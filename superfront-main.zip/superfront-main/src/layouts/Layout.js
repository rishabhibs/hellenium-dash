import React from "react"
import Fullpagelayout from "./Fullpagelayout"
import Verticallayout from "./Verticallayout"
import Adminlayout from "./Adminlayout"

const layouts = {
  vertical: Verticallayout,
  admin: Adminlayout,
  full: Fullpagelayout
}

const ContextLayout = React.createContext()

class Layout extends React.Component {
  state = {
    activeLayout: 'vertical',
    width: window.innerWidth,
    lastLayout: null,
    direction: 'ltr'
  }

  updateWidth = () => {
    this.setState({
      width: window.innerWidth
    })
  }

  handleWindowResize = () => {
    this.updateWidth()
  }

  componentDidMount = () => {
    if (window !== "undefined") {
      window.addEventListener("resize", this.handleWindowResize)
    }
    this.handleDirUpdate()
  }

  componentDidUpdate() {
    this.handleDirUpdate()
  }

  handleDirUpdate = () => {
    let dir = this.state.direction
    if (dir === "rtl")
      document.getElementsByTagName("html")[0].setAttribute("dir", "rtl")
    else document.getElementsByTagName("html")[0].setAttribute("dir", "ltr")
  }



  render() {
    const { children } = this.props
    return (
      <ContextLayout.Provider
        value={{
          state: this.state,
          fullLayout: layouts["full"],
          VerticalLayout: layouts["vertical"],
          AdminLayout: layouts["admin"],
          switchLayout: layout => {
            this.setState({ activeLayout: layout })
          },
          switchDir: dir => {
            this.setState({ direction: dir })
          }
        }}
      >
        {children}
      </ContextLayout.Provider>
    )
  }
}

export { Layout, ContextLayout }
