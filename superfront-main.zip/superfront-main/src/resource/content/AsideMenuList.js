// eslint-disable no-script-url,jsx-a11y/Linknchor-is-valid
import React from "react";
import { useLocation } from "react-router";
import { NavLink } from "react-router-dom";
import SVG from "react-inlinesvg";
import { checkIsActive } from "../../layouts/_helpers";
// import Layers from '../../assets/media/svg/Layers.svg';
// import Box2 from '../../assets/media/svg/Box2.svg';


export function AsideMenuList() {
  const location = useLocation();
  const getMenuItemActive = (url, hasSubmenu = false) => {
    return checkIsActive(location, url)
      ? ` ${!hasSubmenu && "menu-item-active"} menu-item-open `
      : "";
  };
  return (
    <>

      <nav className="sidebar">
        <div className="sidebar-sticky">
          <ul className="nav">

            <NavLink className="" to="/">
              <li className="company-logo">
                <img src="assets/img/logo.svg" alt="" />
                {/* <span>Dashboard</span> */}
              </li>
            </NavLink>

            <NavLink className="nav-item"  to="/dashboard">
              <li className={`nav-link ${getMenuItemActive("/dashboard")}`}>
                <img src="assets/img/helle-icon.png" alt="" />
                <span>Dashboard</span>
              </li>
            </NavLink>

            {/* <NavLink className="nav-item" to="#">
              <li className={`nav-link ${getMenuItemActive("/personal")}`}>
                <img src="assets/img/helle-icon.png" alt="" />
                <span>Hellenium XML</span>
              </li>
            </NavLink> */}

            <NavLink className="nav-item"  to="/buy">
              <li className={`nav-link ${getMenuItemActive("/buy")}`}>
                <span>Buy</span>
              </li>
            </NavLink>

            <NavLink className="nav-item"  to="/sell">
              <li className={`nav-link ${getMenuItemActive("/sell")}`}>
                <span>Sell</span>
              </li>
            </NavLink>

            <NavLink className="nav-item" to="/deposit">
              <li className={`nav-link ${getMenuItemActive("/deposit")}`}>
                <span>Deposit</span>
              </li>
            </NavLink>

            <NavLink className="nav-item" to="/transfer">
              <li className={`nav-link ${getMenuItemActive("/transfer")}`}>
                <span>Transfer</span>
              </li>
            </NavLink>

            <NavLink className="nav-item" to="/withdraw">
              <li className={`nav-link ${getMenuItemActive("/withdraw")}`}>
                <span>Withdraw</span>
              </li>
            </NavLink>

            <NavLink className="nav-item" to="/bank">
              <li className={`nav-link ${getMenuItemActive("/bank")}`}>
                <span>Bank</span>
              </li>
            </NavLink>
            <NavLink className="nav-item" to="/personal">
              <li className={`nav-link ${getMenuItemActive("/personal")}`}>
                <span>Transaction History</span>
              </li>
            </NavLink><NavLink className="nav-item" to="/wallets">
              <li className={`nav-link ${getMenuItemActive("/wallets")}`}>
                <span>Wallets</span>
              </li>
            </NavLink>

          </ul>
        </div>
      </nav >
    </>

  );
}
