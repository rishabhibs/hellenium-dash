import React from 'react';

class Scroll extends React.Component {
    render () {
        return (
            <div id="kt_scrolltop" className="scrolltop">
                <span className="svg-icon">
                    <SVG src={toAbsoluteUrl("/assets/media/svg/icons/Navigation/Up-2.svg")}></SVG>
                </span>
            </div>
        )
    }
}

export default Scroll;
