import React from 'react';
import { history } from '../history';
import { signOut } from '../../redux/actions/auth';
import { connect } from 'react-redux';
import { GoSignOut } from 'react-icons/go';
import { ImOffice } from 'react-icons/im';
import { AiFillCopy } from 'react-icons/ai';
import { toast } from "react-toastify";
import {
    isMobile
} from "react-device-detect";
import Cookies from 'universal-cookie';

import { user_info } from '../../redux/actions/auth';
import { getwallets } from '../../redux/actions/wallets';
import { current_wallet, gettransactions } from '../../redux/actions/balances';
import { check_kyc } from '../../redux/actions/kyc';
import { getallcurrencies, getprice } from '../../redux/actions/currencies';
import config from '../../config';

import ArrowRightAltIcon from '@material-ui/icons/ArrowRightAlt';
import KeyboardBackspaceIcon from '@material-ui/icons/KeyboardBackspace';

import "../../assets/scss/simpleStyle.scss";

class Header extends React.Component {

    constructor() {
        super()
        this.state = {
            firstname: '',
            lastname: '',
            email: '',
            phonenumber: '',
            userdata: {},
            flag: false,
            arrow: 'right'
        }
    }

    UNSAFE_componentWillMount() {
        this.props.user_info();
        this.props.current_wallet();
        this.props.getprice();
        this.props.check_kyc();
        this.props.getwallets();
        this.props.getallcurrencies();
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if (nextProps.userdata) {
            this.setState({ userdata: nextProps.userdata });
        }
        if (this.props !== nextProps && this.state.flag === false) {
            this.setState({ flag: true });
            let socket = nextProps.socket;

            try {
                socket.on('getDepositdone', (data) => {
                    if (data === true) {
                        toast.success("Deposit done!", {
                            position: "top-right",
                            autoClose: 2000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                        });
                        this.props.current_wallet();
                    } else {
                        toast.error("Deposit Failed!", {
                            position: "top-right",
                            autoClose: 2000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                        });
                    }
                })

                socket.on('getWithdrawdone', (data) => {
                    if (data === true) {
                        toast.success("Withdrawal done! Please confirm your bank", {
                            position: "top-right",
                            autoClose: 2000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                        });
                    } else {
                        toast.error("Withdrawal Failed!", {
                            position: "top-right",
                            autoClose: 2000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                        });
                    }
                    this.props.current_wallet();
                })

                socket.on('getBuydone', (data) => {
                    if (data === true) {
                        toast.success("Buy request done!", {
                            position: "top-right",
                            autoClose: 2000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                        });
                    } else {
                        toast.error("Buy request Failed!", {
                            position: "top-right",
                            autoClose: 2000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                        });
                    }
                    this.props.current_wallet();
                })

                socket.on('mCreateapayment', (data) => {
                    toast.success(`${data.sender} sent ${data.amount} ${data.asset} to you!`, {
                        position: "top-right",
                        autoClose: 2000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                    this.props.current_wallet();
                })
            } catch (error) {
                console.log(error);
                const cookies = new Cookies();
                if (config.dev === true) {
                    cookies.remove('socket', { path: '/', domain: "localhost" });
                } else {
                    cookies.remove('socket', { path: '/', domain: "hellenium.com" });
                }
                // window.location.href = config.client_url;
            }
        }
    }

    signout = () => {
        this.props.signOut();
        history.push('/signin');
    }

    gotohome = () => {
        history.push('/');
    }

    gotoaddcompany = () => {
        history.push('/company');
    }

    copyText() {
        var copyinput = document.createElement("input");
        copyinput.setAttribute("id", "copytext");
        copyinput.setAttribute("value", this.props.currentwallet.public_key);
        document.body.append(copyinput);
        var copyText = document.getElementById("copytext");
        copyText.select();
        document.execCommand("copy");
        copyinput.remove();

        toast.success("Address copied successfully!", {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    }

    rightleftbar() {
        document.getElementsByClassName('aside-left')[0].style.left = '0px';
        this.setState({ arrow: 'left' })
    }

    leftleftbar() {
        document.getElementsByClassName('aside-left')[0].style.left = '-295px';
        this.setState({ arrow: 'right' })
    }

    render() {
        return (
            <div id="kt_header" className="header header-fixed">
                <div className="container-fluid d-flex align-items-stretch justify-content-between">
                    <div className="header-menu-wrapper header-menu-wrapper-left">
                        <div className="subheader-separator subheader-separator-ver mt-2 mb-2 mr-4 bg-gray-200"></div>
                        <h5 className="font-weight-bold mr-4 mb-2 mt-8">
                            <span className="text-dark-50 font-weight-bolder mr-5">Wallet Address</span>
                            {this.props.currentwallet ? this.props.currentwallet.public_key !== undefined ? this.props.currentwallet.public_key.slice(0, 8) : "" : ""}...
                            <summary className="text-dark-50 font-weight-bolder d-none d-md-inline ml-3 copyBtn" onClick={() => this.copyText()}><AiFillCopy className="text-primary" /></summary>
                        </h5>
                    </div>Z
                    <div className="topbar pt-4 pb-4">
                        {
                            isMobile ? <div className="topbar-item pl-3">
                                <div className="btn btn-icon btn-icon-mobile w-auto btn-clean d-flex align-items-center btn-lg px-2" >
                                    <span className="symbol symbol-lg-35 symbol-25 symbol-light-primary">
                                        <span className="symbol-label font-size-h5 font-weight-bold">
                                            {this.state.arrow === 'right' ? <ArrowRightAltIcon onClick={() => this.rightleftbar()} /> : <KeyboardBackspaceIcon onClick={() => this.leftleftbar()} />}
                                        </span>
                                    </span>
                                </div>
                            </div> : ""
                        }

                        <div className="topbar-item pl-3">
                            <div className="btn btn-icon btn-icon-mobile w-auto btn-clean d-flex align-items-center btn-lg px-2" onClick={() => { this.props.status === 0 ? this.props.parent(1) : this.props.parent(0) }}>
                                <span className="symbol symbol-lg-35 symbol-25">
                                    <span className="symbol-label font-size-h5 font-weight-bold">
                                        <button className="btn btn-light-primary btn-bold align-items-center mr-3" onClick={() => this.gotoaddcompany()}><ImOffice /></button>
                                    </span>
                                </span>
                            </div>
                        </div>
                        <div className="topbar-item pl-3">
                            <div className="btn btn-icon btn-icon-mobile w-auto btn-clean d-flex align-items-center btn-lg px-2" onClick={() => { this.props.status === 0 ? this.props.parent(1) : this.props.parent(0) }}>
                                <span className="text-muted font-weight-bold font-size-base d-none d-md-inline mr-1">Hi,</span>
                                <span className="text-dark-50 font-weight-bolder font-size-base d-none d-md-inline mr-3">
                                    {`${this.state.userdata.firstname ? this.state.userdata.firstname : ""} ${this.state.userdata.lastname ? this.state.userdata.lastname : ""}`}
                                </span>
                                <span className="symbol symbol-lg-35 symbol-25">
                                    {/* <span className="symbol-label font-size-h5 font-weight-bold">{this.state.firstname[0]}</span> */}
                                </span>
                            </div>
                        </div>
                        <div className="topbar-item pl-3">
                            <div className="btn btn-icon btn-icon-mobile w-auto btn-clean d-flex align-items-center btn-lg px-2" onClick={() => { this.props.status === 0 ? this.props.parent(1) : this.props.parent(0) }}>
                                <span className="symbol symbol-lg-35 symbol-25">
                                    <span className="symbol-label font-size-h5 font-weight-bold">
                                        <button className="btn btn-light-primary btn-bold align-items-center mr-3" onClick={() => this.signout()}><GoSignOut /></button>
                                    </span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function done(state) {
    return {
        socket: state.socket.socket,
        userdata: state.userdata.userdata,
        state: state.auth.auth,
        currentwallet: state.stellar.currentwallet,
        wallets: state.stellar.wallets,
        allasets: state.stellar.allasets,
    }
}

export default connect(done, {
    signOut,
    user_info,
    getwallets,
    current_wallet,
    check_kyc,
    getallcurrencies,
    getprice,
    gettransactions
})(Header);