import React from 'react';
import { history } from '../history';
import { signOut } from '../../redux/actions/auth';
import { connect } from 'react-redux';
import { GoSignOut } from 'react-icons/go';
import { ImOffice } from 'react-icons/im';
import { AiFillCopy } from 'react-icons/ai';
import { toast } from "react-toastify";
import {
  isMobile
} from "react-device-detect";
import Cookies from 'universal-cookie';

import { user_info } from '../../redux/actions/auth';
import { getwallets } from '../../redux/actions/wallets';
import { current_wallet, gettransactions } from '../../redux/actions/balances';
import { check_kyc } from '../../redux/actions/kyc';
import { getallcurrencies, getprice } from '../../redux/actions/currencies';
import config from '../../config';

import ArrowRightAltIcon from '@material-ui/icons/ArrowRightAlt';
import KeyboardBackspaceIcon from '@material-ui/icons/KeyboardBackspace';

import "../../assets/scss/simpleStyle.scss";

class Header extends React.Component {

  constructor() {
    super()
    this.state = {
      firstname: '',
      lastname: '',
      email: '',
      phonenumber: '',
      userdata: {},
      flag: false,
      arrow: 'right'
    }
  }

  UNSAFE_componentWillMount() {
    this.props.user_info();
    this.props.current_wallet();
    this.props.getprice();
    this.props.check_kyc();
    this.props.getwallets();
    this.props.getallcurrencies();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.userdata) {
      this.setState({ userdata: nextProps.userdata });
    }
    if (this.props !== nextProps && this.state.flag === false) {
      this.setState({ flag: true });
      let socket = nextProps.socket;

      try {
        socket.on('getDepositdone', (data) => {
          if (data === true) {
            toast.success("Deposit done!", {
              position: "top-right",
              autoClose: 2000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            });
            this.props.current_wallet();
          } else {
            toast.error("Deposit Failed!", {
              position: "top-right",
              autoClose: 2000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            });
          }
        })

        socket.on('getWithdrawdone', (data) => {
          if (data === true) {
            toast.success("Withdrawal done! Please confirm your bank", {
              position: "top-right",
              autoClose: 2000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            });
          } else {
            toast.error("Withdrawal Failed!", {
              position: "top-right",
              autoClose: 2000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            });
          }
          this.props.current_wallet();
        })

        socket.on('getBuydone', (data) => {
          if (data === true) {
            toast.success("Buy request done!", {
              position: "top-right",
              autoClose: 2000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            });
          } else {
            toast.error("Buy request Failed!", {
              position: "top-right",
              autoClose: 2000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            });
          }
          this.props.current_wallet();
        })

        socket.on('mCreateapayment', (data) => {
          toast.success(`${data.sender} sent ${data.amount} ${data.asset} to you!`, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
          this.props.current_wallet();
        })
      } catch (error) {
          console.log(error);
          const cookies = new Cookies();
          if (config.dev === true) {
              cookies.remove('socket', { path: '/', domain: "localhost" });
          } else {
              cookies.remove('socket', { path: '/', domain: "hellenium.com" });
          }
          window.location.href = config.client_url;
      }
    }
  }

  signout = () => {
    this.props.signOut();
    history.push('/signin');
  }

  gotohome = () => {
    history.push('/');
  }

  gotoaddcompany = () => {
    history.push('/company');
  }

  copyText() {
    var copyinput = document.createElement("input");
    copyinput.setAttribute("id", "copytext");
    copyinput.setAttribute("value", this.props.currentwallet.public_key);
    document.body.append(copyinput);
    var copyText = document.getElementById("copytext");
    copyText.select();
    document.execCommand("copy");
    copyinput.remove();

    toast.success("Address copied successfully!", {
      position: "top-right",
      autoClose: 2000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  }

  rightleftbar() {
    document.getElementsByClassName('aside-left')[0].style.left = '0px';
    this.setState({ arrow: 'left' })
  }

  leftleftbar() {
    document.getElementsByClassName('aside-left')[0].style.left = '-295px';
    this.setState({ arrow: 'right' })
  }

  render() {
    return (
      <>
        <nav className="navbar sticky-top top-menu flex-md-nowrap">
          <button className="navbar-toggler">
            <img src="assets/img/menu-icon.png" />
          </button>
          <button className="toggle-close">
            <img src="assets/img/menu-close.png" />
          </button>
          <ul className="account-balance-score">
            <li>Balance</li>
            <li><span>XML</span>400</li>
            <li><span>XML</span>400</li>
            <li><span>XML</span>400</li>
            <li><span>XML</span>400</li>
          </ul>
          <ul className="navbar-nav">
            <li className="nav-item text-nowrap my-profile-menu">
              <a role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" className="profile-pic-link" href="#"><img src="assets/img/profile-img.png" alt="" /></a>

              <div className="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink" x-placement="bottom-end">
              <a className="dropdown-item" href="#">My Account</a>
              <a className="dropdown-item" href="#">My Orders</a>
              <a className="dropdown-item" href="#">Logout</a></div>
            </li>
          </ul>
        </nav>

      </>
    )
  }
}

function done(state) {
  return {
    socket: state.socket.socket,
    userdata: state.userdata.userdata,
    state: state.auth.auth,
    currentwallet: state.stellar.currentwallet,
    wallets: state.stellar.wallets,
    allasets: state.stellar.allasets,
  }
}

export default connect(done, {
  signOut,
  user_info,
  getwallets,
  current_wallet,
  check_kyc,
  getallcurrencies,
  getprice,
  gettransactions
})(Header);