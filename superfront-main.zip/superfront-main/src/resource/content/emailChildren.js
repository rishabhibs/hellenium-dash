import { lazy } from "react"
import {
    useParams
} from "react-router-dom";
const Emailconfirm  = lazy(() => import('./emailconfirm'));

export default function EmailChildren() {
    let { data } = useParams();

    return (
        <Emailconfirm data={data} />
    );
}