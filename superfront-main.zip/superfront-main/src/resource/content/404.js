import React from 'react';
import backgroundImage from '../../assets/media/error/bg2.jpg';

class Error extends React.Component {
    render () {
        return (
            <div className="d-flex flex-column flex-root" style={{ height: "100%" }}>
                <div className="d-flex flex-row-fluid bgi-size-cover bgi-position-center" style={{backgroundImage: `url(${backgroundImage})`}}>
                    <div className="d-flex flex-row-fluid flex-column justify-content-end align-items-center text-center text-white pb-40">
                        <h1 className="display-1 font-weight-bold">OOPS!</h1>
                        <span className="display-4 font-weight-boldest mb-8">Something went wrong here</span>
                    </div>
                </div>
            </div>
        )
    }
}

export default Error;