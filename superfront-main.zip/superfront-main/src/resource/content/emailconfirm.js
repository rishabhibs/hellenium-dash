import React from 'react';
import { Link } from 'react-router-dom';
import { emailConfirm } from '../../redux/actions/emailConfirm';
import { connect } from 'react-redux';
import BackgroundImg from '../../assets/media/bg/bg-1.jpg';
import LogoImage from '../../assets/images/stellar.png';
import '../../assets/css/thankyoupage.css';
import Spinner from "../Loading-spinner";

class Emailconfirm extends React.Component {
    
    constructor() {
        super()
        this.state = {
            data: '',
            status: 0,
            message: "",
            confirms: false,
        }
    }

    UNSAFE_componentWillMount() {
        this.props.emailConfirm(this.props.data);
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        let obj = { status: 1 };
        obj['confirms'] = nextProps.confirm.status;
        obj['message'] = nextProps.confirm.message;
        this.setState(obj);
    }

    render () {
        return (
            <>
                {this.state.status === 0 ? 
                    <Spinner />:
                    <div className="d-flex flex-column flex-root" style={{ height: "100%" }}>
                        <div className="login login-3 login-signin-on d-flex flex-row-fluid" id="kt_login">
                            <div className="d-flex flex-center bgi-size-cover bgi-no-repeat flex-row-fluid" style={{ backgroundImage: `url(${BackgroundImg})` }}>
                                <div className="login-form text-center text-white p-7 position-relative overflow-hidden">
                                    <div className="flex-center mb-15">
                                        <Link to="#">
                                            <img src={LogoImage} className="max-h-200px" alt="" />
                                        </Link>
                                    </div>
                                    {
                                        this.state.confirms === true ? 
                                        <div className="login-signin">
                                            <div className="mb-20">
                                                <h3>Thank you for your verification</h3>
                                                <p className="opacity-60 font-weight-bold">Please feel free to use this for msc1 & XML</p>
                                            </div>
                                            <div className="mt-10">
                                                <button type="button" id="kt_login_signin_submit" className="btn btn-pill btn-outline-white font-weight-bold opacity-90 px-15 py-3">
                                                    <Link to="/signin" id="kt_login_signin" className="text-white font-weight-bold">Go to signin</Link>
                                                </button>
                                            </div>
                                        </div> :
                                        <div className="login-signin">
                                            <div className="mb-20">
                                                <h3>Something went wrong</h3>
                                                <p className="opacity-60 font-weight-bold">{this.state.message}</p>
                                            </div>
                                            <div className="mt-10">
                                                <button type="button" id="kt_login_signin_submit" className="btn btn-pill btn-outline-white font-weight-bold opacity-90 px-15 py-3">
                                                    <Link to="/signup" id="kt_login_signin" className="text-white font-weight-bold">Go to signup</Link>
                                                </button>
                                            </div>
                                        </div>
                                    }
                                </div>
                            </div>
                        </div>
                    </div>
                }
            </>
        )
    }
}

function done(state) {
    return {
        confirm: state.userdata.confirm
    }
}

export default connect(done, { emailConfirm })(Emailconfirm);
