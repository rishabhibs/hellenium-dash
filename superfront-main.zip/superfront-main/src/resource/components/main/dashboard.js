import React from 'react';
import { connect } from 'react-redux';
// import { Link } from 'react-router-dom';
// import SVG from "react-inlinesvg";

import { gettransactions } from '../../../redux/actions/balances';
// import Datagrid from './transactions/datagrid';
import { GotoSearch } from '../../../redux/actions/search';
import { history } from '../../history';
// import Shielduser from '../../../assets/media/svg/Shield-user.svg';
// import Adduser from '../../../assets/media/svg/Add-user.svg';
// import Sending from '../../../assets/media/svg/Sending.svg';
// import Exchange from '../../../assets/media/svg/Exchange.svg';

class Dashboard extends React.Component {

  constructor() {
    super();
    this.state = {
      walletid: "",
      trdata: []
    }
  }

  UNSAFE_componentWillMount() {
    this.props.gettransactions({
      id: this.props.currentwallet.id
    })
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      if (nextProps.transactiondata) {
        if (nextProps.transactiondata.length === 0) {
          this.props.gettransactions({
            id: this.props.currentwallet.id
          })
        } else {
          this.setState({
            trdata: nextProps.transactiondata
          })
        }
      }
    }
  }

  gotoSearch(type) {
    this.props.GotoSearch(type);
    history.push('/search');
  }

  render() {
    return (
      <div>
      <div className="left-container">
        {/*Profile Welcome Section*/}
        <div className="row">
          <div className="col-md-8 col-sm-12 col-12">
            <div className="profile-welcome-box">
              <div className="welcome-text">
                <h3>Hi Sotiris!</h3>
                <h5>What would you like to do now?</h5>
                <div className="btn-row">
                  <a href="#" className="btn"><img src="assets/img/p-btn-1.svg" alt="" /> Buy</a>
                  <a href="#" className="btn"><img src="assets/img/p-btn-2.svg" alt="" /> Sell</a>
                  <a href="#" className="btn"><img src="assets/img/p-btn-1.svg" alt="" /> Add a beneficiary</a>
                  <a href="#" className="btn"><img src="assets/img/p-btn-2.svg" alt="" /> Create Payment</a>
                </div>
              </div>
              <div className="welcome-img">
                <img src="assets/img/welcome-man.png" alt="" />
              </div>
            </div>
          </div>
          <div className="col-md-4 col-sm-12 col-12">
            <div className="analitics-box">
              <h2>Analitics <a href="#" className="view-more"><img src="assets/img/right-arrow.svg" alt="" /></a>
              </h2>
              <div className="chart-box">
                <img src="assets/img/chart-img.png" alt="" />
              </div>
              <h3>20</h3>
            </div>
          </div>
        </div>
        {/*Profile Welcome Section*/}
        <div className="transaction-history-section">
          <div className="transaction-history-content">
            <div className="row">
              <div className="col-md-6">
                <h2>Transaction History</h2>
                <h3>These are your last transactions.</h3>
              </div>
              <div className="col-md-6 timing-tab-box">
                <ul>
                  <li><a href="#">Month</a></li>
                  <li><a href="#">Week</a></li>
                  <li><a href="#" className="active">Day</a></li>
                </ul>
              </div>
            </div>
            <div className="transaction-history-table table-responsive">
              <table className="table">
                {/*Row start*/}
                <tbody><tr>
                  <td className="date-td">
                    <span className="month">Oct</span>
                    <span className="date">22</span>
                  </td>
                  <td className="logo-td">
                    <a href="#" className="logo-btn">
                      <img src="assets/img/t-logo.png" alt="" />
                    </a>
                  </td>
                  <td className="email-td">
                    <span className="outstand-span">Sant Outstanding</span>
                    <h4>Email: <a href="#">mail@gmail.com</a></h4>
                  </td>
                  <td className="paid-td">
                    <h3>$2,000,000</h3>
                    <h4>Paid</h4>
                  </td>
                  <td className="amount-td">
                    <h3>$2,000,000</h3>
                  </td>
                  <td className="approved-td">
                    <span className="alert">Approved</span>
                  </td>
                  <td className="action-td">
                    <div className="dropdown show">
                      <a className href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="assets/img/action-icon.png" alt="" />
                      </a>
                      <div className="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                        <a className="dropdown-item" href="#">delete</a>
                        <a className="dropdown-item" href="#">view</a>
                        <a className="dropdown-item" href="#">Edit</a>
                      </div>
                    </div>
                  </td>
                </tr>
                  {/*Row End*/}
                  {/*Row start*/}
                  <tr>
                    <td className="date-td">
                      <span className="month">Oct</span>
                      <span className="date">22</span>
                    </td>
                    <td className="logo-td">
                      <a href="#" className="logo-btn">
                        <img src="assets/img/t-logo.png" alt="" />
                      </a>
                    </td>
                    <td className="email-td">
                      <span className="outstand-span">Sant Outstanding</span>
                      <h4>Email: <a href="#">mail@gmail.com</a></h4>
                    </td>
                    <td className="paid-td">
                      <h3>$2,000,000</h3>
                      <h4>Paid</h4>
                    </td>
                    <td className="amount-td">
                      <h3>$2,000,000</h3>
                    </td>
                    <td className="approved-td">
                      <span className="alert">Approved</span>
                    </td>
                    <td className="action-td">
                      <div className="dropdown show">
                        <a className href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <img src="assets/img/action-icon.png" alt="" />
                        </a>
                        <div className="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                          <a className="dropdown-item" href="#">delete</a>
                          <a className="dropdown-item" href="#">view</a>
                          <a className="dropdown-item" href="#">Edit</a>
                        </div>
                      </div>
                    </td>
                  </tr>
                  {/*Row End*/}
                  {/*Row start*/}
                  <tr>
                    <td className="date-td">
                      <span className="month">Oct</span>
                      <span className="date">22</span>
                    </td>
                    <td className="logo-td">
                      <a href="#" className="logo-btn">
                        <img src="assets/img/t-logo.png" alt="" />
                      </a>
                    </td>
                    <td className="email-td">
                      <span className="outstand-span">Sant Outstanding</span>
                      <h4>Email: <a href="#">mail@gmail.com</a></h4>
                    </td>
                    <td className="paid-td">
                      <h3>$2,000,000</h3>
                      <h4>Paid</h4>
                    </td>
                    <td className="amount-td">
                      <h3>$2,000,000</h3>
                    </td>
                    <td className="approved-td">
                      <span className="alert">Approved</span>
                    </td>
                    <td className="action-td">
                      <div className="dropdown show">
                        <a className href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <img src="assets/img/action-icon.png" alt="" />
                        </a>
                        <div className="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                          <a className="dropdown-item" href="#">delete</a>
                          <a className="dropdown-item" href="#">view</a>
                          <a className="dropdown-item" href="#">Edit</a>
                        </div>
                      </div>
                    </td>
                  </tr>
                  {/*Row End*/}
                  {/*Row start*/}
                  <tr>
                    <td className="date-td">
                      <span className="month">Oct</span>
                      <span className="date">22</span>
                    </td>
                    <td className="logo-td">
                      <a href="#" className="logo-btn">
                        <img src="assets/img/t-logo.png" alt="" />
                      </a>
                    </td>
                    <td className="email-td">
                      <span className="outstand-span">Sant Outstanding</span>
                      <h4>Email: <a href="#">mail@gmail.com</a></h4>
                    </td>
                    <td className="paid-td">
                      <h3>$2,000,000</h3>
                      <h4>Paid</h4>
                    </td>
                    <td className="amount-td">
                      <h3>$2,000,000</h3>
                    </td>
                    <td className="approved-td">
                      <span className="alert">Approved</span>
                    </td>
                    <td className="action-td">
                      <div className="dropdown show">
                        <a className href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <img src="assets/img/action-icon.png" alt="" />
                        </a>
                        <div className="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                          <a className="dropdown-item" href="#">delete</a>
                          <a className="dropdown-item" href="#">view</a>
                          <a className="dropdown-item" href="#">Edit</a>
                        </div>
                      </div>
                    </td>
                  </tr>
                  {/*Row End*/}
                </tbody></table>
            </div>
          </div>
        </div>
      </div>
      </div>
    )
  }
}

function donef(state) {
  return {
    currentwallet: state.stellar.currentwallet,
    transactiondata: state.userdata.tdata
  }
}

export default connect(donef, { GotoSearch, gettransactions })(Dashboard);