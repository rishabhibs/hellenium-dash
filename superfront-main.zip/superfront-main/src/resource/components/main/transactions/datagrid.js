import React from 'react'
import { MDBDataTable } from 'mdbreact'

const commonCol = [
  {
    label: 'No',
    field: 'no',
    sort: 'asc',
  },
  {
    label: 'Sender Name',
    field: 'sender',
    sort: 'asc',
  },
  {
    label: 'Sender Email',
    field: 's_email',
    sort: 'asc',
  },
  {
    label: 'Sender Wallet Address',
    field: 's_wallet',
    sort: 'asc',
  },
  {
    label: 'Receiver Name',
    field: 'receiver',
    sort: 'asc',
  },
  {
      label: 'Reciever Email',
      field: 'r_email',
      sort: 'asc',
  },
  {
      label: 'Receiver Wallet Address',
      field: 'r_wallet',
      sort: 'asc',
  },
  {
      label: 'Amount',
      field: 'amount',
      sort: 'asc',
  },
  {
      label: 'Asset Code',
      field: 'asset_code',
      sort: 'asc',
  },
  {
      label: 'Asset Issuer',
      field: 'asset_issuer',
      sort: 'asc',
  },
  {
      label: 'Form',
      field: 'form',
      sort: 'asc',
  },
  {
      label: 'Type',
      field: 'type',
      sort: 'asc',
  },
  {
      label: 'Time',
      field: 'time',
      sort: 'asc',
  },
]

class Datagrid extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data : {
                columns: commonCol,
                rows: props.transactiondata
            }   
        }
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(nextProps !== this.props){
            this.setState({
                data: {
                    columns: commonCol,
                    rows: nextProps.transactiondata
                }
            });
        }
    }

    render() {
        return (
            <MDBDataTable
                striped
                bordered
                small
                hover
                className="w-98"
                data={this.state.data}
            />
        );
    }
}

export default Datagrid;