import React from 'react';
import { connect } from 'react-redux';
import Select from 'react-select';
import Spinner from 'react-bootstrap/Spinner'
import Cookies from 'universal-cookie';

import '../../../../assets/css/type-select.css';
import { transfer_stellar } from '../../../../redux/actions/transfer';
import countries from "../../../../assets/countries";

class Company extends React.Component {
    constructor() {
        super();
        this.state = {
            amount: 0,
            customStyles: {
                control: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 400
                }),
                menu: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 400
                })
            },
            genderValue: "",
            status: 0,
            loading: 0,


            registerName: "",
            cName: "",
            incorporationDate: "",
            webAddress: "",
            country: "",
            EconomicSector: "",
            Subsector: "",
            vNumber: "",
            targetOption: {}
        }
    }

    UNSAFE_componentWillMount() {
        const cookies = new Cookies();
        var data = JSON.parse(atob(cookies.get("token")));
        console.log(data);
        this.setState({
            registerName: data.firstname
        })
    }

    transfer() {
        this.setState({
            status: 1,
            loading: 1
        })
    }

    componentDidUpdate(prevProps) {
        if(prevProps !==  this.props) {
        }
    }
    
    UNSAFE_componentWillReceiveProps(nextProps) { // Legacy
        // console.log(nextProps.resultData)
        if(nextProps.resultData) {
            this.setState({
                loading: 0
            })
        }
    }

    render () {
        return (
            <div className="d-flex flex-column-fluid">
                <div className="container py-8">
                    <div className="row">
                        <div className="col-lg-12 col-xxl-12">
                            <div className="card card-custom mb-8 mb-lg-0">
                                <div className="card-header border-0 pt-5">
                                    <h3 className="card-title align-items-start flex-column">
                                        <span className="card-label font-weight-bolder text-dark">Company</span>
                                        <span className="text-muted mt-3 font-weight-bold font-size-sm">You have to enter all fields.</span>
                                    </h3>
                                </div>
                                <div className="card-body">
                                    <div className="row">
                                        <div className="card card-custom wave wave-animate-slow wave-info mb-8 mb-lg-0 w-100">
                                            <div className="card-body mb-48">
                                                <div className="form-group row">
                                                    <div className="col-lg-6">
                                                        <label className="ml-3">Name of person Registering the company</label>
                                                        <div className="input-group type-select">
                                                            <input type="text" className="form-control" placeholder="Enter Name of person Registering the company" disabled value={this.state.registerName}/>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6">
                                                        <label className="ml-3">Name of the company</label>
                                                        <div className="input-group type-select">
                                                            <input type="text" className="form-control" placeholder="Enter Name of the company" onChange={(e) => this.setState({cName: e.target.value})}/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="form-group row">
                                                    <div className="col-lg-6">
                                                        <label className="ml-3">Date of incorporation</label>
                                                        <div className="input-group type-select">
                                                            <input type="text" className="form-control" placeholder="Enter Date of incorporation" onChange={(e) => this.setState({incorporationDate: e.target.value})}/>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6">
                                                        <label className="ml-3">VAT number</label>
                                                        <div className="input-group type-select">
                                                            <input type="text" className="form-control" placeholder="Enter VAT number" onChange={(e) => this.setState({vNumber: e.target.value})}/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="form-group row">
                                                    <div className="col-lg-6">
                                                        <label className="ml-3">web address</label>
                                                        <div className="input-group type-select">
                                                            <input type="text" className="form-control" placeholder="Enter web address" onChange={(e) => this.setState({webAddress: e.target.value})}/>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6">
                                                        <label className="ml-3">Country</label>
                                                        <div className="input-group type-select">
                                                            <Select
                                                                value={this.state.targetOption}
                                                                defaultValue={countries[0]}
                                                                onChange={(e) => this.setState({targetOption: e})} 
                                                                options={countries} 
                                                                styles={this.state.customStyles}
                                                                maxMenuHeight={200}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="form-group row">
                                                    <div className="col-lg-6">
                                                        <label className="ml-3">Economic sector</label>
                                                        <div className="input-group type-select">
                                                            <input type="text" className="form-control" placeholder="Enter Economic sector" onChange={(e) => this.setState({EconomicSector: e.target.value})}/>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6">
                                                        <label className="ml-3">Subsector</label>
                                                        <div className="input-group type-select">
                                                            <input type="text" className="form-control" placeholder="Enter Subsector" onChange={(e) => this.setState({Subsector: e.target.value})}/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="card-footer">
                                    <div className="row">
                                        <div className="col-lg-12 text-right">
                                            <button type="reset" className="btn btn-primary mr-2" onClick={() => this.transfer()}>
                                                { this.state.loading === 1 ? <Spinner animation="border" /> : "Submit" }
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function resultf(state) {
    return {
        resultData: state.main.data,
        beneficiaries: state.stellar.getbeneficiaries
    }
}

export default connect(resultf, { transfer_stellar })(Company);