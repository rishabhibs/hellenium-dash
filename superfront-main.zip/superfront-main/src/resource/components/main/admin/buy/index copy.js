import React from 'react';
import { connect } from "react-redux";
import Dialog from 'react-bootstrap-dialog'
import Select from 'react-select'

import Btable from './b_table';
import { buyget, buychange, deleteHistoryBuy } from '../../../../../redux/actions/admin';
import Button from '@material-ui/core/Button';
import "../../../../../assets/scss/simpleStyle.scss";

class ABuy extends React.Component {

    constructor() {
        super()
        this.state = {
            buydata : [],
            toml: {},
            loading: 0,
            disablebutton: false,
            pagestatus: 0,
            modal:false,
            editinguser: {},
            open: false,
            selectStyle: {
                control: base => ({
                    ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 150
                }),
                menu: base => ({
                    ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 150
                })
            },
            options: [
                { label: "pending", value: "pending" },
                { label: "completed", value: "completed" },
                { label: "failed", value: "failed" },
            ],
            targetOption: {}
        }
    }

    UNSAFE_componentWillMount() {
        let socket = this.props.socket;
        socket.on('mBuyrequested', () => {
            this.props.buyget();
        })
        this.props.buyget();
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(this.props !== nextProps) {
            this.setState({
                loading: 0,
                disablebutton: false,
                open: false
            })
        }
        if(nextProps.buydata) {
            let arr = [];
            for(let i = 0 ; i < nextProps.buydata.length ; i++) {
                let buyData = nextProps.buydata[i];
                let obj = {
                    'no': i+1,
                    'firstname': buyData.tbl_user.firstname,
                    'lastname': buyData.tbl_user.lastname,
                    'email': buyData.tbl_user.email,
                    'crypto': buyData.crypto,
                    'issuer': buyData.issuer,
                    'fiat': buyData.fiat,
                    'cryptoamount': buyData.cryptoamount,
                    'fiatamount': buyData.fiatamount,
                    'priceterms': buyData.priceterms,
                    'createdAt': buyData.createdAt,
                    'updatedAt': buyData.updatedAt,
                    'status': buyData.status === "pending" ? <Select className="select" autosize={true} styles={this.state.selectStyle} options={this.state.options} onChange={(e) => this.changetarget(e.value, buyData.id)}  maxMenuHeight={80} value={this.state.options.filter(item => item.value === buyData.status)[0]} /> : buyData.status,
                    'action': <Button variant="contained" color="secondary" onClick={() => this.deleteHistoryBuy(buyData.id)}>Delete</Button>,
                }
                arr.push(obj);
            }
            this.setState({buydata: arr});
        }
    }

    changetarget(tvalue, id) {
        this.dialog.show({
            title: 'Are you sure?',
            body: 'Please confirm!',
            actions: [
                Dialog.CancelAction(() => {
                    // me.setState({targetOption: })
                }),
                Dialog.OKAction(() => {
                    // console.log(this.state.targetOption);
                    this.props.buychange({
                        id:id,
                        status:tvalue,
                    })
                })
            ],
            bsSize: 'small',
            onHide: () => {}
        })
    }

    edit(user) {
        this.setState({editinguser: user, open:true});
    }

    edituser() {
        this.setState({
            loading: 1,
            disablebutton: true
        })
        this.props.EditUser(this.state.editinguser);
    }

    cancel() {
        this.setState({open: false});
    }
    
    deleteHistoryBuy(partner_id) {
        this.dialog.show({
            title: 'Are you sure?',
            body: 'Please confirm!',
            actions: [
                Dialog.CancelAction(() => {
                    // me.setState({targetOption: })
                }),
                Dialog.OKAction(() => {
                    this.props.deleteHistoryBuy(partner_id);
                })
            ],
            bsSize: 'small',
            onHide: () => {}
        })
    }

    activewallets(publickey) {
        this.props.activewallet(publickey);
    }

    toggle = () => {
        this.setState({
            modal:false
        });
    }

    render () {
        return (
            <div className="d-flex flex-column-fluid justify-content-center pt-18">
                <Dialog ref={(component) => { this.dialog = component }} />
                <div className="py-8 w-98">
                    <div className="row">
                        <div className="col-lg-12 col-xxl-12">
                            <div className="card card-custom mb-8 mb-lg-0">
                                <div className="card-header border-0 pt-5">
                                    <h3 className="card-title align-items-start flex-column">
                                        <span className="card-label font-weight-bolder text-dark">Buy Request</span>
                                    </h3>
                                </div>
                                <div className="card-body">
                                    <div className="row">
                                        <div className="card card-custom wave wave-animate-slow wave-primary mb-8 mb-lg-0 w-100">
                                            <div className="card-body">
                                                <div className="row overflow-auto">
                                                    {
                                                        this.state.buydata.length > 0 ? 
                                                        <Btable buydata={this.state.buydata} />: 
                                                        <h3 className="card-title align-items-center text-center flex-column w-100">
                                                            There is no buy request.
                                                        </h3>
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function buygetdone(state) {
    return {
        socket: state.socket.socket,
        buydata: state.admin.buydata,
    }
}

export default connect(buygetdone, { buyget, buychange, deleteHistoryBuy })(ABuy);