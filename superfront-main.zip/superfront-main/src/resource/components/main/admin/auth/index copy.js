import React from 'react';

import { connect } from "react-redux";
import { toast } from 'react-toastify';
import { adminsignin } from "../../../../../redux/actions/admin";

import "../../../../../assets/scss/simpleStyle.scss";
import "../../../../../assets/scss/new_style.scss";

class Adminlogin extends React.Component {

    constructor() {
        super()
        this.state = {
            toml: {},
            loading: 0,
            main_formClass: "form-control h-auto placeholder-white opacity-70 bg-dark-o-70 border-0 py-4 px-8 mb-5",
            pagestatus: 0,
            email: "",
            password: ""
        }
    }

    gosignin() {
        if(this.state.email === "" || this.state.password === "") {
            toast.error("Input correctly", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            return;
        }
        this.props.adminsignin({email: this.state.email, password: this.state.password});
    }

    render () {
        return (
            <div className="d-flex flex-column flex-root   ooooooppp" style={{ height: "100%" }}>
                <div className="login login-3 login-signin-on d-flex flex-row-fluid" id="kt_login">
                    <div className="d-flex flex-center bgi-size-cover bgi-no-repeat flex-row-fluid">
                        <div className="new-login login-form text-center p-15 position-relative overflow-hidden">
                            <div className="login-signin">
                                <div className="mb-10">
                                    <h3>Sign In As Admin</h3>
                                    <p className="opacity-60 font-weight-bold">Enter your details to login to you admin account:</p>
                                </div>
                                <form className="form" id="kt_login_signin_form">
                                    <div className="form-group has-danger">
                                        <input className={ this.state.email !== "" ? this.state.main_formClass+' is-valid' : this.state.main_formClass+' is-invalid'} type="text" placeholder="Email" onChange={e => {this.setState({email: e.target.value})}} name="email" autoComplete="off" />
                                    </div>
                                    <div className="form-group has-danger">
                                        <input className={ this.state.password !== "" ? this.state.main_formClass+' is-valid' : this.state.main_formClass+' is-invalid' } type="password" placeholder="Password" onChange={e => {this.setState({password: e.target.value})}} name="password" value={this.state.password} />
                                    </div>
                                    <div className="form-group text-center mt-10">
                                        <button type="button" onClick={() => this.gosignin()} id="kt_login_signin_submit" className="new-login-btn-color btn btn-pill btn-outline-white border-white font-weight-bold opacity-90 px-15 py-3">Sign In</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default connect(null, { adminsignin })(Adminlogin);