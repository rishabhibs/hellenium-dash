import React from 'react';

import { connect } from "react-redux";
import { toast } from 'react-toastify';
import { adminsignin } from "../../../../../redux/actions/admin";

import "../../../../../assets/scss/simpleStyle.scss";
import "../../../../../assets/scss/new_style.scss";

class Adminlogin extends React.Component {

    constructor() {
        super()
        this.state = {
            toml: {},
            loading: 0,
            main_formClass: "form-control h-auto placeholder-white opacity-70 bg-dark-o-70 border-0 py-4 px-8 mb-5",
            pagestatus: 0,
            email: "",
            password: ""
        }
    }

    gosignin() {
        if (this.state.email === "" || this.state.password === "") {
            toast.error("Input correctly", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            return;
        }
        this.props.adminsignin({ email: this.state.email, password: this.state.password });
    }

    render() {
        return (
            <div className="login-container">
                <form className="form-signin">
                    <img className="login-logo" src="assets/img/logo.svg" alt="" />
                    <h1 className="login-heading">Sign In As Admin</h1>
                    <h2 className="login-subheading">Enter Your Details</h2>
                    <div className="form-box">
                        <label htmlFor="Email" className="label">Email address</label>
                        <input type="email" id="Email" className="form-control" 
                        onChange={e => {this.setState({email: e.target.value})}} name="email"
                        placeholder="sonice@sonice.com" required />
                    </div>
                    <div className="form-box">
                        <label htmlFor="Password" className="label">Password</label>
                        <input type="password" id="Password" className="form-control" 
                        onChange={e => {this.setState({password: e.target.value})}} name="password" value={this.state.password} 
                        placeholder="***********" required />
                    </div>
                    <button className="btn btn-block"
                     onClick={() => this.gosignin()} 
                     type="button">Sign In</button>
                </form>
            </div>

        )
    }
}

export default connect(null, { adminsignin })(Adminlogin);