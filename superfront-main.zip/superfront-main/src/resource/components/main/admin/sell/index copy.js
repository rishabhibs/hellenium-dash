import React from 'react';
import { connect } from "react-redux";
import Dialog from 'react-bootstrap-dialog'
// import Select from 'react-select'

import Stable from './s_table';
import { sellget } from '../../../../../redux/actions/admin';
// import { sellget, sellchange, deleteHistorySell } from '../../../../../redux/actions/admin';
import Button from '@material-ui/core/Button';
import "../../../../../assets/scss/simpleStyle.scss";

class ASell extends React.Component {

    constructor() {
        super()
        this.state = {
            selldata : [],
            toml: {},
            loading: 0,
            disablebutton: false,
            pagestatus: 0,
            modal:false,
            editinguser: {},
            open: false,
            selectStyle: {
                control: base => ({
                    ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 150
                }),
                menu: base => ({
                    ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 150
                })
            },
            options: [
                { label: "pending", value: "pending" },
                { label: "completed", value: "completed" },
                { label: "failed", value: "failed" },
            ],
            targetOption: {}
        }
    }

    UNSAFE_componentWillMount() {
        let socket = this.props.socket;
        socket.on('mSellrequested', () => {
            this.props.sellget();
        })
        this.props.sellget();
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(this.props !== nextProps) {
            this.setState({
                loading: 0,
                disablebutton: false,
                open: false
            })
        }
        if(nextProps.selldata) {
            let arr = [];
            for(let i = 0 ; i < nextProps.selldata.length ; i++) {
                let sellData = nextProps.selldata[i];
                let obj = {
                    'no': i+1,
                    'firstname': sellData.tbl_user.firstname,
                    'lastname': sellData.tbl_user.lastname,
                    'email': sellData.tbl_user.email,
                    'crypto': sellData.crypto,
                    'issuer': sellData.issuer,
                    'fiat': sellData.fiat,
                    'cryptoamount': sellData.cryptoamount,
                    'fiatamount': sellData.fiatamount,
                    'priceterms': sellData.priceterms,
                    'createdAt': sellData.createdAt,
                    'updatedAt': sellData.updatedAt,
                    // 'status': sellData.status === "pending" ? <Select className="select" autosize={true} styles={this.state.selectStyle} options={this.state.options} onChange={(e) => this.changetarget(e.value, sellData.id)}  maxMenuHeight={80} value={this.state.options.filter(item => item.value === sellData.status)[0]} /> : sellData.status,
                    'action': <Button variant="contained" color="secondary" onClick={() => this.deleteHistorySell(sellData.id)}>Delete</Button>,
                }
                arr.push(obj);
            }
            this.setState({selldata: arr});
        }
    }

    // changetarget(tvalue, id) {
    //     this.dialog.show({
    //         title: 'Are you sure?',
    //         body: 'Please confirm!',
    //         actions: [
    //             Dialog.CancelAction(() => {
    //                 // me.setState({targetOption: })
    //             }),
    //             Dialog.OKAction(() => {
    //                 // console.log(this.state.targetOption);
    //                 this.props.sellchange({
    //                     id:id,
    //                     status:tvalue,
    //                 })
    //             })
    //         ],
    //         bsSize: 'small',
    //         onHide: () => {}
    //     })
    // }

    edit(user) {
        this.setState({editinguser: user, open:true});
    }

    edituser() {
        this.setState({
            loading: 1,
            disablebutton: true
        })
        this.props.EditUser(this.state.editinguser);
    }

    cancel() {
        this.setState({open: false});
    }
    
    // deleteHistorySell(partner_id) {
    //     this.dialog.show({
    //         title: 'Are you sure?',
    //         body: 'Please confirm!',
    //         actions: [
    //             Dialog.CancelAction(() => {
    //                 // me.setState({targetOption: })
    //             }),
    //             Dialog.OKAction(() => {
    //                 this.props.deleteHistorySell(partner_id);
    //             })
    //         ],
    //         bsSize: 'small',
    //         onHide: () => {}
    //     })
    // }

    activewallets(publickey) {
        this.props.activewallet(publickey);
    }

    toggle = () => {
        this.setState({
            modal:false
        });
    }

    render () {
        return (
            <div className="d-flex flex-column-fluid justify-content-center pt-18">
                <Dialog ref={(component) => { this.dialog = component }} />
                <div className="py-8 w-98">
                    <div className="row">
                        <div className="col-lg-12 col-xxl-12">
                            <div className="card card-custom mb-8 mb-lg-0">
                                <div className="card-header border-0 pt-5">
                                    <h3 className="card-title align-items-start flex-column">
                                        <span className="card-label font-weight-bolder text-dark">Sell Request</span>
                                    </h3>
                                </div>
                                <div className="card-body">
                                    <div className="row">
                                        <div className="card card-custom wave wave-animate-slow wave-primary mb-8 mb-lg-0 w-100">
                                            <div className="card-body">
                                                <div className="row overflow-auto">
                                                    {
                                                        this.state.selldata.length > 0 ? 
                                                        <Stable selldata={this.state.selldata} />: 
                                                        <h3 className="card-title align-items-center text-center flex-column w-100">
                                                            There is no Sell request.
                                                        </h3>
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function sellgetdone(state) {
    return {
        socket: state.socket.socket,
        selldata: state.admin.selldata,
    }
}

export default connect(sellgetdone, { sellget })(ASell);