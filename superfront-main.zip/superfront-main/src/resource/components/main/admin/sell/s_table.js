import React from 'react'
import { MDBDataTable } from 'mdbreact'

const commonCol = [
    {
        label: 'No',
        field: 'no',
        sort: 'asc',
    },
    {
        label: 'First Name',
        field: 'firstname',
        sort: 'asc',
    },
    {
        label: 'Last Name',
        field: 'lastname',
        sort: 'asc',
    },
    {
        label: 'Email',
        field: 'email',
        sort: 'asc',
    },
    {
        label: 'Crypto',
        field: 'crypto',
        sort: 'asc',
    },
    {
        label: 'Fiat',
        field: 'fiat',
        sort: 'asc',
    },
    {
        label: 'Crypto Amount',
        field: 'cryptoamount',
        sort: 'asc',
    },
    {
        label: 'Fiat Amount',
        field: 'fiatamount',
        sort: 'asc',
    },
    {
        label: 'Price of 1 unit of buying in terms',
        field: 'priceterms',
        sort: 'asc',
    },
    // {
    //     label: 'Status',
    //     field: 'status',
    //     sort: 'asc',
    // },
    {
        label: 'Action',
        field: 'action',
        sort: 'asc',
    }
]

class Stable extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data : {
                columns: commonCol,
                rows: props.selldata
            }   
        }
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(nextProps !== this.props){
            this.setState({
                data: {
                    columns: commonCol,
                    rows: nextProps.selldata
                }
            });
        }
    }

    render() {
        return (
            <MDBDataTable
                striped
                bordered
                small
                hover
                className="w-98"
                data={this.state.data}
            />
        );
    }
}

export default Stable;