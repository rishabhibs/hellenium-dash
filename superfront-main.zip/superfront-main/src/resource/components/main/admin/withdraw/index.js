import React from 'react';
import { connect } from "react-redux";
import Select from 'react-select'
import Dialog from 'react-bootstrap-dialog'


// import Btable from './b_table';
import { withdrawget, withdrawchange } from '../../../../../redux/actions/admin';
// import Button from '@material-ui/core/Button';
import "../../../../../assets/scss/simpleStyle.scss";

class ADWithdraw extends React.Component {

    constructor() {
        super()
        this.state = {
            withdrawdata : [],
            toml: {},
            loading: 0,
            disablebutton: false,
            pagestatus: 0,
            modal:false,
            open: false,
            selectStyle: {
                control: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 150
                }),
                menu: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 150
                })
            },
            options: [
                { label: "pending", value: "pending" },
                { label: "completed", value: "completed" },
                { label: "failed", value: "failed" },
            ],
            targetOption: {}
        }
    }

    UNSAFE_componentWillMount() {
        let socket = this.props.socket;
        socket.on('mWithdrawed', () => {
            this.props.withdrawget();
        })
        this.props.withdrawget();
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(this.props !== nextProps) {
            this.setState({
                loading: 0,
                disablebutton: false,
                open: false
            })
        }
        if(nextProps.withdrawdata) {
            let arr = [];
            for(let i = 0 ; i < nextProps.withdrawdata.length ; i++) {
                let obj = {
                    'id': nextProps.withdrawdata[i].id,
                    'no': i+1,
                    'name': nextProps.withdrawdata[i].firstname,
                    'email': nextProps.withdrawdata[i].email,
                    'type': nextProps.withdrawdata[i].type,
                    'iban': nextProps.withdrawdata[i].iban,
                    'address': nextProps.withdrawdata[i].address,
                    'amount': nextProps.withdrawdata[i].amount,
                    'currency': nextProps.withdrawdata[i].currency,
                    'status': nextProps.withdrawdata[i].status === "pending" ? 
                                                <Select 
                                                    className="select" 
                                                    autosize={true} 
                                                    styles={this.state.selectStyle} 
                                                    options={this.state.options} 
                                                    onChange={(e) => this.changetarget(e, nextProps.withdrawdata[i].id, nextProps.withdrawdata[i].partner_id, nextProps.withdrawdata[i].amount, nextProps.withdrawdata[i].currency, nextProps.withdrawdata[i].type, nextProps.withdrawdata[i].address)}  
                                                    maxMenuHeight={80} 
                                                    value={this.state.options.filter(item => item.value === nextProps.withdrawdata[i].status)[0]} /> : 
                                                nextProps.withdrawdata[i].status,
                    'createdAt': nextProps.withdrawdata[i].createdAt,
                    'updatedAt': nextProps.withdrawdata[i].updatedAt,
                }
                arr.push(obj); 
            }
            this.setState({withdrawdata: arr});
        }
    }

    changetarget(target, id, partner_id, amount, currency, type, address) {
        this.dialog.show({
            title: 'Are you sure?',
            body: 'Please confirm!',
            actions: [
                Dialog.CancelAction(() => {
                    // me.setState({targetOption: })
                }),
                Dialog.OKAction(() => {
                    // console.log(this.state.targetOption);
                    this.props.withdrawchange({
                        id:id,
                        type:type,
                        address:address,
                        partner_id:partner_id,
                        amount:amount,
                        currency:currency,
                        status:target.value,
                    })
                })
            ],
            bsSize: 'small',
            onHide: () => {}
        })
    }
    
    render () {
        return (
            <div className="transaction-history-section">
                <div className="transaction-history-content">
                    <div className="row">
                        <div className="col-md-6">
                            <h2>Withdraw Request</h2>
                            <h3>These are list of requests</h3>
                        </div>
                    </div>
                    <div className="request-list-box">
                    {
                  this.state.withdrawdata.length > 0 ?
                    this.state.withdrawdata.map((element, index) => (
                      <tr>
                        <td className="date-td">
                          <span className="month">{index+1}</span>
                        </td>
                        <td className="name-td">
                          <span className="name-span">{element.amount}</span>
                        </td>
                        <td className="surname-td">
                          <span className="surname-span">{element.currency}</span>
                        </td>
                        <td className="user-date-td">
                          <span>{element.createdAt}</span>
                        </td>
                        <td className="user-action-td">
                          <div className="dropdown">
                            <a className href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              <img src="/assets/img/action-icon.png" alt="" />
                            </a>
                            <div className="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink" x-placement="bottom-end" style={{ position: 'absolute', transform: 'translate3d(6px, 23px, 0px)', top: '0px', left: '0px', willChange: 'transform' }}>
                              <a className="dropdown-item" href="#">delete</a>
                              <a className="dropdown-item" href="#">view</a>
                              <a className="dropdown-item" href="#">Edit</a>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))
                    :
                     (                    
                      <>
                        <img src="/assets/img/no-request-img.png" className="no-req-img" alt="" />
                        <h3>There are no requests for confirmation</h3>
                        </>
                   )
                }      
                    </div>
                </div>
            </div>
        )
    }
}

function walletget(state) {
    return {
        socket: state.socket.socket,
        withdrawdata: state.admin.withdrawdata,
    }
}

export default connect(walletget, { withdrawget, withdrawchange })(ADWithdraw);