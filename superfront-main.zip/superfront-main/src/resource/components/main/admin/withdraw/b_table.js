import React from 'react'
import { MDBDataTable } from 'mdbreact'

const commonCol = [
    {
        label: 'No',
        field: 'no',
        sort: 'asc',
    },
    {
        label: 'Name',
        field: 'name',
        sort: 'asc',
    },
    {
        label: 'Email',
        field: 'email',
        sort: 'asc',
    },
    {
        label: 'Type',
        field: 'type',
        sort: 'asc',
    },
    {
        label: 'IBAN',
        field: 'iban',
        sort: 'asc',
    },
    {
        label: 'Distination Address',
        field: 'address',
        sort: 'asc',
    },
    {
        label: 'Amount',
        field: 'amount',
        sort: 'asc',
    },
    {
        label: 'Currency',
        field: 'currency',
        sort: 'asc',
    },
    {
        label: 'Request Status',
        field: 'status',
        sort: 'asc',
    },
    {
        label: 'Requested Date',
        field: 'createdAt',
        sort: 'asc',
    },
    {
        label: 'Managed Date',
        field: 'updatedAt',
        sort: 'asc',
    }
];

class Btable extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data : {
                columns: commonCol,
                rows: props.withdrawdata
            }   
        }
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(nextProps !== this.props){
            this.setState({
                data: {
                    columns: commonCol,
                    rows: nextProps.withdrawdata
                }
            });
        }
    }

    render() {
        return (
            <MDBDataTable
                striped
                bordered
                small
                hover
                className="w-98"
                data={this.state.data}
            />
        );
    }
}

export default Btable;