import React from 'react';
import { connect } from "react-redux";
import Select from 'react-select'
import Dialog from 'react-bootstrap-dialog'

import Btable from './b_table';
import { withdrawget, withdrawchange } from '../../../../../redux/actions/admin';
// import Button from '@material-ui/core/Button';
import "../../../../../assets/scss/simpleStyle.scss";

class ADWithdraw extends React.Component {

    constructor() {
        super()
        this.state = {
            withdrawdata : [],
            toml: {},
            loading: 0,
            disablebutton: false,
            pagestatus: 0,
            modal:false,
            open: false,
            selectStyle: {
                control: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 150
                }),
                menu: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 150
                })
            },
            options: [
                { label: "pending", value: "pending" },
                { label: "completed", value: "completed" },
                { label: "failed", value: "failed" },
            ],
            targetOption: {}
        }
    }

    UNSAFE_componentWillMount() {
        let socket = this.props.socket;
        socket.on('mWithdrawed', () => {
            this.props.withdrawget();
        })
        this.props.withdrawget();
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(this.props !== nextProps) {
            this.setState({
                loading: 0,
                disablebutton: false,
                open: false
            })
        }
        if(nextProps.withdrawdata) {
            let arr = [];
            for(let i = 0 ; i < nextProps.withdrawdata.length ; i++) {
                let obj = {
                    'id': nextProps.withdrawdata[i].id,
                    'no': i+1,
                    'name': nextProps.withdrawdata[i].firstname,
                    'email': nextProps.withdrawdata[i].email,
                    'type': nextProps.withdrawdata[i].type,
                    'iban': nextProps.withdrawdata[i].iban,
                    'address': nextProps.withdrawdata[i].address,
                    'amount': nextProps.withdrawdata[i].amount,
                    'currency': nextProps.withdrawdata[i].currency,
                    'status': nextProps.withdrawdata[i].status === "pending" ? 
                                                <Select 
                                                    className="select" 
                                                    autosize={true} 
                                                    styles={this.state.selectStyle} 
                                                    options={this.state.options} 
                                                    onChange={(e) => this.changetarget(e, nextProps.withdrawdata[i].id, nextProps.withdrawdata[i].partner_id, nextProps.withdrawdata[i].amount, nextProps.withdrawdata[i].currency, nextProps.withdrawdata[i].type, nextProps.withdrawdata[i].address)}  
                                                    maxMenuHeight={80} 
                                                    value={this.state.options.filter(item => item.value === nextProps.withdrawdata[i].status)[0]} /> : 
                                                nextProps.withdrawdata[i].status,
                    'createdAt': nextProps.withdrawdata[i].createdAt,
                    'updatedAt': nextProps.withdrawdata[i].updatedAt,
                }
                arr.push(obj); 
            }
            this.setState({withdrawdata: arr});
        }
    }

    changetarget(target, id, partner_id, amount, currency, type, address) {
        this.dialog.show({
            title: 'Are you sure?',
            body: 'Please confirm!',
            actions: [
                Dialog.CancelAction(() => {
                    // me.setState({targetOption: })
                }),
                Dialog.OKAction(() => {
                    // console.log(this.state.targetOption);
                    this.props.withdrawchange({
                        id:id,
                        type:type,
                        address:address,
                        partner_id:partner_id,
                        amount:amount,
                        currency:currency,
                        status:target.value,
                    })
                })
            ],
            bsSize: 'small',
            onHide: () => {}
        })
    }
    
    render () {
        return (
            <div className="d-flex flex-column-fluid justify-content-center pt-18">
                <Dialog ref={(component) => { this.dialog = component }} />
                <div className="py-8 w-98">
                    <div className="row">
                        <div className="col-lg-12 col-xxl-12">
                            <div className="card card-custom mb-8 mb-lg-0">
                                <div className="card-header border-0 pt-5">
                                    <h3 className="card-title align-items-start flex-column">
                                        <span className="card-label font-weight-bolder text-dark">Withdraw Request</span>
                                    </h3>
                                </div>
                                <div className="card-body">
                                    <div className="row">
                                        <div className="card card-custom wave wave-animate-slow wave-primary mb-8 mb-lg-0 w-100">
                                            <div className="card-body">
                                                <div className="row overflow-auto">
                                                    {
                                                        this.state.withdrawdata.length > 0 ? 
                                                        <Btable withdrawdata={this.state.withdrawdata} />: 
                                                        <h3 className="card-title align-items-center text-center flex-column w-100">
                                                            There is no withdraw request.
                                                        </h3>
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function walletget(state) {
    return {
        socket: state.socket.socket,
        withdrawdata: state.admin.withdrawdata,
    }
}

export default connect(walletget, { withdrawget, withdrawchange })(ADWithdraw);