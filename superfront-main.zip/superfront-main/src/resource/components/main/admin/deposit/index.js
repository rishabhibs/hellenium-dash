import React from 'react';
import { connect } from "react-redux";
import Select from 'react-select'
import Dialog from 'react-bootstrap-dialog'

import Btable from './b_table';
import { depositsget, depositschange } from '../../../../../redux/actions/admin';
// import Button from '@material-ui/core/Button';
import "../../../../../assets/scss/simpleStyle.scss";

class ADeposit extends React.Component {

    constructor() {
        super()
        this.state = {
            depositsdata: [],
            toml: {},
            loading: 0,
            disablebutton: false,
            pagestatus: 0,
            modal: false,
            ModalHeader: "Edit User",
            editinguser: {},
            open: false,
            selectStyle: {
                control: base => ({
                    ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 150
                }),
                menu: base => ({
                    ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 150
                })
            },
            options: [
                { label: "pending", value: "pending" },
                { label: "completed", value: "completed" },
                { label: "failed", value: "failed" },
            ],
            targetOption: {}
        }
    }

    UNSAFE_componentWillMount() {
        let socket = this.props.socket;
        socket.on('mDeposited', () => {
            this.props.depositsget();
        })
        this.props.depositsget();
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if (this.props !== nextProps) {
            this.setState({
                loading: 0,
                disablebutton: false,
                open: false
            })
        }
        if (nextProps.depositsdata) {
            let arr = [];
            for (let i = 0; i < nextProps.depositsdata.length; i++) {
                let obj = {
                    'id': nextProps.depositsdata[i].id,
                    'no': i + 1,
                    'name': nextProps.depositsdata[i].firstname,
                    'email': nextProps.depositsdata[i].email,
                    'iban': nextProps.depositsdata[i].iban,
                    'amount': nextProps.depositsdata[i].amount,
                    'currency': nextProps.depositsdata[i].currency,
                    'status': nextProps.depositsdata[i].status === "pending" ? <Select className="select" autosize={true} styles={this.state.selectStyle} options={this.state.options} onChange={(e) => this.changetarget(e, nextProps.depositsdata[i].id, nextProps.depositsdata[i].partner_id, nextProps.depositsdata[i].amount, nextProps.depositsdata[i].currency)} maxMenuHeight={80} value={this.state.options.filter(item => item.value === nextProps.depositsdata[i].status)[0]} /> : nextProps.depositsdata[i].status,
                    'createdAt': nextProps.depositsdata[i].createdAt,
                    'updatedAt': nextProps.depositsdata[i].updatedAt,
                }
                arr.push(obj);
            }
            this.setState({ depositsdata: arr });
        }
    }

    changetarget(target, id, partner_id, amount, currency) {
        this.dialog.show({
            title: 'Are you sure?',
            body: 'Please confirm!',
            actions: [
                Dialog.CancelAction(() => {
                    // me.setState({targetOption: })
                }),
                Dialog.OKAction(() => {
                    // console.log(this.state.targetOption);
                    this.props.depositschange({
                        id: id,
                        partner_id: partner_id,
                        amount: amount,
                        currency: currency,
                        status: target.value,
                    })
                })
            ],
            bsSize: 'small',
            onHide: () => { }
        })
    }

    edit(user) {
        this.setState({ editinguser: user, open: true });
    }

    edituser() {
        this.setState({
            loading: 1,
            disablebutton: true
        })
        this.props.EditUser(this.state.editinguser);
    }

    cancel() {
        this.setState({ open: false });
    }

    deleteuser(partner_id) {
        this.props.DeleteUser(partner_id);
    }

    activewallets(publickey) {
        this.props.activewallet(publickey);
    }

    toggle = () => {
        this.setState({
            modal: false
        });
    }

    render() {
      console.log("this.state.usersdata  ",this.state.depositsdata);
        return (
            <div className="transaction-history-section">
                <div className="transaction-history-content">
                    <div className="row">
                        <div className="col-md-6">
                            <h2>Deposit confirmation request</h2>
                            <h3>These are list of requests</h3>
                        </div>
                    </div>
                    <div className="request-list-box">
                    {
                  this.state.depositsdata.length > 0 ?
                    this.state.depositsdata.map((element, index) => (
                      <tr>
                        <td className="date-td">
                          <span className="month">{index+1}</span>
                        </td>
                        <td className="name-td">
                          <span className="name-span">{element.amount}</span>
                        </td>
                        <td className="surname-td">
                          <span className="surname-span">{element.currency}</span>
                        </td>
                        <td className="user-date-td">
                          <span>{element.createdAt}</span>
                        </td>
                        <td className="user-action-td">
                          <div className="dropdown">
                            <a className href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              <img src="/assets/img/action-icon.png" alt="" />
                            </a>
                            <div className="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink" x-placement="bottom-end" style={{ position: 'absolute', transform: 'translate3d(6px, 23px, 0px)', top: '0px', left: '0px', willChange: 'transform' }}>
                              <a className="dropdown-item" href="#">delete</a>
                              <a className="dropdown-item" href="#">view</a>
                              <a className="dropdown-item" href="#">Edit</a>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))
                    :
                     (                    
                      <>
                        <img src="/assets/img/no-request-img.png" className="no-req-img" alt="" />
                        <h3>There are no requests for confirmation</h3>
                        </>
                   )
                }      
                    </div>
                </div>
            </div>

        )
    }
}

function walletget(state) {
    return {
        socket: state.socket.socket,
        depositsdata: state.admin.depositsdata,
    }
}

export default connect(walletget, { depositsget, depositschange })(ADeposit);