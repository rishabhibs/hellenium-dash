import React from 'react';
import { connect } from "react-redux";
import Select from 'react-select'
import Dialog from 'react-bootstrap-dialog'

import Btable from './b_table';
import { depositsget, depositschange } from '../../../../../redux/actions/admin';
// import Button from '@material-ui/core/Button';
import "../../../../../assets/scss/simpleStyle.scss";

class ADeposit extends React.Component {

    constructor() {
        super()
        this.state = {
            depositsdata : [],
            toml: {},
            loading: 0,
            disablebutton: false,
            pagestatus: 0,
            modal:false,
            ModalHeader: "Edit User",
            editinguser: {},
            open: false,
            selectStyle: {
                control: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 150
                }),
                menu: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 150
                })
            },
            options: [
                { label: "pending", value: "pending" },
                { label: "completed", value: "completed" },
                { label: "failed", value: "failed" },
            ],
            targetOption: {}
        }
    }

    UNSAFE_componentWillMount() {
        let socket = this.props.socket;
        socket.on('mDeposited', () => {
            this.props.depositsget();
        })
        this.props.depositsget();
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(this.props !== nextProps) {
            this.setState({
                loading: 0,
                disablebutton: false,
                open: false
            })
        }
        if(nextProps.depositsdata) {
            let arr = [];
            for(let i = 0 ; i < nextProps.depositsdata.length ; i++) {
                let obj = {
                    'id': nextProps.depositsdata[i].id,
                    'no': i+1,
                    'name': nextProps.depositsdata[i].firstname,
                    'email': nextProps.depositsdata[i].email,
                    'iban': nextProps.depositsdata[i].iban,
                    'amount': nextProps.depositsdata[i].amount,
                    'currency': nextProps.depositsdata[i].currency,
                    'status': nextProps.depositsdata[i].status === "pending" ? <Select className="select" autosize={true} styles={this.state.selectStyle} options={this.state.options} onChange={(e) => this.changetarget(e, nextProps.depositsdata[i].id, nextProps.depositsdata[i].partner_id, nextProps.depositsdata[i].amount, nextProps.depositsdata[i].currency)}  maxMenuHeight={80} value={this.state.options.filter(item => item.value === nextProps.depositsdata[i].status)[0]} /> : nextProps.depositsdata[i].status,
                    'createdAt': nextProps.depositsdata[i].createdAt,
                    'updatedAt': nextProps.depositsdata[i].updatedAt,
                }
                arr.push(obj);
            }
            this.setState({depositsdata: arr});
        }
    }

    changetarget(target, id, partner_id, amount, currency) {
        this.dialog.show({
            title: 'Are you sure?',
            body: 'Please confirm!',
            actions: [
                Dialog.CancelAction(() => {
                    // me.setState({targetOption: })
                }),
                Dialog.OKAction(() => {
                    // console.log(this.state.targetOption);
                    this.props.depositschange({
                        id:id,
                        partner_id:partner_id,
                        amount:amount,
                        currency:currency,
                        status:target.value,
                    })
                })
            ],
            bsSize: 'small',
            onHide: () => {}
        })
    }

    edit(user) {
        this.setState({editinguser: user, open:true});
    }

    edituser() {
        this.setState({
            loading: 1,
            disablebutton: true
        })
        this.props.EditUser(this.state.editinguser);
    }

    cancel() {
        this.setState({open: false});
    }
    
    deleteuser(partner_id) {
        this.props.DeleteUser(partner_id);
    }

    activewallets(publickey) {
        this.props.activewallet(publickey);
    }

    toggle = () => {
        this.setState({
            modal:false
        });
    }

    render () {
        return (
            <div className="d-flex flex-column-fluid justify-content-center pt-18">
                <Dialog ref={(component) => { this.dialog = component }} />
                <div className="py-8 w-98">
                    <div className="row">
                        <div className="col-lg-12 col-xxl-12">
                            <div className="card card-custom mb-8 mb-lg-0">
                                <div className="card-header border-0 pt-5">
                                    <h3 className="card-title align-items-start flex-column">
                                        <span className="card-label font-weight-bolder text-dark">Deposit Request</span>
                                    </h3>
                                </div>
                                <div className="card-body">
                                    <div className="row">
                                        <div className="card card-custom wave wave-animate-slow wave-primary mb-8 mb-lg-0 w-100">
                                            <div className="card-body">
                                                <div className="row overflow-auto">
                                                    {
                                                        this.state.depositsdata.length > 0 ? 
                                                        <Btable depositsdata={this.state.depositsdata} />: 
                                                        <h3 className="card-title align-items-center text-center flex-column w-100">
                                                            There is no deposit request.
                                                        </h3>
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function walletget(state) {
    return {
        socket: state.socket.socket,
        depositsdata: state.admin.depositsdata,
    }
}

export default connect(walletget, { depositsget, depositschange })(ADeposit);