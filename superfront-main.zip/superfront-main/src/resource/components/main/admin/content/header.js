import React from 'react';
import Cookies from 'universal-cookie';
import { connect } from 'react-redux';

import config from '../../../../../config';
import { history } from '../../../../history';
import { socketconnect } from '../../../../../redux/actions/auth';

import "../../../../../assets/scss/simpleStyle.scss";

class Header extends React.Component {

    constructor() {
        super()
        this.state = {
            firstname: '',
            lastname: '',
            email: '',
            phonenumber: '',
            public_key: ''
        }
    }

    UNSAFE_componentWillMount() {
        this.props.socketconnect('admin');
    }

    gotopage(num) {
        if (num === 1) {
            history.push('/admin/users');
        } else if (num === 2) {
            history.push('/admin/deposit');
        } else if (num === 3) {
            history.push('/admin/withdraw');
        } else if (num === 4) {
            history.push('/admin/buy');
        } else if (num === 5) {
            history.push('/admin/sell');
        } else {
            const cookies = new Cookies();
            if (config.dev === true) {
                cookies.remove('adtoken', { path: '/', domain: 'localhost' });
            } else {
                cookies.remove('adtoken', { path: '/', domain: 'hellenium.com' });
            }
            history.push('/admin/signout');
        }
    }

    render() {
        return (

            <nav className="navbar sticky-top top-menu flex-md-nowrap">
                <div className="admin-logo">
                    <h1>Admin Panel</h1>
                </div>
                <ul className="admin-menu-bar">
                    <li className="active"><a onClick={() => this.gotopage(1)}>User Manage</a></li>
                    <li><a onClick={() => this.gotopage(2)}>Deposit Request</a></li>
                    <li><a onClick={() => this.gotopage(3)}>Withdraw Request</a></li>
                    <li><a onClick={() => this.gotopage(5)}>Sell View</a></li>
                    <li><a onClick={() => this.gotopage(4)}>Buy View</a></li>
                </ul>
                <ul className="navbar-nav">
                    <li className="nav-item text-nowrap">
                        <a className="profile-pic-link" href="#"><img src="/assets/img/profile-img.png" alt="" /></a>
                    </li>
                </ul>
            </nav>

        )
    }
}

export default connect(null, { socketconnect })(Header);