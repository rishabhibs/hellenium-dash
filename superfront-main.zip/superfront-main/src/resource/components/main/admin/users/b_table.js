import React from 'react'
import { MDBDataTable } from 'mdbreact'

const commonCol = [
    {
        label: 'No',
        field: 'index',
        sort: 'asc',
    },
    {
        label: 'First Name',
        field: 'firstname',
        sort: 'asc',
    },
    {
        label: 'Last Name',
        field: 'lastname',
        sort: 'asc',
    },
    {
        label: 'Email',
        field: 'email',
        sort: 'asc',
    },
    {
        label: 'Phone Number',
        field: 'phone',
        sort: 'asc',
    },
    {
        label: 'KYC status',
        field: 'kyc_status',
        sort: 'asc',
    },
    {
        label: 'Wallet Name',
        field: 'walletname',
        sort: 'asc',
    },
    {
        label: 'Wallet Address',
        field: 'public_key',
        sort: 'asc',
    },
    {
        label: 'Created Date',
        field: 'createdAt',
        sort: 'asc',
    },
    {
        label: 'Edit',
        field: 'edit',
        sort: 'asc',
    },
    {
        label: 'Delete',
        field: 'delete',
        sort: 'asc',
    }
]

class Btable extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data : {
                columns: commonCol,
                rows: props.usersdata
            }   
        }
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(nextProps !== this.props){
            this.setState({
                data: {
                    columns: commonCol,
                    rows: nextProps.usersdata
                }
            });
        }
    }

    render() {
        return (
            <MDBDataTable
                striped
                bordered
                small
                hover
                className="w-98"
                data={this.state.data}
            />
        );
    }
}

export default Btable;