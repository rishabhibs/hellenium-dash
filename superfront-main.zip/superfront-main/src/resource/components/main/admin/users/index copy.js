import React from 'react';
import { connect } from "react-redux";
import EditviewM from './editview';
import Btable from './b_table';
import { getusers, DeleteUser, EditUser } from '../../../../../redux/actions/admin';
import Button from '@material-ui/core/Button';
import Dialog from 'react-bootstrap-dialog'

import "../../../../../assets/scss/simpleStyle.scss";

class Users extends React.Component {

    constructor() {
        super()
        this.state = {
            usersdata : [],
            toml: {},
            loading: 0,
            disablebutton: false,
            pagestatus: 0,
            modal:false,
            ModalHeader: "Edit User",
            editinguser: {},
            open: false,
        }
    }

    UNSAFE_componentWillMount() {
        let socket = this.props.socket;
        socket.on('mRegistered', () => {
            this.props.getusers();
        })
        this.props.getusers();
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(this.props !== nextProps) {
            this.setState({
                loading: 0,
                disablebutton: false,
                open: false
            })
        }
        if(nextProps.usersdata) {
            var alldata = [];
            for(let i = 0 ; i < nextProps.usersdata.result.users.length ; i++) {
                let user = nextProps.usersdata.result.users[i];
                user['index'] = i + 1;
                if(user.kyc_status === true) {
                    user.kyc_status = "true";
                }
                let walletform = nextProps.usersdata.result.wallets.filter(item => item.partner_id === `${user.id}` );
                if(walletform.length > 0) {
                    user['walletname'] = walletform[0].walletname;
                    user['public_key'] = walletform[0].public_key;
                } else {
                    user['walletname'] = null;
                    user['public_key'] = null;
                }
                user['edit'] = <Button variant="contained" color="primary" onClick={() => this.edit(user)}>Edit</Button>;
                user['delete'] = <Button variant="contained" color="secondary" onClick={() => this.deleteuser(user.id)}>Delete</Button>;
                alldata.push(user);
            }
            this.setState({usersdata: alldata})
        }
    }

    edit(user) {
        this.setState({editinguser: user, open:true});
    }

    edituser() {
        this.setState({
            loading: 1,
            disablebutton: true
        })
        this.props.EditUser(this.state.editinguser);
    }

    cancel() {
        this.setState({open: false});
    }
    
    deleteuser(partner_id) {
        this.dialog.show({
            title: 'Are you sure?',
            body: 'Please confirm!',
            actions: [
                Dialog.CancelAction(() => {
                    // me.setState({targetOption: })
                }),
                Dialog.OKAction(() => {
                    this.props.DeleteUser(partner_id);
                })
            ],
            bsSize: 'small',
            onHide: () => {}
        })
    }

    activewallets(publickey) {
        this.props.activewallet(publickey);
    }

    toggle = () => {
        this.setState({
            modal:false
        });
    }

    render () {
        return (
            <div className="d-flex flex-column-fluid justify-content-center pt-18">
                <EditviewM parent={this} open={this.state.open} />
                <Dialog ref={(component) => { this.dialog = component }} />
                <div className="w-98 py-8">
                    <div className="row">
                        <div className="col-lg-12 col-xxl-12">
                            <div className="card card-custom mb-8 mb-lg-0">
                                <div className="card-header border-0 pt-5">
                                    <h3 className="card-title align-items-start flex-column">
                                        <span className="card-label font-weight-bolder text-dark">Users</span>
                                    </h3>
                                </div>
                                <div className="card-body">
                                    <div className="row">
                                        <div className="card card-custom wave wave-animate-slow wave-primary mb-8 mb-lg-0 w-100">
                                            <div className="card-body">
                                                <div className="row overflow-auto">
                                                    {
                                                        this.state.usersdata.length > 0 ? 
                                                        <Btable usersdata={this.state.usersdata} />: 
                                                        <h3 className="card-title align-items-center text-center flex-column w-100">
                                                            There is no users.
                                                        </h3>
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function walletget(state) {
    return {
        socket: state.socket.socket,
        usersdata: state.admin.usersdata,
    }
}

export default connect(walletget, { getusers, DeleteUser, EditUser })(Users);