import React from 'react';
import { connect } from "react-redux";
import EditviewM from './editview';
import Btable from './b_table';
import { getusers, DeleteUser, EditUser } from '../../../../../redux/actions/admin';
import Button from '@material-ui/core/Button';
import Dialog from 'react-bootstrap-dialog'

import "../../../../../assets/scss/simpleStyle.scss";

class Users extends React.Component {

  constructor() {
    super()
    this.state = {
      usersdata: [],
      toml: {},
      loading: 0,
      disablebutton: false,
      pagestatus: 0,
      modal: false,
      ModalHeader: "Edit User",
      editinguser: {},
      open: false,
    }
  }

  UNSAFE_componentWillMount() {
    let socket = this.props.socket;
    socket.on('mRegistered', () => {
      this.props.getusers();
    })
    this.props.getusers();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      this.setState({
        loading: 0,
        disablebutton: false,
        open: false
      })
    }
    if (nextProps.usersdata) {
      var alldata = [];
      for (let i = 0; i < nextProps.usersdata.result.users.length; i++) {
        let user = nextProps.usersdata.result.users[i];
        user['index'] = i + 1;
        if (user.kyc_status === true) {
          user.kyc_status = "true";
        }
        let walletform = nextProps.usersdata.result.wallets.filter(item => item.partner_id === `${user.id}`);
        if (walletform.length > 0) {
          user['walletname'] = walletform[0].walletname;
          user['public_key'] = walletform[0].public_key;
        } else {
          user['walletname'] = null;
          user['public_key'] = null;
        }
        user['edit'] = <Button variant="contained" color="primary" onClick={() => this.edit(user)}>Edit</Button>;
        user['delete'] = <Button variant="contained" color="secondary" onClick={() => this.deleteuser(user.id)}>Delete</Button>;
        alldata.push(user);
      }
      this.setState({ usersdata: alldata })
    }
  }

  edit(user) {
    this.setState({ editinguser: user, open: true });
  }

  edituser() {
    this.setState({
      loading: 1,
      disablebutton: true
    })
    this.props.EditUser(this.state.editinguser);
  }

  cancel() {
    this.setState({ open: false });
  }

  deleteuser(partner_id) {
    this.dialog.show({
      title: 'Are you sure?',
      body: 'Please confirm!',
      actions: [
        Dialog.CancelAction(() => {
          // me.setState({targetOption: })
        }),
        Dialog.OKAction(() => {
          this.props.DeleteUser(partner_id);
        })
      ],
      bsSize: 'small',
      onHide: () => { }
    })
  }

  activewallets(publickey) {
    this.props.activewallet(publickey);
  }

  toggle = () => {
    this.setState({
      modal: false
    });
  }

  render() {
    console.log("this.state.usersdata  ",this.state.usersdata);
    return (

      <div className="transaction-history-section">
        <div className="transaction-history-content">
          <div className="row">
            <div className="col-md-6">
              <h2>Users</h2>
              <h3>These are list of users</h3>
            </div>
            <div className="col-md-6 timing-tab-box">
              <div className="form-box">
                <input type="search" id="search" className="form-control" placeholder="Search" />
              </div>
            </div>
          </div>
          <div className="transaction-history-table table-responsive">
            <table className="table">
              <tbody>
                {/*Row start*/}

                {
                  this.state.usersdata.length > 0 ?
                    this.state.usersdata.map((element, index) => (
                      <tr>
                        <td className="date-td">
                          <span className="month">{index+1}</span>
                        </td>
                        <td className="name-td">
                          <span className="name-span">{element.firstname}</span>
                        </td>
                        <td className="surname-td">
                          <span className="surname-span">{element.email}</span>
                        </td>
                        <td className="user-date-td">
                          <h3>{element.createdAt}</h3>
                        </td>
                        <td className="user-action-td">
                          <div className="dropdown">
                            <a className href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              <img src="/assets/img/action-icon.png" alt="" />
                            </a>
                            <div className="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink" x-placement="bottom-end" /* style={{ position: 'absolute', transform: 'translate3d(6px, 23px, 0px)', top: '0px', left: '0px', willChange: 'transform' }} */>
                              <a className="dropdown-item" href="#">delete</a>
                              <a className="dropdown-item" href="#">view</a>
                              <a className="dropdown-item" href="#">Edit</a>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))
                    :
                    // (
                    <h3 className="card-title align-items-center text-center flex-column w-100">
                      There is no users.
                    </h3>
                  // )
                }



              </tbody>
            </table>
          </div>
        </div>
      </div>


    )
  }
}

function walletget(state) {
  return {
    socket: state.socket.socket,
    usersdata: state.admin.usersdata,
  }
}

export default connect(walletget, { getusers, DeleteUser, EditUser })(Users);