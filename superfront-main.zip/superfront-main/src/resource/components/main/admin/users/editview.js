import React from 'react';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import { useSpring, animated } from 'react-spring/web.cjs'; // web.cjs is required for IE 11 support
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import EmailIcon from '@material-ui/icons/Email';
import PhoneForwardedIcon from '@material-ui/icons/PhoneForwarded';
import Grid from '@material-ui/core/Grid';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import LastPageIcon from '@material-ui/icons/LastPage';
import Spinner from 'react-bootstrap/Spinner';

const useStyles = makeStyles((theme) => ({
  modal: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  paper: {
    backgroundColor: theme.palette.background.paper,
    border: '2px solid #000',
    boxShadow: theme.shadows[5],
    padding: theme.spacing(2, 4, 3),
  },
  margin: {
    margin: theme.spacing(1),
  },
}));

const Fade = React.forwardRef(function Fade(props, ref) {
  const { in: open, children, onEnter, onExited, ...other } = props;
  const style = useSpring({
    from: { opacity: 0 },
    to: { opacity: open ? 1 : 0 },
    onStart: () => {
      if (open && onEnter) {
        onEnter();
      }
    },
    onRest: () => {
      if (!open && onExited) {
        onExited();
      }
    },
  });

  return (
    <animated.div ref={ref} style={style} {...other}>
      {children}
    </animated.div>
  );
});

Fade.propTypes = {
  children: PropTypes.element,
  in: PropTypes.bool.isRequired,
  onEnter: PropTypes.func,
  onExited: PropTypes.func,
};

export default function EditviewM(props) {
  const classes = useStyles();

  const handleClose = () => {
    props.parent.setState({open: false});
  };

  return (
    <div>
      <Modal
        aria-labelledby="spring-modal-title"
        aria-describedby="spring-modal-description"
        className={classes.modal}
        open={props.open}
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 200,
        }}
      >
        <Fade in={props.open}>
          <div className={classes.paper}>
            <h2 id="spring-modal-title">Edit User</h2>
            <div className={classes.margin}>
                <Grid container spacing={1} alignItems="flex-end">
                    <Grid item>
                        <FirstPageIcon />
                    </Grid>
                    <Grid item>
                        <TextField 
                            label="First Name" 
                            defaultValue={props.parent.state.editinguser.firstname} 
                            onChange={(e) => {
                                let obj = props.parent.state.editinguser;
                                obj.firstname = e.target.value;
                                props.parent.setState({editinguser: obj})
                            }} 
                        />
                    </Grid>
                </Grid>
            </div>
            <div className={classes.margin}>
                <Grid container spacing={1} alignItems="flex-end">
                    <Grid item>
                        <LastPageIcon />
                    </Grid>
                    <Grid item>
                        <TextField 
                            label="Last Name" 
                            defaultValue={props.parent.state.editinguser.lastname} 
                            onChange={(e) => {
                                let obj = props.parent.state.editinguser;
                                obj.lastname = e.target.value;
                                props.parent.setState({editinguser: obj})
                            }} 
                        />
                    </Grid>
                </Grid>
            </div>
            <div className={classes.margin}>
                <Grid container spacing={1} alignItems="flex-end">
                    <Grid item>
                        <EmailIcon />
                    </Grid>
                    <Grid item>
                        <TextField 
                            label="Email" 
                            defaultValue={props.parent.state.editinguser.email} 
                            onChange={(e) => {
                                let obj = props.parent.state.editinguser;
                                obj.email = e.target.value;
                                props.parent.setState({editinguser: obj})
                            }} 
                        />
                    </Grid>
                </Grid>
            </div>
            <div className={classes.margin}>
                <Grid container spacing={1} alignItems="flex-end">
                    <Grid item>
                        <PhoneForwardedIcon />
                    </Grid>
                    <Grid item>
                        <TextField 
                            label="Phone Number" 
                            defaultValue={props.parent.state.editinguser.phone} 
                            onChange={(e) => {
                                let obj = props.parent.state.editinguser;
                                obj.phone = e.target.value;
                                props.parent.setState({editinguser: obj})
                            }} 
                        />
                    </Grid>
                </Grid>
            </div>
            <div className={classes.margin}>
                <Grid container spacing={1} alignItems="flex-end">
                    <Grid item>
                        <Button variant="contained" color="primary" disabled={props.parent.state.disablebutton} onClick={() => props.parent.edituser()}>
                            { props.parent.state.loading === 0 ? "Save" : <Spinner animation="border" /> }
                        </Button>
                    </Grid>
                    <Grid item>
                        <Button variant="contained" color="primary" disabled={props.parent.state.disablebutton} onClick={() => props.parent.cancel()}>
                            { props.parent.state.loading === 0 ? "Cancel" : <Spinner animation="border" /> }
                        </Button>
                    </Grid>
                </Grid>
            </div>
          </div>
        </Fade>
      </Modal>
    </div>
  );
}
