import React from 'react';
import Searchtab from './searchtab';

class Search extends React.Component {
    constructor() {
        super();
        this.state = {
            tabledata: {}
        }
    }
    
    UNSAFE_componentWillMount() {
        var mainobj = {
            columns: [
                {
                  label: 'Name',
                  field: 'name',
                  sort: 'asc',
                  width: 150
                },
                {
                  label: 'Position',
                  field: 'position',
                  sort: 'asc',
                  width: 270
                },
                {
                  label: 'Office',
                  field: 'office',
                  sort: 'asc',
                  width: 200
                },
                {
                  label: 'Age',
                  field: 'age',
                  sort: 'asc',
                  width: 100
                },
                {
                  label: 'Start date',
                  field: 'date',
                  sort: 'asc',
                  width: 150
                },
                {
                  label: 'Salary',
                  field: 'salary',
                  sort: 'asc',
                  width: 100
                },
                {
                  label: 'Action',
                  field: 'action',
                  sort: 'asc',
                  width: 50
                }
              ],
              rows: []
        }
        for(var i = 0 ; i < 100 ; i++) {
            var obj = {
              name: 'Tiger Nixon'+i,
              position: 'System Architect'+i,
              office: 'Edinburgh'+i,
              age: '61',
              date: '2011/04/25'+i,
              salary: '$320'+i,
              action: <button class="btn btn-primary">Edit user</button>
            };
            mainobj.rows.push(obj);
          } 
        this.setState({ tabledata : mainobj});
    }
    render () {
        return (
            <div className="d-flex flex-column-fluid">
                <div className="container py-8">
                    <div className="row">
                        <div className="col-lg-6 col-xxl-12">
                            <div className="card card-custom mb-8 mb-lg-0">
                                <Searchtab tabledata={this.state.tabledata} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Search;