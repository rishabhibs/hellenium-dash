import React from 'react';
import { MDBDataTable } from 'mdbreact';

const Searchtable = (props) => {
  return (
    <MDBDataTable
      striped
      bordered
      small
      data={props.tabledata}
    />
  );
}

export default Searchtable;