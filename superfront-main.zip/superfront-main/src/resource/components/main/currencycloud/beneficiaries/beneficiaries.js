import React from 'react';
// import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { getbeneficiaries } from '../../../../../redux/actions/beneficiaries';
import { toAbsoluteUrl } from "../../../../../layouts/_helpers";
import SVG from "react-inlinesvg";
import { history } from '../../../../history';
import BeneficiariesList from  './beneficiariesList';
import Spinner from "../../../../Loading-spinner";

class Beneficiaries extends React.Component {

    constructor() {
        super();
        this.state = {
            beneficiaries: 0,
            status: 0
        };
    }

    componentDidMount() {
        this.props.getbeneficiaries();
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        this.setState({status: 1});
        if(nextProps.beneficiaries.beneficiaries) {
            this.setState({beneficiaries: nextProps.beneficiaries.beneficiaries});
        }
    }

    addben() {
        history.push('/currencycloud/addbeneficiaries');
    }

    render () {
        return (
            <>
                { this.state.status === 0 ? <Spinner />  :
                    this.state.beneficiaries.length > 0 ? 
                    <> 
                        <button onClick={() => this.addben()} className="btn btn-success btn-shadow-hover font-weight-bolder w-100 py-3">Add Beneficiary</button> 
                        <BeneficiariesList beneficiaries={this.state.beneficiaries} /> 
                    </> : 
                    <div className="row m-0" style={{ textAlign: "center", justifyContent: "center" }}>
                        <div className="col-md-4 col-lg-4">
                            <div className="card card-custom">
                                <div className="card-header border-0 pt-5">
                                    <h3 className="card-title font-weight-bolder ">Add Beneficiary</h3>
                                </div>
                                <div className="card-body d-flex flex-column">
                                    <div className="flex-grow-1">
                                        <SVG src={toAbsoluteUrl("/assets/media/svg/icons/Communication/Address-card.svg")} style={{ width: '100%' }} className="h-50 align-self-center bg-secondary"></SVG>
                                    </div>
                                    <div className="pt-5">
                                    <p className="text-center font-weight-normal font-size-lg pb-7">
                                        You do not have any beneficiaries at the moment!
                                    </p>
                                    <button onClick={() => this.addben()} className="btn btn-success btn-shadow-hover font-weight-bolder w-100 py-3">Add Beneficiary</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                }
            </>
        )
    }
}

function done(state) {
    return {
        beneficiaries: state.main.data
    }
}

export default connect(done, {getbeneficiaries})(Beneficiaries);