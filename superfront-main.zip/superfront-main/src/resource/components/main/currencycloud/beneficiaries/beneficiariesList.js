import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Avatar from '@material-ui/core/Avatar';
import Divider from '@material-ui/core/Divider';
// import AddIcon from '@material-ui/icons/Add';
import AddShoppingCartIcon from '@material-ui/icons/AddShoppingCart';
// import SVG from "react-inlinesvg";
// import { toAbsoluteUrl } from "../../../../layouts/_helpers";

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
    backgroundColor: theme.palette.background.purple,
  },
}));

export default function BeneficiariesList(props) {
  const classes = useStyles();

  return (
    <List className={classes.root}>
      {props.beneficiaries.map((item) => { 
        return <>
            <Divider variant="inset" component="li" />
              <ListItem>
                <ListItemAvatar>
                  <Avatar>
                    <AddShoppingCartIcon />
                  </Avatar>
                </ListItemAvatar>
                <ListItem button>
                    <ListItemText primary={item.name} secondary={'currency '+ item.currency} />
                </ListItem>
              </ListItem>
            </>
      })}
    </List>
  );
}