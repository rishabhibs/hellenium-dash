import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Avatar from '@material-ui/core/Avatar';
import Divider from '@material-ui/core/Divider';
import AddIcon from '@material-ui/icons/Add';
import AddShoppingCartIcon from '@material-ui/icons/AddShoppingCart';
// import SVG from "react-inlinesvg";
// import { toAbsoluteUrl } from "../../../../layouts/_helpers";

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
    backgroundColor: theme.palette.background.purple,
  },
}));

export default function BalanceList(props) {
  const classes = useStyles();

  return (
    <List className={`${classes.root} w-100`}>
      <ListItem key='title'>
          <ListItemAvatar>
          <Avatar>
              <AddIcon />
          </Avatar>
          </ListItemAvatar>
          <ListItem button>
              <ListItemText primary="Add" secondary="new balance" />
          </ListItem>
      </ListItem>
      <Divider variant="inset" component="li" key="driver 1" />
      <Divider variant="inset" component="li" key="driver 2" />
      {/* {props.balances.map((item, index) => { 
        return <>
            <Divider variant="inset" component="li" key={`driver ${index}`} />
            <ListItem key={index}>
              <ListItemAvatar>
                <Avatar>
                  <AddShoppingCartIcon />
                </Avatar>
              </ListItemAvatar>
              <ListItem button>
                  <ListItemText primary={item.currency} secondary={'amount '+ item.amount} />
              </ListItem>
            </ListItem>
          </>
      })} */}
    </List>
  );
}