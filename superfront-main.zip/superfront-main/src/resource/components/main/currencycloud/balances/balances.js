import React from 'react';
// import { Link } from 'react-router-dom';
import BalanceList from './balanceList';
import Spinner from "../../../../Loading-spinner";

import { connect } from 'react-redux';
import { getbalances } from '../../../../../redux/actions/balances';

class Balances extends React.Component {

    constructor() {
        super();
        this.state = {
            balances: [],
            status: 0
        }
    }

    componentDidMount() {
        this.props.getbalances();
    }
    
    UNSAFE_componentWillReceiveProps(nextProps) {
        this.setState({status: 1});
        var balances = nextProps.balances.data.data.balances;
        if(balances.length > 0) {
            this.setState({balances: balances});
        }
    }

    addbanances() {
        // console.log('hola');
    }
    
    render () {
        return (
            <div className="d-flex flex-column-fluid w-100">
                {this.state.status === 0 ? <Spinner /> : <BalanceList balances={this.state.balances} />}
            </div>
        )
    }
}

function balances(state) {
    return {
        balances: state.main
    }
}

export default connect(balances, {getbalances})(Balances);