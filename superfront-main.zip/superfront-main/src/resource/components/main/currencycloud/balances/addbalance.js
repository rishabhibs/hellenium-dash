import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { getbalances, addbalances } from '../../../../../redux/actions/balances';
// import { toAbsoluteUrl } from "../../../../layouts/_helpers";
// import SVG from "react-inlinesvg";
import '../../../../../assets/css/beneficiaries.css';
import CountrySelector from '../../utils/countryselector';
import CurrencySelector from '../../utils/currencySelector';
import config from '../../../../../config';

class AddBalances extends React.Component {

    constructor() {
        super();
        this.state = {
            stage: 1,
            focus: 0,
            error: 0,
            bnname: '',
            hname: '',
            country: '',
            currency: '',
            benenickname: '',
            benecountry: '',
            currency: '',
            holdername: '',
            type: '',
            IBAN: '',
            BICSWIFT: '',
            fname: '',
            lname: '',
            address: '',
            city: '',
        };
    }

    nextBtn() {
        var num = this.state.stage + 1;
        if(this.state.stage !== 4) {
            this.setState({stage: num});
        }
    }

    prevBtn() {
        var num = this.state.stage - 1;
        if(num !== 0) {
            this.setState({stage: num});
        }
    }

    onBlur(e) {
        if(e.target.value === "")
        {
            this.setState({focus: 0}); 
        }
    }

    Focus(value, num) {
        this.setState({focus: num});
        if(value === "") {
            this.setState({error: num});
        }
    }

    onChange(val) {
        this.setState({currency: val.target.value});
    }

    changeCountry(val) {
        this.setState({country: val.label});
    }

    addbenandpay() {
        var obj = {
            header: {
                'X-Auth-Token': config.auth_token
            },
            formData: {
                name: this.state.bnname,
                bank_account_holder_name: this.state.hname,
                bank_country: this.state.country,
                currency: this.state.currency,
                currency: this.state.currency,
                currency: this.state.currency,
                currency: this.state.currency,
                currency: this.state.currency,
            }
        }
    }
    
    render () {
        return (
            <section className="wizard-section">
                <div className="row no-gutters">
                    <div className="col-lg-12 col-md-12">
                        <div className="form-wizard">
                            <form action="" method="post" role="form">
                                <div className="form-wizard-header">
                                    <p>Fill all form field to go next step</p>
                                    <ul className="list-unstyled form-wizard-steps clearfix">
                                        <li className={this.state.stage === 1 ? "active" : this.state.stage > 1 ? "activated" : ""}><span>1</span></li>
                                        <li className={this.state.stage === 2 ? "active" : this.state.stage > 2 ? "activated" : ""}><span>2</span></li>
                                        <li className={this.state.stage === 3 ? "active" : this.state.stage > 3 ? "activated" : ""}><span>3</span></li>
                                        <li className={this.state.stage === 4 ? "active" : this.state.stage > 4 ? "activated" : ""}><span>4</span></li>
                                    </ul>
                                </div>
                                <div className={`wizard-fieldset mb-20 ${this.state.stage === 1 ? "show" : ""}`}>
                                    <div className="row">
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Beneficiary Nickname</h3></div>
                                            <div className={this.state.focus === 1 || this.state.bnname !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 1)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'bnname': e.target.value})}}/>
                                                <label htmlFor="bnname" className="wizard-form-text-label">Beneficiary Nick Name*</label>
                                                <div className="wizard-form-error" style={this.state.bnname !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Beneficiary Country</h3></div>
                                            <div className='form-group'>
                                                <CountrySelector changeCountry={(e) => this.changeCountry(e)} />
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Currency</h3></div>
                                            <div className="form-group">
                                                <CurrencySelector onChange={(e) => this.onChange(e)} name={'currency'} />
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Bank Account Holder Name</h3></div>
                                            <div className={this.state.focus === 2 || this.state.hname !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 2)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'hname': e.target.value})}}/>
                                                <label htmlFor="hname" className="wizard-form-text-label">Holder Name*</label>
                                                <div className="wizard-form-error" style={this.state.hname !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Beneficiary Type</h3></div>
                                            <div className="wizard-form-radio">
                                                <input name="radio-name" onChange={() => this.setState({type: 0})} type="radio" />
                                                <label htmlFor="radio1">Company</label>
                                            </div>
                                            <div className="wizard-form-radio">
                                                <input name="radio-name" onChange={() => this.setState({type: 1})} id="radio2" type="radio" />
                                                <label htmlFor="radio2">Individual</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-group clearfix">
                                        <Link to="#" className="form-wizard-previous-btn float-left" onClick={() => {this.prevBtn()}}>Previous</Link>
                                        <Link to="#" className="form-wizard-next-btn float-right" onClick={() => {this.nextBtn()}}>Next</Link>
                                    </div>
                                </div>
                                <div className={`wizard-fieldset mb-20 ${this.state.stage === 2 ? "show" : ""}`}>
                                    <div className="row">
                                        <h3>Priority Payment </h3>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>IBAN</h3></div>
                                            <div className={this.state.focus === 3 || this.state.IBAN !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 3)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'IBAN': e.target.value})}}/>
                                                <label htmlFor="IBAN" className="wizard-form-text-label">IBAN*</label>
                                                <div className="wizard-form-error" style={this.state.IBAN !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>BIC/SWIFT</h3></div>
                                            <div className={this.state.focus === 4 || this.state.BICSWIFT !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 4)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'BICSWIFT': e.target.value})}}/>
                                                <label htmlFor="BICSWIFT" className="wizard-form-text-label">BIC/SWIFT*</label>
                                                <div className="wizard-form-error" style={this.state.BICSWIFT !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>First Name</h3></div>
                                            <div className={this.state.focus === 5 || this.state.fname !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 5)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'fname': e.target.value})}}/>
                                                <label htmlFor="fname" className="wizard-form-text-label">First Name*</label>
                                                <div className="wizard-form-error" style={this.state.fname !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Last Name</h3></div>
                                            <div className={this.state.focus === 6 || this.state.lname !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 6)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'lname': e.target.value})}}/>
                                                <label htmlFor="lname" className="wizard-form-text-label">Last Name*</label>
                                                <div className="wizard-form-error" style={this.state.lname !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Address</h3></div>
                                            <div className={this.state.focus === 7 || this.state.address !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 7)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'address': e.target.value})}}/>
                                                <label htmlFor="address" className="wizard-form-text-label">Address*</label>
                                                <div className="wizard-form-error" style={this.state.address !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>City</h3></div>
                                            <div className={this.state.focus === 8 || this.state.fname !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 8)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'city': e.target.value})}}/>
                                                <label htmlFor="city" className="wizard-form-text-label">City*</label>
                                                <div className="wizard-form-error" style={this.state.fname !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-group clearfix">
                                        <Link to="#" className="form-wizard-previous-btn float-left" onClick={() => {this.prevBtn()}}>Previous</Link>
                                        <Link to="#" className="form-wizard-next-btn float-right" onClick={() => {this.nextBtn()}}>Next</Link>
                                    </div>
                                </div>
                                <div className={`wizard-fieldset pl-48 mb-20 ${this.state.stage === 3 ? "show" : ""}`}>
                                    <div className="row">
                                        <h3><b>You are ready to create Beneficiary!</b></h3><br />
                                    </div>
                                    <div className="row">
                                        <h3>Beneficiary Details</h3>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Address: <b>{this.state.address}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Country: <b>{this.state.benecountry}</b></h4></div>
                                        </div>
                                        <h3>Beneficiary Bank Details</h3>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Currency: <b>{this.state.currency}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Priority: <b>{this.state.type===0? "company": "Individual"}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Address: <b>{this.state.address}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>City: <b>{this.state.city}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Beneficiary Country: <b>{this.state.benecountry}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Company Name:<b>president</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>IBAN:<b>{this.state.IBAN}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>BIC/SWIFT:<b>{this.state.BICSWIFT}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Bank Name:<b>TEST BANK NAME</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Bank Address:<b>Bank Address</b></h4></div>
                                        </div>
                                    </div>
                                    <div className="form-group clearfix">
                                        <Link to="#" className="form-wizard-previous-btn float-left" onClick={() => {this.prevBtn()}}>Previous</Link>
                                        <Link to="#" className="form-wizard-next-btn float-right" onClick={() => {this.nextBtn()}}>Next</Link>
                                    </div>
                                </div>
                                <div className={`wizard-fieldset pl-48 mb-20 ${this.state.stage === 4 ? "show" : ""}`}>
                                    <div className="row">
                                        <h3><b>Success!</b></h3><br />
                                    </div>
                                    <div className="row">
                                        <h3>Beneficiary Details</h3>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Address: <b>{this.state.address}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Country: <b>{this.state.benecountry}</b></h4></div>
                                        </div>
                                        <h3>Beneficiary Bank Details</h3>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Currency: <b>{this.state.currency}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Priority: <b>{this.state.type===0? "company": "Individual"}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Address: <b>{this.state.address}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>City: <b>{this.state.city}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Beneficiary Country: <b>{this.state.benecountry}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Company Name:<b>president</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>IBAN:<b>{this.state.IBAN}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>BIC/SWIFT:<b>{this.state.BICSWIFT}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Bank Name:<b>TEST BANK NAME</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Bank Address:<b>Bank Address</b></h4></div>
                                        </div>
                                    </div>
                                    <div className="form-group clearfix">
                                        <Link to="#" className="form-wizard-previous-btn float-left" onClick={() => {this.prevBtn()}}>Previous</Link>
                                        <Link to="#" className="form-wizard-next-btn float-right" onClick={() => this.addbenandpay()}>Pay</Link>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}

function done(state) {
    return {
        balances: state.main.data
    }
}

export default connect(done, { getbalances, addbalances })(AddBalances);