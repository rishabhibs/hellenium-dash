import React from 'react';
// import { Link } from 'react-router-dom';

class Transactions extends React.Component {
    render () {
        return (
            <div className="d-flex flex-column-fluid">
                <div className="container py-8">
                    <div className="row">
                        <div className="col-lg-6 col-xxl-12">
                            <div className="card card-custom mb-8 mb-lg-0">
                                <div className="card-header border-0 pt-5">
                                    <h3 className="card-title align-items-start flex-column">
                                        <span className="card-label font-weight-bolder text-dark">XML Transfer</span>
                                        <span className="text-muted mt-3 font-weight-bold font-size-sm">you can transfer XML to someone without any issues</span>
                                    </h3>
                                </div>
                                <form className="form">
                                    <div className="card-body wave wave-animate-slow wave-success">
                                        <div className="form-group row text-center mt-20">
                                            <div className="col-lg-3"></div>
                                            <div className="col-lg-6">
                                                <label>XML fee</label>
                                                <span className="form-text text-muted"><h3>1 XML  &  0.083379 XML</h3></span>
                                            </div>
                                        </div>
                                        <div className="form-group row">
                                            <div className="col-lg-6">
                                                <label>XML:</label>
                                                <div className="input-group">
                                                    <input type="text" className="form-control" placeholder="Enter XML"/>
                                                    <div className="input-group-append"><span className="input-group-text">XML</span></div>
                                                </div>
                                                <span className="form-text text-muted">Please enter XML amount to transfer</span>
                                            </div>
                                            <div className="col-lg-6">
                                                <label>Someone's address to transfer XML:</label>
                                                <div className="input-group">
                                                    <input type="text" className="form-control"/>
                                                    <div className="input-group-append">
                                                        <span className="input-group-text">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 25 25" version="1.1">
                                                                <g stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
                                                                    <rect x="0" y="0" width="20px" height="20px"/>
                                                                    <path d="M6,2 L18,2 C19.6568542,2 21,3.34314575 21,5 L21,19 C21,20.6568542 19.6568542,22 18,22 L6,22 C4.34314575,22 3,20.6568542 3,19 L3,5 C3,3.34314575 4.34314575,2 6,2 Z M12,11 C13.1045695,11 14,10.1045695 14,9 C14,7.8954305 13.1045695,7 12,7 C10.8954305,7 10,7.8954305 10,9 C10,10.1045695 10.8954305,11 12,11 Z M7.00036205,16.4995035 C6.98863236,16.6619875 7.26484009,17 7.4041679,17 C11.463736,17 14.5228466,17 16.5815,17 C16.9988413,17 17.0053266,16.6221713 16.9988413,16.5 C16.8360465,13.4332455 14.6506758,12 11.9907452,12 C9.36772908,12 7.21569918,13.5165724 7.00036205,16.4995035 Z" fill="#000000"/>
                                                                </g>
                                                            </svg>
                                                        </span>
                                                    </div>
                                                </div>
                                                <span className="form-text text-muted">You have to pay</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="card-footer">
                                        <div className="row">
                                            <div className="col-lg-12 text-right">
                                                <button type="reset" className="btn btn-primary mr-2">Transfer</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
        )
    }
}

export default Transactions;