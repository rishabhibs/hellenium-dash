import React from 'react';
// import { Link } from 'react-router-dom';
import '../../../../../assets/css/tableStyle.css';
import Onboardingtable from './onboardtable';

class Onboarding extends React.Component {
    constructor() {
        super();
        this.state = {
            tabledata: {}
        }
    }
    
    UNSAFE_componentWillMount() {
        var mainobj = {
            columns: [
                {
                  label: 'Name',
                  field: 'name',
                  sort: 'asc',
                  width: 150
                },
                {
                  label: 'Position',
                  field: 'position',
                  sort: 'asc',
                  width: 270
                },
                {
                  label: 'Office',
                  field: 'office',
                  sort: 'asc',
                  width: 200
                },
                {
                  label: 'Age',
                  field: 'age',
                  sort: 'asc',
                  width: 100
                },
                {
                  label: 'Start date',
                  field: 'date',
                  sort: 'asc',
                  width: 150
                },
                {
                  label: 'Salary',
                  field: 'salary',
                  sort: 'asc',
                  width: 100
                },
                {
                  label: 'Action',
                  field: 'action',
                  sort: 'asc',
                  width: 50
                }
              ],
              rows: []
        }
        for(var i = 0 ; i < 100 ; i++) {
            var obj = {
              name: 'Tiger Nixon'+i,
              position: 'System Architect'+i,
              office: 'Edinburgh'+i,
              age: '61',
              date: '2011/04/25'+i,
              salary: '$320'+i,
              action: <button class="btn btn-primary">Edit user</button>
            };
            mainobj.rows.push(obj);
          } 
        this.setState({ tabledata : mainobj});
    }
    
    render () {
        return (
          <div className="flex-column-fluid">
            <div className="card card-custom mb-8 mb-lg-0 p-10">
                <div className="card-header border-0 pt-5">
                    <h3 className="card-title align-items-start flex-column">
                        <span className="card-label font-weight-bolder text-dark">Assin Conversation</span>
                    </h3>
                </div>
                <Onboardingtable tabledata={this.state.tabledata} />
            </div>
        </div>
        )
    }
}

export default Onboarding;