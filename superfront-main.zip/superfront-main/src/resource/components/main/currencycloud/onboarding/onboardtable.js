import React from 'react';
import { MDBDataTable } from 'mdbreact';

const Onboardingtable = (props) => {
  return (
    <MDBDataTable
      striped
      bordered
      small
      data={props.tabledata}
    />
  );
}

export default Onboardingtable;