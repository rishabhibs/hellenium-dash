import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { payf } from '../../../../../redux/actions/pay';
// import { toAbsoluteUrl } from "../../../../layouts/_helpers";
// import SVG from "react-inlinesvg";
import '../../../../../assets/css/beneficiaries.css';
// import CountrySelector from '../utils/countryselector';
import CurrencySelector from '../../utils/currencySelector';
import { stoast } from '../../../../../redux/actions/toast';
import DateAndTimePickers from './datePicker';

class Pay extends React.Component {

    constructor() {
        super();
        this.state = {
            stage: 1,
            focus: 0,
            error: 0,
            bnname: '',
            hname: '',
            country: '',
            currency: '',
            benenickname: '',
            benecountry: '',
            holdername: '',
            type: '',
            IBAN: '',
            BICSWIFT: '',
            fname: '',
            lname: '',
            address: '',
            city: '',
            amount: '',
            ultimatebe: '',
            date: ''
        };
    }

    nextBtn() {
        var data = "";
        var flag = false;
        var focus = 0;
        if(this.state.stage === 1) {
            if(this.state.amount === "") {focus = 1;data="Amount";}
            else if(this.state.bnname === "") {focus = 2;data="IBAN";}
            if(focus !== 0) {
                this.props.stoast("Input "+data+" correctly.", "error");
                this.setState({focus: focus});
            } else { flag = true; }
        } else if(this.state.stage === 2) {
            focus = 0;
            if(this.state.IBAN === "") {focus = 4;data="IBAN";}
            else if(this.state.BICSWIFT === "") {focus = 5;data="BIC SWIFT";}
            else if(this.state.fname === "") {focus = 6;data="First Name";}
            else if(this.state.lname === "") {focus = 7;data="Last Name";}
            else if(this.state.address === "") {focus = 8;data="Address";}
            else if(this.state.city === "") {focus = 9;data="City";}
            if(focus !== 0) {
                this.props.stoast("Input "+data+" correctly.", "error");
                this.setState({focus: focus});
            } else { flag = true; }
        } else if(this.state.stage === 3) {flag = true;}

        if(flag === true) {
            var num = this.state.stage + 1;
            if(this.state.stage !== 4) {
                this.setState({stage: num});
            }
        }
    }

    prevBtn() {
        var num = this.state.stage - 1;
        if(num !== 0) {
            this.setState({stage: num});
        }
    }

    onBlur(e) {
        if(e.target.value === "")
        {
            this.setState({focus: 0}); 
        }
    }

    Focus(value, num) {
        this.setState({focus: num});
        if(value === "") {
            this.setState({error: num});
        }
    }

    onChange(val) {
        this.setState({currency: val.target.value});
    }

    changeCountry(val) {
        this.setState({country: val.label});
    }

    paybn() {
        this.props.payf(this.state);
    }
    
    changeDate(dt) {
        this.setState({date: dt});
    }
    
    render () {
        return (
            <section className="wizard-section">
                <div className="row no-gutters">
                    <div className="col-lg-12 col-md-12">
                        <div className="form-wizard">
                            <form action="" method="post" role="form">
                                <div className="form-wizard-header">
                                    <p>Fill all form field to go next step</p>
                                    <ul className="list-unstyled form-wizard-steps clearfix">
                                        <li className={this.state.stage === 1 ? "active" : this.state.stage > 1 ? "activated" : ""}><span>1</span></li>
                                        <li className={this.state.stage === 2 ? "active" : this.state.stage > 2 ? "activated" : ""}><span>2</span></li>
                                        <li className={this.state.stage === 3 ? "active" : this.state.stage > 3 ? "activated" : ""}><span>3</span></li>
                                        <li className={this.state.stage === 4 ? "active" : this.state.stage > 4 ? "activated" : ""}><span>4</span></li>
                                    </ul>
                                </div>
                                <div className={`wizard-fieldset mb-20 ${this.state.stage === 1 ? "show" : ""}`}>
                                    <div className="row">
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Currency</h3></div>
                                            <div className="form-group">
                                                <CurrencySelector onChange={(e) => this.onChange(e)} name={'currency'} />
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Amount</h3></div>
                                            <div className={this.state.focus === 1 || this.state.amount !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 1)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'amount': e.target.value})}}/>
                                                <label htmlFor="amount" className="wizard-form-text-label">Amount*</label>
                                                <div className="wizard-form-error" style={this.state.amount !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Beneficiary Name  <Link to="/currencycloud/addbeneficiaries" className="btn btn-primary">Add</Link></h3> </div>
                                            <div className={this.state.focus === 2 || this.state.bnname !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 2)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'bnname': e.target.value})}}/>
                                                <label htmlFor="bnname" className="wizard-form-text-label">Beneficiary Name*</label>
                                                <div className="wizard-form-error" style={this.state.bnname !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Ultimate Beneficiary</h3></div>
                                            <div className={this.state.focus === 3 || this.state.ultimatebe !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 3)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'ultimatebe': e.target.value})}}/>
                                                <label htmlFor="ultimatebe" className="wizard-form-text-label">Ultimate Beneficiary*</label>
                                                <div className="wizard-form-error" style={this.state.ultimatebe !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-group clearfix">
                                        <Link to="#" className="form-wizard-previous-btn float-left" onClick={() => {this.prevBtn()}}>Previous</Link>
                                        <Link to="#" className="form-wizard-next-btn float-right" onClick={() => {this.nextBtn()}}>Select a Payer</Link>
                                    </div>
                                </div>
                                <div className={`wizard-fieldset mb-20 ${this.state.stage === 2 ? "show" : ""}`}>
                                    <div className="row">
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Payment Date</h3></div>
                                            <DateAndTimePickers parent={this} />
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>BIC/SWIFT</h3></div>
                                            <div className={this.state.focus === 5 || this.state.BICSWIFT !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 5)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'BICSWIFT': e.target.value})}}/>
                                                <label htmlFor="BICSWIFT" className="wizard-form-text-label">BIC/SWIFT*</label>
                                                <div className="wizard-form-error" style={this.state.BICSWIFT !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>First Name</h3></div>
                                            <div className={this.state.focus === 6 || this.state.fname !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 6)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'fname': e.target.value})}}/>
                                                <label htmlFor="fname" className="wizard-form-text-label">First Name*</label>
                                                <div className="wizard-form-error" style={this.state.fname !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Last Name</h3></div>
                                            <div className={this.state.focus === 7 || this.state.lname !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 7)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'lname': e.target.value})}}/>
                                                <label htmlFor="lname" className="wizard-form-text-label">Last Name*</label>
                                                <div className="wizard-form-error" style={this.state.lname !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Address</h3></div>
                                            <div className={this.state.focus === 8 || this.state.address !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 8)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'address': e.target.value})}}/>
                                                <label htmlFor="address" className="wizard-form-text-label">Address*</label>
                                                <div className="wizard-form-error" style={this.state.address !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>City</h3></div>
                                            <div className={this.state.focus === 9 || this.state.city !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 9)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'city': e.target.value})}}/>
                                                <label htmlFor="city" className="wizard-form-text-label">City*</label>
                                                <div className="wizard-form-error" style={this.state.city !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-group clearfix">
                                        <Link to="#" className="form-wizard-previous-btn float-left" onClick={() => {this.prevBtn()}}>Previous</Link>
                                        <Link to="#" className="form-wizard-next-btn float-right" onClick={() => {this.nextBtn()}}>Next</Link>
                                    </div>
                                </div>
                                <div className={`wizard-fieldset  pl-48 mb-20 ${this.state.stage === 3 ? "show" : ""}`}>
                                    <div className="row">
                                        <h3><b>You are ready to create Beneficiary!</b></h3><br />
                                    </div>
                                    <div className="row">
                                        <h3>Beneficiary Details</h3>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Address: <b>{this.state.address}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Country: <b>{this.state.benecountry}</b></h4></div>
                                        </div>
                                        <h3>Beneficiary Bank Details</h3>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Currency: <b>{this.state.currency}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Priority: <b>{this.state.type===0? "company": "Individual"}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Address: <b>{this.state.address}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>City: <b>{this.state.city}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Beneficiary Country: <b>{this.state.benecountry}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Company Name:<b>president</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>IBAN:<b>{this.state.IBAN}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>BIC/SWIFT:<b>{this.state.BICSWIFT}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Bank Name:<b>TEST BANK NAME</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Bank Address:<b>Bank Address</b></h4></div>
                                        </div>
                                    </div>
                                    <div className="form-group clearfix">
                                        <Link to="#" className="form-wizard-previous-btn float-left" onClick={() => {this.prevBtn()}}>Previous</Link>
                                        <Link to="#" className="form-wizard-next-btn float-right" onClick={() => {this.nextBtn()}}>Next</Link>
                                    </div>
                                </div>
                                <div className={`wizard-fieldset pl-48 mb-20 ${this.state.stage === 4 ? "show" : ""}`}>
                                    <div className="row">
                                        <h3><b>Success!</b></h3><br />
                                    </div>
                                    <div className="row">
                                        <h3>Beneficiary Details</h3>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Address: <b>{this.state.address}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Country: <b>{this.state.benecountry}</b></h4></div>
                                        </div>
                                        <h3>Beneficiary Bank Details</h3>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Currency: <b>{this.state.currency}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Priority: <b>{this.state.type===0? "company": "Individual"}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Address: <b>{this.state.address}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>City: <b>{this.state.city}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Beneficiary Country: <b>{this.state.benecountry}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Company Name:<b>president</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>IBAN:<b>{this.state.IBAN}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>BIC/SWIFT:<b>{this.state.BICSWIFT}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Bank Name:<b>TEST BANK NAME</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Bank Address:<b>Bank Address</b></h4></div>
                                        </div>
                                    </div>
                                    <div className="form-group clearfix">
                                        <Link to="#" className="form-wizard-previous-btn float-left" onClick={() => {this.prevBtn()}}>Previous</Link>
                                        <Link to="#" className="form-wizard-next-btn float-right" onClick={() => this.paybn()}>Pay</Link>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}

function done(state) {
    return {
        beneficiaries: state.main.data
    }
}

export default connect(done, {payf, stoast})(Pay);