import React from 'react';
import { MDBDataTable } from 'mdbreact';

const Assintable = (props) => {
  return (
    <MDBDataTable
      striped
      bordered
      small
      data={props.tabledata}
    />
  );
}

export default Assintable;