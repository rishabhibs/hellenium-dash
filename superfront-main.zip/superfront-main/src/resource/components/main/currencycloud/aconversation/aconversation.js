import React from 'react';
// import { Link } from 'react-router-dom';
import '../../../../../assets/css/tableStyle.css';
import Assintable from './assiantable';

class Aconversation extends React.Component {
    constructor(){
        super();
        this.state = {
            tabledata: []
        }
    }
    UNSAFE_componentWillMount() {
        const data = {
            columns: [
                {
                    label: 'Name',
                    field: 'name',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'Position',
                    field: 'position',
                    sort: 'asc',
                    width: 270
                },
                {
                    label: 'Office',
                    field: 'office',
                    sort: 'asc',
                    width: 200
                },
                {
                    label: 'Age',
                    field: 'age',
                    sort: 'asc',
                    width: 100
                },
                {
                    label: 'Start date',
                    field: 'date',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'Salary',
                    field: 'salary',
                    sort: 'asc',
                    width: 100
                }
            ],
            rows: []
        };
        for(var i = 0 ; i < 100 ; i++) {
            var obj = {
                name: 'Garrett Winters'+i,
                position: 'Accountant'+i,
                office: 'Tokyo'+i,
                age: '63'+i,
                date: '2011/07/25',
                salary: '$170'+i
            }
            data.rows.push(obj);
        }
        this.setState({tabledata: data});
    }
    render () {
        return (
            <div className="flex-column-fluid">
                <div className="card card-custom mb-8 mb-lg-0 p-10">
                    <div className="card-header border-0 pt-5">
                        <h3 className="card-title align-items-start flex-column">
                            <span className="card-label font-weight-bolder text-dark">Assin Conversation</span>
                        </h3>
                    </div>
                    <Assintable tabledata={this.state.tabledata} />
                </div>
            </div>
        )
    }
}

export default Aconversation;