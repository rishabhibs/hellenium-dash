import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

import { convert } from '../../../../../redux/actions/convert';
import '../../../../../assets/css/beneficiaries.css';
import CurrencySelector from '../../utils/currencySelector';
import SimpleSelect from './selectOption';
import { stoast } from '../../../../../redux/actions/toast';
import DateAndTimePickers from './datePicker';

class Convert extends React.Component {

    constructor() {
        super();
        this.state = {
            focus:0,
            amount: 0,
            stage: 1,
            sell: '',
            buy: '',
            type: '',
            datetime: '',
            status: 0
        };
    }

    UNSAFE_componentWillMount() {
        this.setState({status: 0});
    }

    nextBtn() {
        if(this.state.stage === 1) {
            if(this.state.sell === '') {
                this.props.stoast('Input Sell exactly', 'error');
                return;
            } else if(this.state.buy === '') {
                this.props.stoast('Input Buy exactly', 'error');
                return;
            } else if(this.state.type === '') {
                this.props.stoast('Input Type exactly', 'error');
                this.setState({focus: 1});
                return;
            } else if(this.state.amount === 0) {
                this.props.stoast('Input Amount exactly', 'error');
                this.setState({focus: 1});
                return;
            } else if(this.state.buy === this.state.sell) {
                this.props.stoast("Buy and sell mustn't be same.", 'error');
                return;
            }
        } else if(this.state.stage === 2) {
            if(this.state.datetime === '') {
                this.props.stoast("Input date correctly.", 'error');
                return;
            }
        }

        var num = this.state.stage + 1;
        if(this.state.stage !== 4) {
            this.setState({stage: num});
        }

    }

    prevBtn() {
        var num = this.state.stage - 1;
        if(num !== 0) {
            this.setState({stage: num});
        }
    }

    onBlur(e) {
        if(e.target.value === "")
        {
            this.setState({focus: 0}); 
        }
    }

    Focus(value, num) {
        this.setState({focus: num});
        if(value === "") {
            this.setState({error: num});
        }
    }

    onChangeSell(val) {
        this.setState({sell: val.target.value});
    }
    
    onChangeBuy(val) {
        this.setState({buy: val.target.value});
    }

    changeCountry(val) {
        this.setState({country: val.label});
    }

    convertf() {
        var obj = {
            buyCurrency: this.state.buy,
            sellCurrency: this.state.sell,
            fixedSide: this.state.type,
            amount: this.state.amount,
            reason: 'I need to convert it',
            termAgreement: true
        }
        this.props.convert(obj);
    }

    changeType(type) {
        if(type === 10) { this.setState({type: "buy"});  } else if(type === 20) { this.setState({type: "sell"}); }
    }

    changeDate(dateD) {
        this.setState({datetime: dateD});
    }
    
    render () {
        return (
            <section className="wizard-section">
                <div className="row no-gutters">
                    <div className="col-lg-12 col-md-12">
                        <div className="form-wizard">
                            <form action="" method="post" role="form">
                                <div className="form-wizard-header">
                                    <p>Fill all form field to go next step</p>
                                    <ul className="list-unstyled form-wizard-steps clearfix">
                                        <li className={this.state.stage === 1 ? "active" : this.state.stage > 1 ? "activated" : ""}><span>1</span></li>
                                        <li className={this.state.stage === 2 ? "active" : this.state.stage > 2 ? "activated" : ""}><span>2</span></li>
                                        <li className={this.state.stage === 3 ? "active" : this.state.stage > 3 ? "activated" : ""}><span>3</span></li>
                                        <li className={this.state.stage === 4 ? "active" : this.state.stage > 4 ? "activated" : ""}><span>4</span></li>
                                    </ul>
                                </div>
                                <div className={`wizard-fieldset mb-20 ${this.state.stage === 1 ? "show" : ""}`}>
                                    <div className="row">
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Sell</h3></div>
                                            <div className="form-group">
                                                <CurrencySelector onChange={(e) => this.onChangeSell(e)} />
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Buy</h3></div>
                                            <div className="form-group">
                                                <CurrencySelector onChange={(e) => this.onChangeBuy(e)} />
                                            </div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <SimpleSelect changeType={(type) => this.changeType(type)} />
                                            <div className="col-12"><h3>Amount</h3></div>
                                            <div className={this.state.focus === 1 || this.state.amount !== "" ? "form-group focus-input" : "form-group"}>
                                                <input type="text" className="form-control wizard-required" onFocus={(e) => this.Focus(e.target.value, 1)} onBlur={(e) => this.onBlur(e)} onChange={(e) => {this.setState({'amount': e.target.value})}}/>
                                                <label htmlFor="hname" className="wizard-form-text-label">Amount*</label>
                                                <div className="wizard-form-error" style={this.state.amount !== "" ? {} : {display: "block"}}></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-group clearfix">
                                        <Link to="#" className="form-wizard-previous-btn float-left" onClick={() => {this.prevBtn()}}>Previous</Link>
                                        <Link to="#" className="form-wizard-next-btn float-right" onClick={() => {this.nextBtn()}}>Next</Link>
                                    </div>
                                </div>
                                <div className={`wizard-fieldset mb-20 ${this.state.stage === 2 ? "show" : ""}`}>
                                    <div className="row">
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h3>Select Date of Conversion </h3></div>
                                            <DateAndTimePickers parent={this} />
                                        </div>
                                    </div>
                                    <div className="form-group clearfix">
                                        <Link to="#" className="form-wizard-previous-btn float-left" onClick={() => {this.prevBtn()}}>Previous</Link>
                                        <Link to="#" className="form-wizard-next-btn float-right" onClick={() => {this.nextBtn()}}>Next</Link>
                                    </div>
                                </div>
                                <div className={`wizard-fieldset pl-48 mb-20 ${this.state.stage === 3 ? "show" : ""}`}>
                                    <div className="row">
                                        <h3><b>You are ready to create Beneficiary!</b></h3><br />
                                    </div>
                                    <div className="row">
                                        <h3>Quote</h3>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Selling: <b>{this.state.amount}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Buying: <b>{this.state.amount}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Your Exchange Rate: <b>{this.state.buy}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Settlement Date: <b>{this.state.datetime}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Conversion Date: <b>{this.state.datetime}</b></h4></div>
                                        </div>
                                    </div>
                                    <div className="form-group clearfix">
                                        <Link to="#" className="form-wizard-previous-btn float-left" onClick={() => {this.prevBtn()}}>Previous</Link>
                                        <Link to="#" className="form-wizard-next-btn float-right" onClick={() => {this.nextBtn()}}>Next</Link>
                                    </div>
                                </div>
                                <div className={`wizard-fieldset pl-48 mb-20 ${this.state.stage === 4 ? "show" : ""}`}>
                                    <div className="row">
                                        <h3><b>Success!</b></h3><br />
                                    </div>
                                    <div className="row">
                                    <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Selling: <b>{this.state.amount}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Buying: <b>{this.state.amount}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Your Exchange Rate: <b>{this.state.buy}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Settlement Date: <b>{this.state.datetime}</b></h4></div>
                                        </div>
                                        <div className="col-md-12 pl-15">
                                            <div className="col-12"><h4>Conversion Date: <b>{this.state.datetime}</b></h4></div>
                                        </div>
                                    </div>
                                    <div className="form-group clearfix">
                                        <Link to="#" className="form-wizard-previous-btn float-left" onClick={() => {this.prevBtn()}}>Previous</Link>
                                        <Link to="#" className="form-wizard-next-btn float-right" onClick={() => this.convertf()}>Convert</Link>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}

function done(state) {
    return {
        convert: state.main.convert
    }
}

export default connect(done, { convert, stoast })(Convert);