import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import SVG from "react-inlinesvg";

import { gettransactions } from '../../../redux/actions/balances';
import Datagrid from './transactions/datagrid';
import { GotoSearch } from '../../../redux/actions/search';
import { history } from '../../history';
import Shielduser from '../../../assets/media/svg/Shield-user.svg';
import Adduser from '../../../assets/media/svg/Add-user.svg';
import Sending from '../../../assets/media/svg/Sending.svg';
import Exchange from '../../../assets/media/svg/Exchange.svg';

class Dashboard extends React.Component {

    constructor() {
        super();
        this.state = {
            walletid: "",
            trdata: []
        }
    }

    UNSAFE_componentWillMount() {
        this.props.gettransactions({
            id: this.props.currentwallet.id
        }) 
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(this.props !== nextProps) {
            if(nextProps.transactiondata) {
                if(nextProps.transactiondata.length === 0) {
                    this.props.gettransactions({
                        id: this.props.currentwallet.id
                    }) 
                } else {
                    this.setState({
                        trdata: nextProps.transactiondata
                    })
                }
            }
        }
    }
    
    gotoSearch(type) {
        this.props.GotoSearch(type);
        history.push('/search');
    }

    render () {
        return (
            <div className="d-flex flex-column-fluid">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6 px-6 py-8 rounded-xl">
                            <div className="card card-custom wave wave-animate-slow wave-warning mb-8 mb-lg-0">
                                <div className="card-body">
                                    <div className="d-flex align-items-center p-5">
                                        <div className="mr-6">
                                            <span className="svg-icon svg-icon-warning  svg-icon-4x">
                                                <SVG src={Shielduser}></SVG>
                                            </span>
                                        </div>
                                        <div className="d-flex flex-column">
                                            <Link to="/hellenium/crypto/buy" className="text-dark text-hover-primary font-weight-bold font-size-h4 mb-3">Buy</Link>
                                            <div className="text-dark-75">Buy and save the cryptos into your wallet</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6 px-6 py-8 rounded-xl">
                            <div className="card card-custom wave wave-animate-slow wave-primary mb-8 mb-lg-0">
                                <div className="card-body">
                                    <div className="d-flex align-items-center p-5">
                                        <div className="mr-6">
                                            <span className="svg-icon svg-icon-primary  svg-icon-4x">
                                                <SVG src={Adduser}></SVG>
                                            </span>
                                        </div>
                                        <div className="d-flex flex-column">
                                            <Link to="/beneficiaries/manage" className="text-dark text-hover-primary font-weight-bold font-size-h4 mb-3">Add a beneficiary</Link>
                                            <div className="text-dark-75">Set-up a new beneficiary to pay</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6 px-6 py-8 rounded-xl">
                            <div className="card card-custom wave wave-animate-slow wave-danger  mb-8 mb-lg-0">
                                <div className="card-body">
                                    <div className="d-flex align-items-center p-5">
                                        <div className="mr-6">
                                            <span className="svg-icon svg-icon-danger svg-icon-4x">
                                                <SVG src={Sending}></SVG>
                                            </span>
                                        </div>
                                        <div className="d-flex flex-column">
                                            <Link to="/hellenium/crypto/sell" className="text-dark text-hover-primary font-weight-bold font-size-h4 mb-3">Sell</Link>
                                            <div className="text-dark-75">You can sell your cyptos to fiat</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6 px-6 py-8 rounded-xl">
                            <div className="card card-custom wave wave-animate-slow wave-success mb-8 mb-lg-0">
                                <div className="card-body">
                                    <div className="d-flex align-items-center p-5">
                                        <div className="mr-6">
                                            <span className="svg-icon svg-icon-success svg-icon-4x">
                                                <SVG src={Exchange}></SVG>
                                            </span>
                                        </div>
                                        <div className="d-flex flex-column">
                                            <Link to="/hellenium/transfer" className="text-dark text-hover-primary font-weight-bold font-size-h4 mb-3">Create a payment</Link>
                                            <div className="text-dark-75">Create a new payment</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="content d-flex flex-column flex-column-fluid pt-0 w-98" id="kt_content">
                            <div className="col-lg-12 col-xxl-12">
                                <div className="card card-custom mb-8 mb-lg-0">
                                    <div className="card-header border-0 pt-5">
                                        <h3 className="card-title align-items-start flex-column">
                                            <span className="card-label font-weight-bolder text-dark">Transaction History</span>
                                        </h3>
                                    </div>
                                    <div className="card-body">
                                        <div className="row">
                                            <div className="card card-custom wave wave-animate-slow wave-primary mb-8 mb-lg-0 w-100">
                                                <div className="card-body">
                                                    <div className="row overflow-auto">
                                                        <Datagrid transactiondata={this.state.trdata} />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function donef(state) {
    return {
        currentwallet: state.stellar.currentwallet,
        transactiondata: state.userdata.tdata
    }
}

export default connect(donef, { GotoSearch, gettransactions })(Dashboard);