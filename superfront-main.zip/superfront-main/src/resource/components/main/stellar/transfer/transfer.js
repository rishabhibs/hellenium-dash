import React from 'react';
// import { Link } from 'react-router-dom';
import AccountBoxIcon from '@material-ui/icons/AccountBox';
import { connect } from 'react-redux';
import Select from 'react-select';
import Spinner from 'react-bootstrap/Spinner'
import { toast } from 'react-toastify';
import Dialog from 'react-bootstrap-dialog'

import { transfer_stellar } from '../../../../../redux/actions/transfer';
import { getusers } from '../../../../../redux/actions/beneficiaries';

import '../../../../../assets/css/type-select.css';

class Transfer extends React.Component {
    constructor() {
        super();
        this.state = {
            amount: 0,
            destination: "",
            options : [],
            options2 : [],
            targetOption: {},
            targetOption2: {},
            customStyles: {
                control: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 100
                }),
                menu: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 100
                })
            },
            customStyles2: {
                control: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 300
                }),
                menu: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 300
                })
            },
            status: 0,
            loading: 0,
            disablebutton: false
        }
    }

    UNSAFE_componentWillMount() {
        this.props.getusers();
        this.setState({
            options: this.props.allcurrencies,
            targetOption: this.props.allcurrencies[0]
        });
    }

    transfer() {
        if(this.props.kyc === true) {
            if(this.state.targetOption2.publickey === null) {
                toast.warning("The beneficiary doesn't have the wallet.", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            } else {
                if(this.state.amount === "") {
                    toast.error("Input correctly!", {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                    return;
                }

                var obj = {}
                if(this.state.targetOption.value === "msc1") {
                    var currData = this.state.options.filter(item => item.value === this.state.targetOption.value)[0];
                    obj = {
                        destination: this.state.targetOption2.publickey,
                        assetCode: currData.value,
                        assetIssuer: currData.issuer,
                        amount: this.state.amount,
                        type: 'crypto',
                    }
                } else if (this.state.targetOption.value === "XLM") {
                    obj = {
                        destination: this.state.targetOption2.publickey,
                        assetCode: this.state.targetOption.value,
                        assetIssuer: "",
                        amount: this.state.amount,
                        type: 'crypto',
                    }
                } else {
                    obj = {
                        destination: this.state.targetOption2.publickey,
                        assetCode: this.state.targetOption.value,
                        assetIssuer: "",
                        amount: this.state.amount,
                        type: 'fiat',
                        realid: this.state.targetOption2.realid,
                    }
                }

                let current = this.props.allasets.stellar_balance.filter(item => item.asset_code === obj.assetCode);
                if( current.length > 0 || obj.assetCode === "XLM") {
                    let curbal
                    if(obj.assetCode === "XLM") {
                        curbal = this.props.allasets.stellar_balance.filter(item => item.asset_type === "native")[0].balance
                    } else {
                        curbal = current[0].balance
                    }
                    if(parseFloat(obj.amount) > parseFloat(curbal) || parseFloat(obj.amount) === 0) {
                        toast.error("You don't have enough balance!", {
                            position: "top-right",
                            autoClose: 5000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                        });
                        return;
                    } else {
                        this.setState({
                            status: 1,
                            loading: 1,
                            disablebutton:true
                        })
                        var me = this;
                        this.dialog.show({
                            body: 'Input your currently wallet password.',
                            prompt: Dialog.PasswordPrompt({placeholder: 'secret', required: true}),
                            actions: [
                                Dialog.CancelAction(() => {
                                    this.setState({
                                        loading: 0,
                                        disablebutton:false
                                    })
                                }),
                                Dialog.OKAction((dialog) => {
                                    let password = dialog.value
                                    obj.password = password;
                                    obj.public_key = this.props.currentwallet.public_key;
                                    me.props.transfer_stellar(obj);
                                })
                            ]
                        })
                    }
                } else {
                    toast.error("You don't have the curently currency, please add a trustline!", {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                    return;
                }
            }
        } else {
            toast.warning("Please verify your identify first.", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(nextProps !== this.props) {
            if(nextProps.beneficiaries) {
                if(nextProps.beneficiaries.length > 0) {
                    var result = nextProps.beneficiaries;
                    var options2 = []
                    for(var i = 0 ; i < result.length ; i++ ) {
                        options2.push({
                            value: result[i].firstname + ' ' + result[i].lastname,
                            label: result[i].firstname + ' ' + result[i].lastname,
                            publickey: result[i].public_key,
                            realid: Number(result[i].partner_id),
                        })
                    }
                    this.setState({
                        options2: options2,
                        targetOption2: options2[0]
                    })
                }
            }
            this.setState({
                loading: 0,
                disablebutton: false
            })    
        }
    }

    render () {
        return (
            <div className="left-container">
            <div className="transaction-history-section-container"> 
              <div className="row title-row">
                <div className="col-md-12">
                  <h2>{this.state.targetOption.value} Create a Payment</h2>
                  <h3>Buy {this.state.assetCode}</h3>
                </div>             
              </div>
              {/*Row*/}
              <div className="row">
                <div className="col-md-12 col-lg-12 col-xl-12 col-sm-12 col-12"> 
                  {/*Buy content*/}
                  <div className="buy-content">  
                    <h2>{this.state.targetOption.value} fee</h2>
                    <h3>1 {this.state.targetOption.value}  &  0.00000001 {this.state.targetOption.value}</h3>
                    <h4>It may make some time to be fulfilled because globall payment</h4>
                    <div className="row">
                      <div className="col-md-6">
                        {/*Form Box*/}
                        <div className="form-box msc-form-box">
                          <label htmlFor="You will receive" className="label">You will receive</label>
                          <div className="input-group">
                            <input type="text" className="form-control" aria-label="Text input with dropdown button" placeholder={`Enter ${this.state.targetOption.value}`} onChange={(e) => this.setState({amount: e.target.value})}/>
                            <div className="input-group-append">
                              <button className="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">msci</button>
                              <div className="dropdown-menu">
                                <a className="dropdown-item" href="#">Action</a>
                                <a className="dropdown-item" href="#">Another action</a>
                                <a className="dropdown-item" href="#">Something else here</a>
                                <div role="separator" className="dropdown-divider" />
                                <a className="dropdown-item" href="#">Separated link</a>
                              </div>
                            </div>
                          </div>
                          <span className="bottom-label">Please enter {this.state.targetOption.value} amount to create a payment</span>
                        </div>
                        {/*Form Box*/}
                      </div>
                      <div className="col-md-6">
                        {/*Form Box*/}
                        <div className="form-box msc-form-box">
                          <label htmlFor="You will receive" className="label">Someone's address to create a payment {this.state.targetOption.value}</label>
                          <div className="input-group">
                            <input type="text" className="form-control" aria-label="Text input with dropdown button" placeholder={`Please enter ${this.state.targetOption.value} amount to create a payment`} />
                            <div className="input-group-append">
                              <button className="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">EUR</button>
                              <div className="dropdown-menu">
                                <a className="dropdown-item" href="#">Action</a>
                                <a className="dropdown-item" href="#">Another action</a>
                                <a className="dropdown-item" href="#">Something else here</a>
                                <div role="separator" className="dropdown-divider" />
                                <a className="dropdown-item" href="#">Separated link</a>
                              </div>
                            </div>
                          </div>
                          <span className="bottom-label">Please enter{/* {this.state.stargetOption.value} */} amount to Buy</span>
                        </div>
                        {/*Form Box*/}
                      </div>
                    </div> 
                    <button className="btn btn-submit buy-btn" type="submit"
                    disabled={this.state.disablebutton} onClick={() => this.transfer()}>
                    { this.state.loading === 1 ? <Spinner animation="border" /> : "Buy" }</button>
                  </div>
                  {/*Buy content*/}
                  {/*Buy content*/}
                  {/* <div className="buy-content">  
                    <h2>msc1 price</h2>
                    <h3>1 msc1 &amp; 1.82  EUR</h3>
                    <h4>It may make some time to be fulfilled because globall payment</h4>
                    <div className="row">
                      <div className="col-md-12">
                       
                        <div className="form-box msc-form-box">
                          <label htmlFor="You will receive" className="label">You will receive</label>
                          <div className="input-group">
                            <input type="text" className="form-control" aria-label="Text input with dropdown button" placeholder="Enter msci" />
                            <div className="input-group-append">
                              <button className="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">msci</button>
                              <div className="dropdown-menu">
                                <a className="dropdown-item" href="#">Action</a>
                                <a className="dropdown-item" href="#">Another action</a>
                                <a className="dropdown-item" href="#">Something else here</a>
                                <div role="separator" className="dropdown-divider" />
                                <a className="dropdown-item" href="#">Separated link</a>
                              </div>
                            </div>
                          </div>
                          <span className="bottom-label">Please enter msc1 amount to Buy</span>
                        </div>
                       
                      </div>
                      <div className="col-md-12">
                       
                        <div className="form-box msc-form-box">
                          <label htmlFor="You will receive" className="label">Input amount &amp; Type</label>
                          <div className="input-group">
                            <input type="text" className="form-control" aria-label="Text input with dropdown button" placeholder="Enter EUR" />
                            <div className="input-group-append">
                              <button className="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">EUR</button>
                              <div className="dropdown-menu">
                                <a className="dropdown-item" href="#">Action</a>
                                <a className="dropdown-item" href="#">Another action</a>
                                <a className="dropdown-item" href="#">Something else here</a>
                                <div role="separator" className="dropdown-divider" />
                                <a className="dropdown-item" href="#">Separated link</a>
                              </div>
                            </div>
                          </div>
                          <span className="bottom-label">Please enter msc1 amount to Buy</span>
                        </div>
                       
                      </div>
                    </div> 
                    <button className="btn btn-submit buy-btn" type="submit">Buy</button>
                  </div> */}
                  {/*Buy content*/}
                </div>
              </div>
              {/*Row*/}
            </div>
          </div>
        )
    }
}

function resultf(state) {
    return {
        kyc: state.userdata.kyc,
        allcurrencies: state.stellar.allcurrencies,
        beneficiaries: state.stellar.beneficiaries,
        allasets: state.stellar.allasets,
        currentwallet: state.stellar.currentwallet
    }
}

export default connect(resultf, { transfer_stellar, getusers })(Transfer);