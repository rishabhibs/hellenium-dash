import React from 'react';
import Select from 'react-select';
import Spinner from 'react-bootstrap/Spinner';
import Dialog from 'react-bootstrap-dialog'
import { connect } from 'react-redux';
import { toast } from 'react-toastify';

import { sell } from '../../../../../redux/actions/sell';
import '../../../../../assets/css/type-select.css';

const styles = {
    control: base => ({
    ...base,
        fontFamily: "Times New Roman",
        flex: 1,
        width: 100
    }),
    menu: base => ({
    ...base,
        fontFamily: "Times New Roman",
        flex: 1,
        width: 100
    })
};

class Sell extends React.Component {
    constructor() {
        super();
        this.state = {
            assetCode: "msc1",
            amount: "",
            price: "",
            liveprice: null,
            target: 0,
            loading: 0,
            currency: "EUR",
            msc1Price: 1.82,
            fiatcurrencies: [],
            cryptocurrencies: [],
            xlmprice: {},
            europrice: {},
            stargetOption: {},
            disablebutton: false
        }
    }

    UNSAFE_componentWillMount() {
        this.setState({
            fiatcurrencies: this.props.fiatcurrencies,
            cryptocurrencies: this.props.cryptocurrencies,
            xlmprice: this.props.xlmprice,
            europrice: this.props.europrice,
            stargetOption: this.props.fiatcurrencies[0]
        });
    }

    enterAmount(value) {
        if(this.state.target === 1) {
            var changeValue1;
            if(this.state.assetCode === "msc1") {
                if(this.state.stargetOption.value !== "EUR") {
                    let fiattarget = this.props.europrice[this.state.stargetOption.value];
                    changeValue1 = value * this.state.msc1Price / fiattarget;
                } else {
                    changeValue1 = value * this.state.msc1Price;
                }
            } else {
                let xlmtarget = this.props.xlmprice[this.state.stargetOption.value];
                changeValue1 = value * xlmtarget;
            }
            if(changeValue1 === 0) { changeValue1 = ""; } else { changeValue1 = changeValue1.toFixed(2);}
            this.setState({
                amount: value,
                price: changeValue1
            })
        }
    }

    enterFiat(value) {
        if(this.state.target === 2) {
            var changeValue2;
            if(this.state.assetCode === "msc1") {
                if(this.state.stargetOption.value !== "EUR") {
                    let fiattarget = this.props.europrice[this.state.stargetOption.value];
                    changeValue2 = value / this.state.msc1Price / fiattarget;
                } else {
                    changeValue2 = value / this.state.msc1Price;
                }
            } else {
                let xlmtarget = this.props.xlmprice[this.state.stargetOption.value];
                changeValue2 = value / xlmtarget;
            }
            if(changeValue2 === 0) { changeValue2 = ""; } else { changeValue2 = changeValue2.toFixed(7);}
            this.setState({
                amount: changeValue2,
                price: value
            })
        }
    }

    changeasset(val) {
        var changeValue3;
        if(val === "msc1") {
            if(this.state.stargetOption.value !== "EUR") {
                let fiattarget = this.props.europrice[this.state.stargetOption.value];
                changeValue3 = this.state.amount * this.state.msc1Price * fiattarget;
            } else {
                changeValue3 = this.state.amount * this.state.msc1Price;
            }
        } else {
            let xlmtarget = this.props.xlmprice[this.state.stargetOption.value];
            changeValue3 = this.state.amount * xlmtarget;
        }
        if(changeValue3 === 0) { changeValue3 = ""; } else { changeValue3 = changeValue3.toFixed(2);}
        this.setState({
            price: changeValue3,
            assetCode: val
        })
    }

    changetarget(val) {
        var changeValue4;
        if(this.state.assetCode === "msc1") {
            if(val.value !== "EUR") {
                let fiattarget = this.props.europrice[val.value];
                changeValue4 = parseFloat(this.state.amount) * this.state.msc1Price * fiattarget;
            } else {
                changeValue4 = parseFloat(this.state.amount) * this.state.msc1Price;
            }
        } else {
            let xlmtarget = this.props.xlmprice[val.value];
            changeValue4 = parseFloat(this.state.amount) * xlmtarget;
        }
        if(changeValue4 === 0) { changeValue4 = ""; } else { changeValue4 = changeValue4.toFixed(2);}
        this.setState({
            price: changeValue4,
            stargetOption: val
        })
    }

    sell() {
        if(this.props.kyc === true) {
            if(this.state.amount === "" || this.state.amount === 0) {
                toast.error("Input the acount correctly!", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            }
            let balances = this.props.allasets.stellar_balance;
            if(this.state.assetCode === "XLM") {
                let balance = balances.filter(item => item.asset_type === "native")[0].balance;
                if(parseFloat(this.state.amount) > parseFloat(balance)) {
                    toast.error("You don't have enough balance!", {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                    return;
                }
            } else {
                let balance = balances.filter(item => item.asset_code === this.state.assetCode)[0].balance;
                if(parseFloat(this.state.amount) > parseFloat(balance)) {
                    toast.error("You don't have enough balance!", {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                    return;
                }
            }
            let me = this;
            var assetis = '';
            
            if(this.state.assetCode !== 'XLM') {
                assetis = this.props.cryptocurrencies.filter(item => item.value === this.state.assetCode)[0].issuer
            }

            let obj = {
                amount: this.state.amount, 
                price: this.state.price, 
                currency: this.state.stargetOption.value, 
                assetCode: this.state.assetCode,
                assetIssuer: assetis,
            };
            this.dialog.show({
                body: 'Input your currently wallet password.',
                prompt: Dialog.PasswordPrompt({placeholder: 'secret', required: true}),
                actions: [
                    Dialog.CancelAction(),
                    Dialog.OKAction((dialog) => {
                        let password = dialog.value
                        obj.password = password;
                        obj.public_key = this.props.currentwallet.public_key;
                        me.setState({
                            loading: 1,
                            disablebutton: true
                        });
                        me.props.sell(obj);
                    })
                ]
            })
        } else {
            toast.warning("Please verify your identify first.", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(nextProps !== this.props) {
            try {
                this.setState({
                    loading: 0,
                    disablebutton: false
                })
            } catch (error) {
                this.setState({
                    loading: 0,
                    disablebutton: false
                })
            }
        }
    }

    render () {
        return (
            <div className="d-flex flex-column-fluid">
                <div className="container py-8">
                    <div className="row">
                        <Dialog ref={(component) => { this.dialog = component }} />
                        <div className="col-lg-12 col-xxl-12">
                            <div className="card card-custom mb-8 mb-lg-0">
                                <div className="card-header border-0 pt-5">
                                    <h3 className="card-title align-items-start flex-column">
                                        <span className="card-label font-weight-bolder text-dark">msc1 or XLM Sell</span>
                                        <span className="text-muted mt-3 font-weight-bold font-size-sm">Sell {this.state.assetCode}</span>
                                    </h3>
                                </div>
                                <div className="card-body">
                                    <div className="row">
                                        <div className="card card-custom wave wave-animate-slow wave-success mb-8 mb-lg-0 w-100">
                                            <div className="card-body">
                                                <div className="form-group row text-center mt-5">
                                                    <div className="col-lg-3"></div>
                                                    <div className="col-lg-6">
                                                        <label>{this.state.assetCode} price</label>
                                                        <span className="form-text text-muted">
                                                            <h3>1&nbsp;{this.state.assetCode}&nbsp;&&nbsp;
                                                                {
                                                                    this.state.assetCode === "msc1" ?
                                                                    this.state.stargetOption.value === "EUR" ?
                                                                    this.state.msc1Price :
                                                                    (this.state.msc1Price * this.props.europrice[this.state.stargetOption.value]).toFixed(2) : 
                                                                    this.props.xlmprice[this.state.stargetOption.value].toFixed(2)
                                                                }
                                                            &nbsp; {this.state.stargetOption.value}</h3></span>
                                                        <span className="form-text text-muted">
                                                            It may make some time to be fulfilled because globall payment
                                                        </span>
                                                    </div>
                                                </div>
                                                <div className="form-group row mb-26">
                                                    <div className="col-lg-6">
                                                        <label>You will receive</label>
                                                        <div className="input-group type-select">
                                                            <input type="text" className="form-control" value={this.state.amount} placeholder={`Enter ${this.state.assetCode}`} onFocus={() => this.setState({target:1})} onBlur={() => this.setState({target: 0})} onChange={(e) =>  this.enterAmount(e.target.value)}/>
                                                            <div className="input-group-append">
                                                                <Select className="select" autosize={true} styles={styles} options={this.state.cryptocurrencies} onChange={(e) => this.changeasset(e.value)} defaultValue={this.state.cryptocurrencies[0]} />
                                                            </div>
                                                        </div>
                                                        <span className="form-text text-muted">Please enter {this.state.assetCode} amount to Sell</span>
                                                    </div>
                                                    <div className="col-lg-6">
                                                        <label>Input amount & Type</label>
                                                        <div className="input-group">
                                                            <input type="text" className="form-control" value={this.state.price} placeholder={`Enter ${this.state.stargetOption.value}`} onFocus={() => this.setState({target:2})} onBlur={() => this.setState({target: 0})} onChange={(e) => this.enterFiat(e.target.value)} />
                                                            {this.state.fiatcurrencies.length > 0 ? <Select className="select" autosize={true} styles={styles} options={this.state.fiatcurrencies} onChange={(e) => this.changetarget(e)} defaultValue={this.state.stargetOption} maxMenuHeight={120} />: ""}
                                                        </div>
                                                        <span className="form-text text-muted">Please enter {this.state.stargetOption.value}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="card-footer">
                                    <div className="row">
                                        <div className="col-lg-12 text-right">
                                            <button type="reset" disabled={this.state.disablebutton} className="btn btn-primary mr-2" onClick={() => this.sell()}>
                                                { this.state.loading === 0 ? "Sell" : <Spinner animation="border" /> }
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function done(state) {
    return {
        kyc: state.userdata.kyc,
        currentwallet: state.stellar.currentwallet,
        allasets: state.stellar.allasets,
        fiatcurrencies: state.stellar.fiatcurrencies,
        cryptocurrencies: state.stellar.cryptocurrencies,
        xlmprice: state.stellar.xlmprice,
        europrice: state.stellar.europrice
    }
}

export default connect(done, { sell })(Sell);