import React from 'react'
import { MDBDataTable } from 'mdbreact'

const columns = [
    {
        label: 'Wallet Name',
        field: 'walletname',
        sort: 'asc',
        width: 200
    },
    {
        label: 'Public Key',
        field: 'publickey',
        sort: 'asc',
        width: 200
    },
    {
        label: 'Card Number',
        field: 'card_num',
        sort: 'asc',
        width: 200
    },
    {
        label: 'Type',
        field: 'type',
        sort: 'asc',
        width: 200
    },
    {
        label: 'Status',
        field: 'status',
        sort: 'asc',
        width: 200
    }
];

class Btable extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data : {
                columns: columns,
                rows: props.walletsdata
            }
        }
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(this.props !== nextProps) {
            this.setState({
                data: {
                    columns: columns,
                    rows: nextProps.walletsdata
                }
            })
        }
    }

    render() {
        return (
            <MDBDataTable
                striped
                bordered
                small
                hover
                className="w-98"
                data={this.state.data}
            />
        );
    }
}

export default Btable;