import React from 'react';
import Button from '@material-ui/core/Button';

import { connect } from "react-redux";
import { toast } from 'react-toastify';

import { activewallet } from '../../../../../redux/actions/wallets';
import Btable from './b_table';
import Createwallet from './createwallet';

import "../../../../../assets/scss/simpleStyle.scss";

class Balancem extends React.Component {

  constructor() {
    super()
    this.state = {
      walletsdata: [],
      toml: {},
      loading: 0,
      pagestatus: 0,
    }
  }

  componentDidMount() {
    if (this.props.wallets) {
      let cwallet = this.props.wallets;
      var alldata = [];
      for (let i = 0; i < cwallet.length; i++) {
        alldata.push({
          walletname: cwallet[i].walletname,
          publickey: cwallet[i].public_key,
          type: cwallet[i].type,
          card_num: cwallet[i].card_num,
          status: <button className="btn btn-primary" disabled={cwallet[i].use === true} onClick={() => this.activewallets(cwallet[i].public_key)}>{cwallet[i].use === true ? 'actived' : 'active'}</button>
        })
      }
      this.setState({ walletsdata: alldata })
    }
  }

  createw() {
    if (this.props.kyc === true) {
      this.setState({ pagestatus: 1 })
    } else {
      toast.warning("Please verify your identify first.", {
        position: "top-center",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
    }
  }

  activewallets(publickey) {
    this.setState({ loading: 1 });
    this.props.activewallet(publickey);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      this.setState({ loading: 0 });
      if (nextProps.wallets) {
        let cwallet = nextProps.wallets;
        var alldata = [];
        for (let i = 0; i < cwallet.length; i++) {
          alldata.push({
            walletname: cwallet[i].walletname,
            publickey: cwallet[i].public_key,
            type: cwallet[i].type,
            card_num: cwallet[i].card_num,
            status: <button className="btn btn-primary" disabled={cwallet[i].use} onClick={() => this.activewallets(cwallet[i].public_key)}>{cwallet[i].use === true ? 'actived' : 'active'}</button>
          })
        }
        this.setState({ walletsdata: alldata })
      }
    }
  }

  render() {
    return (
      <div className="d-flex flex-column-fluid">
        <div className="container py-8">
          <div className="row">
            <div className="col-lg-12 col-xxl-12">
              <div className="card card-custom mb-8 mb-lg-0">
                <div className="card-header border-0 pt-5">
                  <h3 className="card-title align-items-start flex-column">
                    <span className="card-label font-weight-bolder text-dark">Wallets</span>
                    <span className="text-muted mt-3 font-weight-bold font-size-sm">you can create wallets here</span>
                  </h3>
                </div>
                <div className="card-body">
                  <div className="row">
                    <div className="card card-custom wave wave-animate-slow wave-primary mb-8 mb-lg-0 w-100">
                      <div className="card-body">
                        {
                          this.state.pagestatus === 1 ?
                            <Createwallet parent={this} /> :
                            <>
                              <div className="form-group row text-center mt-5 mb-10">
                                <div className="col-lg-12 row justify-content-end">
                                  <Button onClick={() => this.createw()} variant="contained" color="secondary" className="ml-10 mt-5">
                                    Create a wallet
                                                                </Button>
                                </div>
                              </div>
                              <div className="row overflow-auto">
                                {
                                  this.state.walletsdata.length > 0 ?
                                    <Btable walletsdata={this.state.walletsdata} /> :
                                    <h3 className="card-title align-items-center text-center flex-column w-100">
                                      You don't have any wallets, please create
                                                                </h3>
                                }
                              </div>
                            </>
                        }
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

function walletget(state) {
  return {
    kyc: state.userdata.kyc,
    wallets: state.stellar.wallets,
  }
}

export default connect(walletget, { activewallet })(Balancem);