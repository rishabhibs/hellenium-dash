import { Component } from 'react';
import { connect } from 'react-redux';
import StellarHDWallet from 'stellar-hd-wallet';

import Spinner from 'react-bootstrap/Spinner'
import { toast } from 'react-toastify';
import { FaCopy } from 'react-icons/fa';
import sjcl from '@tinyanvil/sjcl';

import { createwallet } from '../../../../../redux/actions/wallets';

class Createwallet extends Component {

    constructor(props) {
        super(props);

        let mnemonic = StellarHDWallet.generateMnemonic()
        let keypair = StellarHDWallet.fromMnemonic(mnemonic)

        this.state = {
            wallettype: "hot",
            password: "",
            passwordconfirm: "",
            card_num: "",
            walletname: "",
            mnemonic: mnemonic,
            public_key: keypair.getPublicKey(0),
            secretkey: keypair.getSecret(0),
            exists: 0,
            loading: 0,
            pageStage: 1,
        };
    }

    mcreatewallet() {
        let wallet = {
            name: this.state.walletname,
            public_key: this.state.public_key,
            card_num: this.state.card_num,
            type: 'crypto',
            usage: 'hot',
            keystore : sjcl.encrypt(this.state.password, this.state.secretkey, {
                adata: JSON.stringify({
                    publicKey: this.state.public_key
                })
            })
        }
        this.setState({
            loading: 1
        })
        this.props.createwallet(wallet);
    }

    nextStep() {
        if(this.state.pageStage === 1) {
            if(this.state.password !== this.state.passwordconfirm) {
                toast.error("Password doesn't match.", {
                    position: "top-right",
                    autoClose: 3000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            }
            if(this.state.walletname === "" || this.state.password === "") {
                toast.error("Please input all fields correctly.", {
                    position: "top-right",
                    autoClose: 3000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            }
        }
        if(this.state.pageStage <= 3) {
            this.setState({pageStage: this.state.pageStage + 1});
        }
    }

    prevStep() {
        if(this.state.pageStage >= 1) {
            this.setState({pageStage: this.state.pageStage - 1});
        }
    }

    copyText() {
        var copyinput = document.createElement("input");
        copyinput.setAttribute("id", "copytext");
        copyinput.setAttribute("value", this.state.mnemonic );
        document.body.append(copyinput);
        var copyText = document.getElementById("copytext");
        copyText.select();
        document.execCommand("copy");
        copyinput.remove();

        toast.success("Address copied successfully!", {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(nextProps !== this.props) {
            if(nextProps.wallets) {
                var alldata = [];
                for(let i = 0 ; i < nextProps.wallets.length ; i++) {
                    alldata.push({
                        walletname: nextProps.wallets[i].walletname,
                        publickey: nextProps.wallets[i].public_key,
                        card_num: nextProps.wallets[i].card_num,
                        type: nextProps.wallets[i].type,
                        status: <button className="btn btn-primary" disabled={nextProps.wallets[i].use} onClick={() => this.props.parent.activewallets(nextProps.wallets[i].public_key)}>{nextProps.wallets[i].use === true ? "actived": "active"}</button>
                    })
                }
                this.props.parent.setState({walletsdata: alldata})
            }
            this.props.parent.setState({pagestatus: 0})
            this.setState({loading: 0})
        }
    }

    firstpage() {
        this.props.parent.setState({pagestatus: 0})
    }

    render() {
        return (
            <>
                {
                    this.state.pageStage === 1 ?
                    <div className="form-group row">
                        <div className="col-lg-6 mt-5">
                            <label>Wallet Name</label>
                            <div className="input-group mt-5">
                                <input type="text" className="form-control" 
                                    value={this.state.walletname} 
                                    onChange={(e) => this.setState({ walletname: e.target.value })}
                                    placeholder="Wallet Name" 
                                />
                            </div>
                            <div className="input-group mt-5">
                                <input className="form-control" 
                                    value={this.state.card_num} 
                                    onChange={(e) => this.setState({ card_num: e.target.value })}
                                    placeholder="Card Number" 
                                />
                            </div>
                        </div>
                        <div className="col-lg-6 mt-5">
                            <label>Password</label>
                            <div className="input-group mt-5">
                                <input type="password" className="form-control" 
                                    value={this.state.password} 
                                    onChange={(e) => this.setState({ password: e.target.value })}
                                    placeholder="Password" 
                                />
                            </div>
                            <div className="input-group mt-5">
                                <input type="password" className="form-control" 
                                    value={this.state.passwordconfirm} 
                                    onChange={(e) => this.setState({ passwordconfirm: e.target.value })}
                                    placeholder="Password Confirmation" 
                                />
                            </div>
                        </div>
                        <div className="col-lg-6 mt-10">
                            <label>Keypair for the wallet</label>
                            <div className="input-group mb-5">
                                <input type="text" className="form-control" 
                                    disabled={ this.state.exists === 0 } 
                                    value={this.state.public_key} 
                                    placeholder="Public key" 
                                />
                            </div>
                            <label>Please don't share secret key someone</label>
                            <div className="input-group mb-5">
                                <input type="text" className="form-control" 
                                    disabled={ this.state.exists === 0 } 
                                    value={this.state.secretkey} 
                                    placeholder="Secret key" 
                                />
                            </div>
                        </div>
                        <div className="col-lg-2 mt-10 row justify-content-end align-items-center">
                            <button type="reset" className="mt-5 btn btn-primary h-30" onClick={() => this.firstpage()}>
                                Cancel
                            </button>
                        </div>
                        <div className="col-lg-2 mt-10 row justify-content-end align-items-center">
                            <button type="reset" className="mt-5 btn btn-primary h-30" onClick={() => this.nextStep()}>
                                Next Step
                            </button>
                        </div>
                    </div> :
                    this.state.pageStage === 2 ?
                    <div className="form-group row">
                        <div className="col-lg-8 mt-10">
                            <label>
                                <h4>
                                    If you lost your keypair, you can get from these words
                                </h4>
                            </label>
                            <div className="input-group mb-5">
                                <h4>
                                    <span className="card-label font-weight-bolder text-dark ml-10">
                                        {this.state.mnemonic}
                                    </span>
                                    <label className="ml-5 btn btn-primary" onClick={() => this.copyText()} ><FaCopy /></label>
                                </h4>
                            </div>
                        </div>
                        <div className="col-lg-2 mt-10 row justify-content-end align-items-center">
                            <button type="reset" className="mt-5 btn btn-primary h-30" onClick={() => this.prevStep()}>
                                Prev Step
                            </button>
                        </div>
                        <div className="col-lg-2 mt-10 row justify-content-end align-items-center">
                            <button type="reset" className="mt-5 btn btn-primary h-30" onClick={() => this.nextStep()}>
                                Next Step
                            </button>
                        </div>
                    </div>:
                    this.state.pageStage === 3 ?
                    <div className="form-group row">
                        <div className="col-lg-8 mt-10">
                            <h4>
                                <span className="card-label font-weight-bolder text-dark ml-10">
                                    When you own cryptocurrencies, what you really own is a “private key”, a critical piece of information used to authorize outgoing transactions on the blockchain network.<br /> 
                                    Whoever has the knowledge of this key can spend the associated funds.<br />
                                    If your private keys are stolen or misplaced, or if you store them on a device that crashes, there is no bank or institution to back you up or give you a replacement: you lose access to your funds
                                </span>
                            </h4>
                        </div>
                        <div className="col-lg-2 mt-10 row justify-content-end align-items-center">
                            <button type="reset" className="mt-5 btn btn-primary h-30" onClick={() => this.prevStep()}>
                                Prev Step
                            </button>
                        </div>
                        <div className="col-lg-2 mt-10 row justify-content-end align-items-center">
                            <button type="reset" className="mt-5 btn btn-primary h-30" onClick={() => this.nextStep()}>
                                Next Step
                            </button>
                        </div>
                    </div> : 
                    <div className="form-group row">
                        <div className="col-lg-8 mt-10">
                            <h4>
                                <span className="card-label font-weight-bolder text-dark ml-10">
                                    Being a regulated institution we use need to be able by law access to your funds.<br />  
                                    This is applicable to all fiat currency accounts you have with us like, £, $, € etc.<br />  
                                    When it comes to crypto accounts we recommend  that you create a secondary account where, when needed, you place a limited amount of your funds and give us access to it.<br />  
                                    We will advise you the amounts needed every time.<br /> 
                                    This way you can retain total control of your main account in crypto.<br />
                                    Alternatively, you may choose to hold your account only in our in-house currency [msc1] in which case the system will treat your account similarly to this of a fiat currency fact that wil simplify your every day life and enjoy additional benefits.<br /> 
                                    Please follow this link for additional information
                                </span>
                            </h4>
                        </div>
                        <div className="col-lg-2 mt-10 row justify-content-end align-items-center">
                            <button type="reset" className="mt-5 btn btn-primary h-30" disabled={ this.state.loading } onClick={() => this.prevStep()}>
                                {this.state.loading ? <Spinner animation="border" />: "Prev Step"}
                            </button>
                        </div>
                        <div className="col-lg-2 mt-10 row justify-content-end align-items-center">
                            <button type="reset" className="mt-5 btn btn-primary h-30" disabled={ this.state.loading } onClick={() => this.mcreatewallet()}>
                                {this.state.loading ? <Spinner animation="border" />: "Create wallet"}
                            </button>
                        </div>
                    </div>
                }
            </>
        );
    }
}

function created(state) {
    return {
        wallets: state.stellar.wallets
    }
} 

export default connect(created, { createwallet } )(Createwallet);