import React from 'react';
import Select from 'react-select';
import Spinner from 'react-bootstrap/Spinner';
import Dialog from 'react-bootstrap-dialog'
import { connect } from 'react-redux';
import { toast } from 'react-toastify';

import { buy } from '../../../../../redux/actions/buy';
import '../../../../../assets/css/type-select.css';

class Buy extends React.Component {
    constructor() {
        super();
        this.state = {
            assetCode: "msc1",
            assetIssuer: "",
            amount: "",
            price: "",
            liveprice: null,
            target: 0,
            loading: 0,
            currency: "EUR",
            msc1Price: 1.82,
            fiatcurrencies: [],
            cryptocurrencies: [],
            xlmprice: {},
            europrice: {},
            stargetOption: {},
            disablebutton: false,
            styles: {
                control: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 100
                }),
                menu: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 100
                })
            }
        }
    }

    UNSAFE_componentWillMount() {
        this.setState({
            fiatcurrencies: this.props.fiatcurrencies,
            cryptocurrencies: this.props.cryptocurrencies,
            xlmprice: this.props.xlmprice,
            europrice: this.props.europrice,
            stargetOption: this.props.fiatcurrencies[0]
        });
    }

    enterAmount(value) {
        if(this.state.target === 1) {
            var changeValue1;
            if(this.state.assetCode === "msc1") {
                if(this.state.stargetOption.value !== "EUR") {
                    let fiattarget = this.props.europrice[this.state.stargetOption.value];
                    changeValue1 = value * this.state.msc1Price / fiattarget;
                } else {
                    changeValue1 = value * this.state.msc1Price;
                }
            } else {
                let xlmtarget = this.props.xlmprice[this.state.stargetOption.value];
                changeValue1 = value * xlmtarget;
            }
            if(changeValue1 === 0) { changeValue1 = ""; } else { changeValue1 = changeValue1.toFixed(2);}
            this.setState({
                amount: value,
                price: changeValue1
            })
        }
    }

    enterFiat(value) {
        if(this.state.target === 2) {
            var changeValue2;
            if(this.state.assetCode === "msc1") {
                if(this.state.stargetOption.value !== "EUR") {
                    let fiattarget = this.props.europrice[this.state.stargetOption.value];
                    changeValue2 = value / this.state.msc1Price / fiattarget;
                } else {
                    changeValue2 = value / this.state.msc1Price;
                }
            } else {
                let xlmtarget = this.props.xlmprice[this.state.stargetOption.value];
                changeValue2 = value / xlmtarget;
            }
            if(changeValue2 === 0) { changeValue2 = ""; } else { changeValue2 = changeValue2.toFixed(7);}
            this.setState({
                amount: changeValue2,
                price: value
            })
        }
    }

    changeasset(val) {
        var changeValue3;
        if(val === "msc1") {
            if(this.state.stargetOption.value !== "EUR") {
                let fiattarget = this.props.europrice[this.state.stargetOption.value];
                changeValue3 = this.state.amount * this.state.msc1Price * fiattarget;
            } else {
                changeValue3 = this.state.amount * this.state.msc1Price;
            }
        } else {
            let xlmtarget = this.props.xlmprice[this.state.stargetOption.value];
            changeValue3 = this.state.amount * xlmtarget;
        }
        if(changeValue3 === 0) { changeValue3 = ""; } else { changeValue3 = changeValue3.toFixed(2);}
        this.setState({
            price: changeValue3,
            assetCode: val
        })
    }

    changetarget(val) {
        var changeValue4;
        if(this.state.assetCode === "msc1") {
            if(val.value !== "EUR") {
                let fiattarget = this.props.europrice[val.value];
                changeValue4 = parseFloat(this.state.amount) * this.state.msc1Price * fiattarget;
            } else {
                changeValue4 = parseFloat(this.state.amount) * this.state.msc1Price;
            }
        } else {
            let xlmtarget = this.props.xlmprice[val.value];
            changeValue4 = parseFloat(this.state.amount) * xlmtarget;
        }
        if(changeValue4 === 0) { changeValue4 = ""; } else { changeValue4 = changeValue4.toFixed(2);}
        this.setState({
            price: changeValue4,
            stargetOption: val
        })
    }

    buy() {
        if(this.props.kyc === true) {
            if(this.state.amount === "" || this.state.amount === 0) {
                toast.error("Input the acount correctly!", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            }
            let balances = this.props.allasets.stellar_balance;
            let balance = balances.filter(item => item.asset_code === this.state.stargetOption.value)[0].balance;
            if(parseFloat(this.state.amount) > parseFloat(balance)) {
                toast.error("You don't have enough balance! Please deposit", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            }
            let me = this;
            var assetis = '';
            
            if(this.state.assetCode !== 'XLM') {
                assetis = this.props.cryptocurrencies.filter(item => item.value === this.state.assetCode)[0].issuer
            }

            let obj = {
                amount: this.state.amount, 
                price: this.state.price, 
                currency: this.state.stargetOption.value, 
                assetCode: this.state.assetCode,
                assetIssuer: assetis,
            };

            this.dialog.show({
                body: 'Input your currently wallet password.',
                prompt: Dialog.PasswordPrompt({placeholder: 'secret', required: true}),
                actions: [
                    Dialog.CancelAction(),
                    Dialog.OKAction((dialog) => {
                        let password = dialog.value
                        obj.password = password;
                        me.setState({
                            loading: 1,
                            disablebutton: true
                        });
                        me.props.buy(obj);
                    })
                ]
            })
        } else {
            toast.warning("Please verify your identify first.", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(nextProps !== this.props) {
            try {
                this.setState({
                    loading: 0,
                    disablebutton: false
                })
            } catch (error) {
                this.setState({
                    loading: 0,
                    disablebutton: false
                })
            }
        }
    }

    render () {
        return (
            
    
      
      <div className="left-container">
        <div className="transaction-history-section-container"> 
          <div className="row title-row">
            <div className="col-md-12">
              <h2>msc1 or XLM Buy</h2>
              <h3>Buy {this.state.assetCode}</h3>
            </div>             
          </div>
          {/*Row*/}
          <div className="row">
            <div className="col-md-12 col-lg-12 col-xl-12 col-sm-12 col-12"> 
              {/*Buy content*/}
              <div className="buy-content">  
                <h2>{this.state.assetCode} price</h2>
                <h3>1&nbsp;{this.state.assetCode}&nbsp;&&nbsp;
                  {
                    this.state.assetCode === "msc1" ?
                    this.state.stargetOption.value === "EUR" ?
                    this.state.msc1Price :
                    (this.state.msc1Price * this.props.europrice[this.state.stargetOption.value]).toFixed(2) : 
                    this.props.xlmprice[this.state.stargetOption.value].toFixed(2)
                    }
                    &nbsp; {this.state.stargetOption.value}</h3>
                <h4>It may make some time to be fulfilled because globall payment</h4>
                <div className="row">
                  <div className="col-md-6">
                    {/*Form Box*/}
                    <div className="form-box msc-form-box">
                      <label htmlFor="You will receive" className="label">You will receive</label>
                      <div className="input-group">
                        <input type="text" className="form-control" aria-label="Text input with dropdown button" placeholder="Enter msci" />
                        <div className="input-group-append">
                          <button className="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">msci</button>
                          <div className="dropdown-menu">
                            <a className="dropdown-item" href="#">Action</a>
                            <a className="dropdown-item" href="#">Another action</a>
                            <a className="dropdown-item" href="#">Something else here</a>
                            <div role="separator" className="dropdown-divider" />
                            <a className="dropdown-item" href="#">Separated link</a>
                          </div>
                        </div>
                      </div>
                      <span className="bottom-label">Please enter {this.state.assetCode} amount to Buy</span>
                    </div>
                    {/*Form Box*/}
                  </div>
                  <div className="col-md-6">
                    {/*Form Box*/}
                    <div className="form-box msc-form-box">
                      <label htmlFor="You will receive" className="label">Input amount &amp; Type</label>
                      <div className="input-group">
                        <input type="text" className="form-control" aria-label="Text input with dropdown button" placeholder="Enter EUR" />
                        <div className="input-group-append">
                          <button className="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">EUR</button>
                          <div className="dropdown-menu">
                            <a className="dropdown-item" href="#">Action</a>
                            <a className="dropdown-item" href="#">Another action</a>
                            <a className="dropdown-item" href="#">Something else here</a>
                            <div role="separator" className="dropdown-divider" />
                            <a className="dropdown-item" href="#">Separated link</a>
                          </div>
                        </div>
                      </div>
                      <span className="bottom-label">Please enter{this.state.stargetOption.value} amount to Buy</span>
                    </div>
                    {/*Form Box*/}
                  </div>
                </div> 
                <button className="btn btn-submit buy-btn" type="submit">Buy</button>
              </div>
              {/*Buy content*/}
              {/*Buy content*/}
              <div className="buy-content">  
                <h2>msc1 price</h2>
                <h3>1 msc1 &amp; 1.82  EUR</h3>
                <h4>It may make some time to be fulfilled because globall payment</h4>
                <div className="row">
                  <div className="col-md-12">
                    {/*Form Box*/}
                    <div className="form-box msc-form-box">
                      <label htmlFor="You will receive" className="label">You will receive</label>
                      <div className="input-group">
                        <input type="text" className="form-control" aria-label="Text input with dropdown button" placeholder="Enter msci" />
                        <div className="input-group-append">
                          <button className="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">msci</button>
                          <div className="dropdown-menu">
                            <a className="dropdown-item" href="#">Action</a>
                            <a className="dropdown-item" href="#">Another action</a>
                            <a className="dropdown-item" href="#">Something else here</a>
                            <div role="separator" className="dropdown-divider" />
                            <a className="dropdown-item" href="#">Separated link</a>
                          </div>
                        </div>
                      </div>
                      <span className="bottom-label">Please enter msc1 amount to Buy</span>
                    </div>
                    {/*Form Box*/}
                  </div>
                  <div className="col-md-12">
                    {/*Form Box*/}
                    <div className="form-box msc-form-box">
                      <label htmlFor="You will receive" className="label">Input amount &amp; Type</label>
                      <div className="input-group">
                        <input type="text" className="form-control" aria-label="Text input with dropdown button" placeholder="Enter EUR" />
                        <div className="input-group-append">
                          <button className="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">EUR</button>
                          <div className="dropdown-menu">
                            <a className="dropdown-item" href="#">Action</a>
                            <a className="dropdown-item" href="#">Another action</a>
                            <a className="dropdown-item" href="#">Something else here</a>
                            <div role="separator" className="dropdown-divider" />
                            <a className="dropdown-item" href="#">Separated link</a>
                          </div>
                        </div>
                      </div>
                      <span className="bottom-label">Please enter msc1 amount to Buy</span>
                    </div>
                    {/*Form Box*/}
                  </div>
                </div> 
                <button className="btn btn-submit buy-btn" type="submit">Buy</button>
              </div>
              {/*Buy content*/}
            </div>
          </div>
          {/*Row*/}
        </div>
      </div>
    
  //ends here

        )
    }
}

function done(state) {
    return {
        kyc: state.userdata.kyc,
        allasets: state.stellar.allasets,
        fiatcurrencies: state.stellar.fiatcurrencies,
        cryptocurrencies: state.stellar.cryptocurrencies,
        xlmprice: state.stellar.xlmprice,
        europrice: state.stellar.europrice
    }
}

export default connect(done, { buy })(Buy);