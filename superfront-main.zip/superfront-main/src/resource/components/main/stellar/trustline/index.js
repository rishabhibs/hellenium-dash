import React from 'react'
import { MDBDataTable } from 'mdbreact'
import { StellarTomlResolver } from 'stellar-sdk'
import { connect } from "react-redux";
import { toast } from 'react-toastify';

import Dialog from 'react-bootstrap-dialog'

import { addtrustline } from '../../../../../redux/actions/wallets';

import config from '../../../../../config';
import "../../../../../assets/scss/simpleStyle.scss";

class Trustline extends React.Component {

  constructor() {
    super()
    this.state = {
      walletsdata: [],
      toml: {},
      loading: 0,
      data: null
    }
  }

  UNSAFE_componentWillMount() {
    if (config.dev === true) {
      StellarTomlResolver.resolve(config.toml_url, { allowHttp: true })
        .then(async (toml) => {
          var alldata = [];
          let currenciesfromtoml = toml.CURRENCIES;
          for (let i = 0; i < currenciesfromtoml.length; i++) {
            if (currenciesfromtoml[i].anchor_asset_type === "fiat") continue;
            alldata.push({
              asset: currenciesfromtoml[i].code,
              issuer: currenciesfromtoml[i].issuer,
              status: <button className="btn btn-primary" onClick={() => this.maddtrustline(currenciesfromtoml[i].code, currenciesfromtoml[i].issuer)}>Add a trustline</button>
            })
          }
          this.setState({
            data: {
              columns: [
                {
                  label: 'Asset',
                  field: 'asset',
                  sort: 'asc',
                  width: 200
                },
                {
                  label: 'Issuer',
                  field: 'issuer',
                  sort: 'asc',
                  width: 200
                },
                {
                  label: 'Status',
                  field: 'status',
                  sort: 'asc',
                  width: 200
                }
              ],
              rows: alldata
            }
          })
        })
    } else {
      StellarTomlResolver.resolve(config.toml_url)
        .then(async (toml) => {
          var alldata = [];
          let currenciesfromtoml = toml.CURRENCIES;
          for (let i = 0; i < currenciesfromtoml.length; i++) {
            if (currenciesfromtoml[i].anchor_asset_type === "fiat") continue;
            alldata.push({
              asset: currenciesfromtoml[i].code,
              issuer: currenciesfromtoml[i].issuer,
              status: <button className="btn btn-primary" onClick={() => this.maddtrustline(currenciesfromtoml[i].code, currenciesfromtoml[i].issuer)}>Add a trustline</button>
            })
          }
          this.setState({
            data: {
              columns: [
                {
                  label: 'Asset',
                  field: 'asset',
                  sort: 'asc',
                  width: 200
                },
                {
                  label: 'Issuer',
                  field: 'issuer',
                  sort: 'asc',
                  width: 200
                },
                {
                  label: 'Status',
                  field: 'status',
                  sort: 'asc',
                  width: 200
                }
              ],
              rows: alldata
            }
          })
        })
    }
  }

  maddtrustline(asset, issuer) {
    if (this.props.kyc === true) {
      let obj = {
        asset: asset,
        issuer: issuer,
        public_key: this.props.currentwallet.public_key
      }
      var me = this;
      this.dialog.show({
        body: 'Input your currently wallet password.',
        prompt: Dialog.PasswordPrompt({ placeholder: 'secret', required: true }),
        actions: [
          Dialog.CancelAction(),
          Dialog.OKAction((dialog) => {
            let password = dialog.value
            obj.password = password;
            me.props.addtrustline(obj);
          })
        ]
      })
    } else {
      toast.warning("Please verify your identify first.", {
        position: "top-center",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps !== this.props) {
      this.setState({ loading: 0 })
    }
  }

  render() {
    return (
      <>
        <div className="left-container">
          {/*Awaiting Funds Section*/}
          <div className="row">
            {/*Awaiting Funds box*/}
            <div className="col-md-6 col-sm-12 col-12">
              <div className="analitics-box awaiting-funds-box">
                <h2>Awaiting funds <a href="#" className="view-more"><img src="assets/img/right-arrow.svg" alt="" /></a>
                </h2>
                <div className="chart-box">
                  <img src="assets/img/chart-img.png" alt="" />
                </div>
                <h3>20</h3>
              </div>
            </div>
            {/*Awaiting Funds box*/}
            {/*Awaiting Funds box*/}
            <div className="col-md-6 col-sm-12 col-12">
              <div className="analitics-box awaiting-funds-box">
                <h2>Awaiting funds <a href="#" className="view-more"><img src="assets/img/right-arrow.svg" alt="" /></a>
                </h2>
                <div className="chart-box">
                  <img src="assets/img/chart-img.png" alt="" />
                </div>
                <h3>20</h3>
              </div>
            </div>
            {/*Awaiting Funds box*/}
          </div>
          {/*Awaiting Funds Section*/}
          {/*Awaiting Funds Section*/}
          <div className="row">
            {/*Awaiting Funds box*/}
            <div className="col-md-6 col-sm-12 col-12">
              <div className="analitics-box awaiting-funds-box">
                <h2>Awaiting funds <a href="#" className="view-more"><img src="assets/img/right-arrow.svg" alt="" /></a>
                </h2>
                <div className="chart-box">
                  <img src="assets/img/chart-img.png" alt="" />
                </div>
                <h3>20</h3>
              </div>
            </div>
            {/*Awaiting Funds box*/}
            {/*Awaiting Funds box*/}
            <div className="col-md-6 col-sm-12 col-12">
              <div className="analitics-box awaiting-funds-box">
                <h2>Awaiting funds <a href="#" className="view-more"><img src="assets/img/right-arrow.svg" alt="" /></a>
                </h2>
                <div className="chart-box">
                  <img src="assets/img/chart-img.png" alt="" />
                </div>
                <h3>20</h3>
              </div>
            </div>
            {/*Awaiting Funds box*/}
          </div>
          {/*Awaiting Funds Section*/}
        </div>

      </>
    )
  }
}

function walletget(state) {
  return {
    kyc: state.userdata.kyc,
    currentwallet: state.stellar.currentwallet,
    addtrustline: state.stellar.addtrustline,
    allasets: state.stellar.allasets
  }
}

export default connect(walletget, { addtrustline })(Trustline);