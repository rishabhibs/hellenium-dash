import React from 'react'
import { MDBDataTable } from 'mdbreact'
import { StellarTomlResolver } from 'stellar-sdk'
import { connect } from "react-redux";
import { toast } from 'react-toastify';

import Dialog from 'react-bootstrap-dialog'

import { addtrustline } from '../../../../../redux/actions/wallets';

import config from '../../../../../config';
import "../../../../../assets/scss/simpleStyle.scss";

class Trustline extends React.Component {

  constructor() {
    super()
    this.state = {
      walletsdata: [],
      toml: {},
      loading: 0,
      data: null
    }
  }

  UNSAFE_componentWillMount() {
    if (config.dev === true) {
      StellarTomlResolver.resolve(config.toml_url, { allowHttp: true })
        .then(async (toml) => {
          var alldata = [];
          let currenciesfromtoml = toml.CURRENCIES;
          for (let i = 0; i < currenciesfromtoml.length; i++) {
            if (currenciesfromtoml[i].anchor_asset_type === "fiat") continue;
            alldata.push({
              asset: currenciesfromtoml[i].code,
              issuer: currenciesfromtoml[i].issuer,
              status: <button className="btn btn-primary" onClick={() => this.maddtrustline(currenciesfromtoml[i].code, currenciesfromtoml[i].issuer)}>Add a trustline</button>
            })
          }
          this.setState({
            data: {
              columns: [
                {
                  label: 'Asset',
                  field: 'asset',
                  sort: 'asc',
                  width: 200
                },
                {
                  label: 'Issuer',
                  field: 'issuer',
                  sort: 'asc',
                  width: 200
                },
                {
                  label: 'Status',
                  field: 'status',
                  sort: 'asc',
                  width: 200
                }
              ],
              rows: alldata
            }
          })
        })
    } else {
      StellarTomlResolver.resolve(config.toml_url)
        .then(async (toml) => {
          var alldata = [];
          let currenciesfromtoml = toml.CURRENCIES;
          for (let i = 0; i < currenciesfromtoml.length; i++) {
            if (currenciesfromtoml[i].anchor_asset_type === "fiat") continue;
            alldata.push({
              asset: currenciesfromtoml[i].code,
              issuer: currenciesfromtoml[i].issuer,
              status: <button className="btn btn-primary" onClick={() => this.maddtrustline(currenciesfromtoml[i].code, currenciesfromtoml[i].issuer)}>Add a trustline</button>
            })
          }
          this.setState({
            data: {
              columns: [
                {
                  label: 'Asset',
                  field: 'asset',
                  sort: 'asc',
                  width: 200
                },
                {
                  label: 'Issuer',
                  field: 'issuer',
                  sort: 'asc',
                  width: 200
                },
                {
                  label: 'Status',
                  field: 'status',
                  sort: 'asc',
                  width: 200
                }
              ],
              rows: alldata
            }
          })
        })
    }
  }

  maddtrustline(asset, issuer) {
    if (this.props.kyc === true) {
      let obj = {
        asset: asset,
        issuer: issuer,
        public_key: this.props.currentwallet.public_key
      }
      var me = this;
      this.dialog.show({
        body: 'Input your currently wallet password.',
        prompt: Dialog.PasswordPrompt({ placeholder: 'secret', required: true }),
        actions: [
          Dialog.CancelAction(),
          Dialog.OKAction((dialog) => {
            let password = dialog.value
            obj.password = password;
            me.props.addtrustline(obj);
          })
        ]
      })
    } else {
      toast.warning("Please verify your identify first.", {
        position: "top-center",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps !== this.props) {
      this.setState({ loading: 0 })
    }
  }

  render() {
    return (
      <div className="d-flex flex-column-fluid">
        <div className="container py-8">
          <div className="row">
            <div className="col-lg-12 col-xxl-12">
              <div className="card card-custom mb-8 mb-lg-0">
                <Dialog ref={(component) => { this.dialog = component }} />
                <div className="card-header border-0 pt-5">
                  <h3 className="card-title align-items-start flex-column">
                    <span className="card-label font-weight-bolder text-dark">Trustline</span>
                    <span className="text-muted mt-3 font-weight-bold font-size-sm">By adding a trustline, you can use the asset</span>
                  </h3>
                </div>
                <div className="card-body">
                  <div className="row">
                    <div className="card card-custom wave wave-animate-slow wave-primary mb-8 mb-lg-0 w-100">
                      <div className="card-body">
                        <div className="row overflow-auto">
                          {
                            this.state.data !== null ?
                              <MDBDataTable
                                striped
                                bordered
                                small
                                hover
                                className="w-98"
                                data={this.state.data}
                              /> :
                              <h3 className="card-title align-items-center text-center flex-column w-100">
                                There is no else assets to add a trustline.
                                                            </h3>
                          }
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

function walletget(state) {
  return {
    kyc: state.userdata.kyc,
    currentwallet: state.stellar.currentwallet,
    addtrustline: state.stellar.addtrustline,
    allasets: state.stellar.allasets
  }
}

export default connect(walletget, { addtrustline })(Trustline);