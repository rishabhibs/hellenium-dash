import React from 'react'
import { connect } from 'react-redux'
import Select from 'react-select'
import Spinner from 'react-bootstrap/Spinner'
import { toast } from 'react-toastify'
import { StellarTomlResolver } from 'stellar-sdk'
import { deposit } from '../../../../../redux/actions/buy'
import { AiFillCopy } from 'react-icons/ai';
import Iban from 'iban';
import config from '../../../../../config'

import '../../../../../assets/css/type-select.css'

class Deposit extends React.Component {
    constructor() {
        super();
        this.state = {
            amount: 2,
            main: "",
            options: [],
            paytype: "paypal",
            targetOption: {},
            loading: 0,
            ibannumber: "",
            disablebutton: false,
            selectStyle: {
                control: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 300
                }),
                menu: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 300
                })
            }
        }
    }

    UNSAFE_componentWillMount() {
        let me = this;
        if(config.dev === true ) {
            StellarTomlResolver.resolve(config.toml_url, { allowHttp:true })
            .then(toml => {
                let currencies = toml.CURRENCIES;
                let arr = [];
                for(let i = 0 ; i < currencies.length ; i++) {
                    if(currencies[i].anchor_asset_type === "crypto")continue;
                    arr.push({
                        value: currencies[i].code,
                        label: currencies[i].code
                    })
                }
                me.setState({
                    options: arr,
                    targetOption: arr[0]
                });
            })
        } else {
            StellarTomlResolver.resolve(config.toml_url)
            .then(toml => {
                let currencies = toml.CURRENCIES;
                let arr = [];
                for(let i = 0 ; i < currencies.length ; i++) {
                    if(currencies[i].anchor_asset_type === "crypto")continue;
                    arr.push({
                        value: currencies[i].code,
                        label: currencies[i].code
                    })
                }
                me.setState({
                    options: arr,
                    targetOption: arr[0]
                });
            })
        }
    }
    
    copyText() {
        var copyinput = document.createElement("input");
        copyinput.setAttribute("id", "copytext");
        copyinput.setAttribute("value", config.iban);
        document.body.append(copyinput);
        var copyText = document.getElementById("copytext");
        copyText.select();
        document.execCommand("copy");
        copyinput.remove();

        toast.success("IBAN copied successfully!", {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    }

    depositc() {
        if(this.props.kyc === true) {
            if(Iban.isValid(this.state.ibannumber) === false) {
                this.errmessage("Please input your corret iban number!");
            } else if(this.state.amount < 2) {
                this.errmessage("Deposit minimum amount is 2!");
            } else if(this.state.ibannumber === config.iban) {
                this.errmessage("This is our iban!");
            } else {
                this.props.deposit({
                    iban: this.state.ibannumber,
                    amount: this.state.amount,
                    currency: this.state.targetOption.value
                })
            }
        } else {
            toast.warning("Please verify your identify first.", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });   
        }
    }

    errmessage(str) {
        toast.error(str, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    }

    render () {
        return (
          <div className="left-container">
          <div className="transaction-history-section-container"> 
            <div className="row title-row">
              <div className="col-md-12">
                <h2>Verify your Identity now</h2>
                <h3>You can verify your identity for SoNiceSoNice UK Ltd by clicking verification button below</h3>
              </div>             
            </div>
            <div className="row">
              {/*Transaction Table */}
              <div className="col-md-12 col-lg-12 col-xl-12 col-sm-12 col-12"> 
                <div className="business-kyc-content">  
                  <form className="form-business-kyc">
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Additional Name" className="label">Additional Name</label>
                          <input type="text" id="Additional Name" className="form-control" placeholder="Enter Additional Name" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">                      
                        <div className="form-box"> 
                          <label htmlFor="Organization VAT Number" className="label">Address Country Code</label>      
                          <div className="select-control-wrapper custom-select-box">
                            <select className="form-control">
                              <option>United Kingdom</option>
                              <option>Hola</option>
                              <option>United Kingdom</option>
                              <option>Hola</option>
                              <option>United Kingdom</option>
                              <option>Hola</option>
                              <option>Hola</option>
                              <option>Hola</option>
                              <option>Hola</option>
                              <option>Hola</option> 
                              <option>Hola</option>
                              <option>Hola</option>
                              <option>Hola</option>
                              <option>Hola</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="State or Province" className="label">State or Province</label>
                          <input type="text" id="State or Province" className="form-control" placeholder="Enter State or Province" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="City" className="label">City</label>
                          <input type="text" id="City" className="form-control" placeholder="Enter City" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Postal Code" className="label">Postal Code</label>
                          <input type="text" id="Postal Code" className="form-control" placeholder="Enter Postal Code" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Address" className="label">Address</label>
                          <input type="text" id="Address" className="form-control" placeholder="Enter Address" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Mobile Number" className="label">Mobile Number</label>
                          <input type="text" id="Mobile Number" className="form-control" placeholder="Enter Mobile Number" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Email Address" className="label">Email Address</label>
                          <input type="text" id="Email Address" className="form-control" placeholder="Enter Email Address " />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Birth Date" className="label">Birth Date</label>
                          <input type="date" id="Birth Date" className="form-control" placeholder=" -- / -- / -- " />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Birth Place" className="label">Birth Place</label>
                          <input type="text" id="Birth Place" className="form-control" placeholder="Enter Birth Place" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Birth Country Code" className="label">Birth Country Code</label>
                          <input type="text" id="Birth Country Code" className="form-control" placeholder="Enter Birth Country Code" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Bank Account Number" className="label">Bank Account Number</label>
                          <input type="text" id="Bank Account Number" className="form-control" placeholder="Enter Bank Account Number" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Bank Routing Number" className="label">Bank Routing Number</label>
                          <input type="text" id="Bank Routing Number" className="form-control" placeholder="Enter Bank Routing Number" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Website" className="label">Bank Phone Number</label>
                          <input type="text" id="Organization Website" className="form-control" placeholder="Enter Bank Phone Number" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Email " className="label">Bank Branch Number</label>
                          <input type="text" id="Organization Email " className="form-control" placeholder="Enter Bank Branch Number" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Phone" className="label">Tax Id</label>
                          <input type="text" id="Organization Phone" className="form-control" placeholder="Enter Tax Id" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Email " className="label">Tax Owner Name</label>
                          <input type="text" id="Organization Email " className="form-control" placeholder="Enter Tax Owner Name" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Phone" className="label">Occupation</label>
                          <input type="text" id="Organization Phone" className="form-control" placeholder="Enter Occupation" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Email " className="label">Employer Name</label>
                          <input type="text" id="Organization Email " className="form-control" placeholder="Enter Employer Name" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Phone" className="label">Employer Address</label>
                          <input type="text" id="Organization Phone" className="form-control" placeholder="Enter Employer Address" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Email " className="label">Language Code</label>
                          <input type="text" id="Organization Email " className="form-control" placeholder="Enter Language Code" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    <button className="btn btn-submit verify-my-id" type="submit"><span><img src="assets/img/pass-base-icon.png" /></span>Verify my Identity</button>
                  </form>
                </div>
              </div>
              {/*Transaction Table */}
            </div>
            {/**/}
          </div>
        </div>
        
          
        )
    }
}

function done(state) {
    return {
        kyc: state.userdata.kyc,
        kyb: state.userdata.kyb
    }
}

export default connect(done, { deposit })(Deposit);