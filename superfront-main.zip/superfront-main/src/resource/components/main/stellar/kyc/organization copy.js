import React from 'react';
import Spinner from 'react-bootstrap/Spinner'
import { connect } from "react-redux";
import { toast } from 'react-toastify';

import { allasets } from '../../../../../redux/actions/balances';
import { personal_kyb_save } from '../../../../../redux/actions/kyc';

class KYCorganization extends React.Component {

  constructor() {
    super()
    this.state = {
      loading: 0,
      country: "United Kingdom",
      date: "",
      passbase: "",
      needfields: [
        {
          name: 'organization_name',
          placeholderName: 'Organization Name',
        }, {
          name: 'organization_VAT_number',
          placeholderName: 'Organization VAT Number',
        }, {
          name: 'organization_registration_number',
          placeholderName: 'Organization Registration Number',
        }, {
          name: 'organization_registered_address',
          placeholderName: 'Organization Registered Address',
        }, {
          name: 'organization_number_of_shareholders',
          placeholderName: 'Organization Number of Shareholders',
        }, {
          name: 'organization_shareholder_name',
          placeholderName: 'Organization Shareholder Name',
        }, {
          name: 'organization_photo_incorporation_doc',
          placeholderName: 'Organization Photo Incorporation Doc',
        }, {
          name: 'organization_photo_proof_adress',
          placeholderName: 'Organization Photo Proof Address',
        }, {
          name: 'organization_address_country_code',
          placeholderName: 'Organization Address Country Code',
        }, {
          name: 'organization_state_or_province',
          placeholderName: 'Organization State or Province',
        }, {
          name: 'organization_city',
          placeholderName: 'Organization City',
        }, {
          name: 'organization_postal_code',
          placeholderName: 'Organization Postal Code',
        }, {
          name: 'organization_director_name',
          placeholderName: 'Organization Director Name',
        }, {
          name: 'organization_website',
          placeholderName: 'Organization Website',
        }, {
          name: 'organization_email',
          placeholderName: 'Organization Email',
        }, {
          name: 'organization_phone',
          placeholderName: 'Organization Phone',
        }, {
          name: 'organization_phone',
          placeholderName: 'Organization Phone',
        }
      ],

    }
  }

  correctinput(str) {
    toast.error(str, {
      position: "top-right",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  }

  successinput(str) {
    toast.success(str, {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  }

  referenceUserWithKey(result) {
    this.props.passbasecheck(result);
  }

  kycPut() {
    if (this.props.kyc !== true) {
      this.correctinput(`Sorry!, You have to pass KYC first.`);
    } else {
      var kycinfo = {};
      var needf = this.state.needfields;
      var flag = {
        status: true,
        content: ""
      };
      for (var i = 0; i < needf.length; i++) {
        if (!this.refs[needf[i].name].value) {
          flag.flag = false;
          flag.content = needf[i].name;
        }
        kycinfo[needf[i].name] = this.refs[needf[i].name].value;
      }

      if (flag.flag === false) {
        this.correctinput(`Sorry!, You are missing or invalid ${flag.content}! Please check again.`);
        return;
      }
      this.setState({ loading: 1 })
      this.props.personal_kyb_save(kycinfo);
    }
  }

  selectCountry(val) {
    this.setState({ country: val });
  }

  changedate(val) {
    this.setState({ date: val });
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps !== this.props) {
      this.setState({ loading: 0 })
    }
    if (nextProps.passbase) {
      console.log("=====> ", nextProps.passbase);
    }
  }

  render() {
    return (
      <>
      </>
      // <div className="d-flex flex-column-fluid">
      //   <div className="container py-8">
      //     <div className="row">
      //       <div className="col-lg-12 col-xxl-12">
      //         <div className="card card-custom mb-8 mb-lg-0">
      //           <div className="card-header border-0 pt-5">
      //             <h3 className="card-title align-items-start flex-column">
      //               <span className="card-label font-weight-bolder text-dark">Verify your identity now</span>
      //               <span className="text-muted mt-3 font-weight-bold font-size-sm">You can verify your identity for SoNiceSoNice UK Ltd by clicking the verification button below</span>
      //             </h3>
      //           </div>
      //           <div className="card-body">
      //             {
      //               this.props.kyb === true ?
      //                 <div className="row">
      //                   <div className="card card-custom wave wave-animate-slow wave-primary mb-8 mb-lg-0 w-100">
      //                     <div className="card-body">
      //                       <h3 className="card-title align-items-start flex-column">
      //                         <span className="card-label font-weight-bolder text-dark">You have already verified business identify</span>
      //                       </h3>
      //                     </div>
      //                   </div>
      //                 </div> :
      //                 <div className="row">
      //                   <div className="card card-custom wave wave-animate-slow wave-primary mb-8 mb-lg-0 w-100">
      //                     <div className="card-body">
      //                       <div className="row col-lg-12">
      //                         {
      //                           this.state.needfields.map((data, index) => {
      //                             return <div className="col-lg-6 mt-3" key={index + '-kycfields'}>
      //                               <label>{data.placeholderName}</label>
      //                               <div className="input-group type-select">
      //                                 <input type="text" className="form-control" name={data.name} placeholder={`Enter ${data.placeholderName}`} ref={data.name} />
      //                               </div>
      //                             </div>
      //                           })
      //                         }
      //                         <div className="col-lg-12 mt-10 justify-content-end d-flex">
      //                           <button onClick={() => this.kycPut()} className="btn btn-primary h-100">
      //                             {this.state.loading === 1 ? <Spinner animation="border" /> : "Submit"}
      //                           </button>
      //                         </div>
      //                       </div>
      //                     </div>
      //                   </div>
      //                 </div>
      //             }
      //           </div>
      //         </div>
      //       </div>
      //     </div>
      //   </div>
      // </div>
    )
  }
}

function done(state) {
  return {
    kyc: state.userdata.kyc,
    kyb: state.userdata.kyb
  }
}

export default connect(done, { allasets, personal_kyb_save })(KYCorganization);