import React from 'react';
import Spinner from 'react-bootstrap/Spinner'
import { connect } from "react-redux";
import { toast } from 'react-toastify';

import { allasets } from '../../../../../redux/actions/balances';
import { personal_kyb_save } from '../../../../../redux/actions/kyc';

class KYCorganization extends React.Component {

  constructor() {
    super()
    this.state = {
      loading: 0,
      country: "United Kingdom",
      date: "",
      passbase: "",
      needfields: [
        {
          name: 'organization_name',
          placeholderName: 'Organization Name',
        }, {
          name: 'organization_VAT_number',
          placeholderName: 'Organization VAT Number',
        }, {
          name: 'organization_registration_number',
          placeholderName: 'Organization Registration Number',
        }, {
          name: 'organization_registered_address',
          placeholderName: 'Organization Registered Address',
        }, {
          name: 'organization_number_of_shareholders',
          placeholderName: 'Organization Number of Shareholders',
        }, {
          name: 'organization_shareholder_name',
          placeholderName: 'Organization Shareholder Name',
        }, {
          name: 'organization_photo_incorporation_doc',
          placeholderName: 'Organization Photo Incorporation Doc',
        }, {
          name: 'organization_photo_proof_adress',
          placeholderName: 'Organization Photo Proof Address',
        }, {
          name: 'organization_address_country_code',
          placeholderName: 'Organization Address Country Code',
        }, {
          name: 'organization_state_or_province',
          placeholderName: 'Organization State or Province',
        }, {
          name: 'organization_city',
          placeholderName: 'Organization City',
        }, {
          name: 'organization_postal_code',
          placeholderName: 'Organization Postal Code',
        }, {
          name: 'organization_director_name',
          placeholderName: 'Organization Director Name',
        }, {
          name: 'organization_website',
          placeholderName: 'Organization Website',
        }, {
          name: 'organization_email',
          placeholderName: 'Organization Email',
        }, {
          name: 'organization_phone',
          placeholderName: 'Organization Phone',
        }, {
          name: 'organization_phone',
          placeholderName: 'Organization Phone',
        }
      ],

    }
  }

  correctinput(str) {
    toast.error(str, {
      position: "top-right",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  }

  successinput(str) {
    toast.success(str, {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  }

  referenceUserWithKey(result) {
    this.props.passbasecheck(result);
  }

  kycPut() {
    if (this.props.kyc !== true) {
      this.correctinput(`Sorry!, You have to pass KYC first.`);
    } else {
      var kycinfo = {};
      var needf = this.state.needfields;
      var flag = {
        status: true,
        content: ""
      };
      for (var i = 0; i < needf.length; i++) {
        if (!this.refs[needf[i].name].value) {
          flag.flag = false;
          flag.content = needf[i].name;
        }
        kycinfo[needf[i].name] = this.refs[needf[i].name].value;
      }

      if (flag.flag === false) {
        this.correctinput(`Sorry!, You are missing or invalid ${flag.content}! Please check again.`);
        return;
      }
      this.setState({ loading: 1 })
      this.props.personal_kyb_save(kycinfo);
    }
  }

  selectCountry(val) {
    this.setState({ country: val });
  }

  changedate(val) {
    this.setState({ date: val });
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps !== this.props) {
      this.setState({ loading: 0 })
    }
    if (nextProps.passbase) {
      console.log("=====> ", nextProps.passbase);
    }
  }

  render() {
    return (
      <>
        {/* <main role="main" className="main">
          <div className="left-container"> */}
        <div className="transaction-history-section-container">
          <div className="row title-row">
            <div className="col-md-12">
              <h2>Verify your Organization now</h2>
              <h3>You can verify your Organization for SoNiceSoNice UK Ltd by clicking verification button below</h3>
            </div>
          </div>
          <div className="row">
            {/*Transaction Table */}
            <div className="col-md-12 col-lg-12 col-xl-12 col-sm-12 col-12">
              <div className="business-kyc-content">
                <form className="form-business-kyc">
                  {/*Field row*/}
                  <div className="row">
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organization Name" className="label">Organization Name</label>
                        <input type="text" id="Organization Name" className="form-control" placeholder="Enter Organization Name" />
                      </div>
                    </div>
                    {/*Field box*/}
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organization VAT Number" className="label">Organization VAT Number</label>
                        <input type="text" id="Organization VAT Number" className="form-control" placeholder="Enter Organization VAT Number" required />
                      </div>
                    </div>
                    {/*Field box*/}
                  </div>
                  {/*Field row*/}
                  {/*Field row*/}
                  <div className="row">
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organisation Registration Number " className="label">Organisation Registration Number </label>
                        <input type="text" id="Organisation Registration Number " className="form-control" placeholder="Enter Organisation Registration Number" />
                      </div>
                    </div>
                    {/*Field box*/}
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organization Registered Address" className="label">Organization Registered Address</label>
                        <input type="text" id="Organization Registered Address" className="form-control" placeholder="Enter Organization Registered Address" />
                      </div>
                    </div>
                    {/*Field box*/}
                  </div>
                  {/*Field row*/}
                  {/*Field row*/}
                  <div className="row">
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organisation Number of Shareholders" className="label">Organisation Number of Shareholders </label>
                        <input type="text" id="Organisation Number of Shareholders" className="form-control" placeholder="Enter Organisation Number of Shareholders" />
                      </div>
                    </div>
                    {/*Field box*/}
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organization Shareholder Name " className="label">Organization Shareholder Name </label>
                        <input type="text" id="Organization Shareholder Name" className="form-control" placeholder="Enter Organization Shareholder Name" />
                      </div>
                    </div>
                    {/*Field box*/}
                  </div>
                  {/*Field row*/}
                  {/*Field row*/}
                  <div className="row">
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organization Photo Incorporation Doc" className="label">Organization Photo Incorporation Doc</label>
                        <input type="text" id="Organization Photo Incorporation Doc" className="form-control" placeholder="Enter Organisation Photo Incorporation Doc" />
                      </div>
                    </div>
                    {/*Field box*/}
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organization Photo Proof Address" className="label">Organization Photo Proof Address </label>
                        <input type="text" id="Organization Photo Proof Address" className="form-control" placeholder="Enter Organization Photo Proof Address" />
                      </div>
                    </div>
                    {/*Field box*/}
                  </div>
                  {/*Field row*/}
                  {/*Field row*/}
                  <div className="row">
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organization Address Country Code" className="label">Organization Address Country Code</label>
                        <input type="text" id="Organization Address Country Code" className="form-control" placeholder="Enter Organization Address Country Code" />
                      </div>
                    </div>
                    {/*Field box*/}
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organization State or Province" className="label">Organization State or Province</label>
                        <input type="text" id="Organization State or Province" className="form-control" placeholder="Enter Organization State or Province" />
                      </div>
                    </div>
                    {/*Field box*/}
                  </div>
                  {/*Field row*/}
                  {/*Field row*/}
                  <div className="row">
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organisation City" className="label">Organisation City </label>
                        <input type="text" id="Organisation City" className="form-control" placeholder="Enter Organization City" />
                      </div>
                    </div>
                    {/*Field box*/}
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organization Postal Code" className="label">Organization Postal Code</label>
                        <input type="text" id="Organization Postal Code" className="form-control" placeholder="Enter Organization Postal Code" />
                      </div>
                    </div>
                    {/*Field box*/}
                  </div>
                  {/*Field row*/}
                  {/*Field row*/}
                  <div className="row">
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organization Director Name" className="label">Organization Director Name</label>
                        <input type="text" id="Organization Director Name" className="form-control" placeholder="Enter Organization Director Name" />
                      </div>
                    </div>
                    {/*Field box*/}
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organization Website" className="label">Organization Website</label>
                        <input type="text" id="Organization Website" className="form-control" placeholder="Enter Organisation Website" />
                      </div>
                    </div>
                    {/*Field box*/}
                  </div>
                  {/*Field row*/}
                  {/*Field row*/}
                  <div className="row">
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organization Email " className="label">Organization Email </label>
                        <input type="text" id="Organization Email " className="form-control" placeholder="Enter Organization Email" />
                      </div>
                    </div>
                    {/*Field box*/}
                    {/*Field box*/}
                    <div className="col-md-6">
                      <div className="form-box">
                        <label htmlFor="Organization Phone" className="label">Organization Phone</label>
                        <input type="text" id="Organization Phone" className="form-control" placeholder="Enter Organization Phone" />
                      </div>
                    </div>
                    {/*Field box*/}
                  </div>
                  {/*Field row*/}
                  <button className="btn btn-submit" type="submit">Verify my Organization</button>
                </form>
              </div>
            </div>
            {/*Transaction Table */}
          </div>
          {/**/}
        </div>
      </>
    )
  }
}

function done(state) {
  return {
    kyc: state.userdata.kyc,
    kyb: state.userdata.kyb
  }
}

export default connect(done, { allasets, personal_kyb_save })(KYCorganization);