import React from 'react';
import Spinner from 'react-bootstrap/Spinner'
import VerifyButton from "@passbase/button/react";
import { CountryDropdown } from 'react-country-region-selector';
import brnv from 'bank-routing-number-validator'
import * as EmailValidator from 'email-validator';
import DatePicker from 'react-date-picker';
import { connect } from "react-redux";
import { toast } from 'react-toastify';

import { allasets } from '../../../../../redux/actions/balances';
import { personal_kyc_save } from '../../../../../redux/actions/kyc';
import config from '../../../../../config'

// import { postcodeValidator, postcodeValidatorExistsForCountry } from 'postcode-validator';
// postcodeValidator('W85TT', 'GB');
// postcodeValidator('1234567', 'GB'); 

class KYCpersonal extends React.Component {

  constructor() {
    super()
    this.state = {
      loading: 0,
      country: "United Kingdom",
      date: "",
      passbase: "",
      disablestatus: false,
      identityAccessKey: '',
      needfields: [
        {
          name: 'additional_name',
          placeholderName: 'Additional Name',
        }, {
          name: 'address_country_code',
          placeholderName: 'Address Country Code',
        }, {
          name: 'state_or_province',
          placeholderName: 'State or Province',
        }, {
          name: 'city',
          placeholderName: 'City',
        }, {
          name: 'postal_code',
          placeholderName: 'Postal Code',
        }, {
          name: 'address',
          placeholderName: 'Address',
        }, {
          name: 'mobile_number',
          placeholderName: 'Mobile Number',
        }, {
          name: 'email_address',
          placeholderName: 'Email Address',
        }, {
          name: 'birth_date',
          placeholderName: 'Birth Date',
        }, {
          name: 'birth_place',
          placeholderName: 'Birth Place',
        }, {
          name: 'birth_country_code',
          placeholderName: 'Birth Country Code',
        }, {
          name: 'bank_account_number',
          placeholderName: 'Bank Account Number',
        }, {
          name: 'bank_number',
          placeholderName: 'Bank Routing Number',
        }, {
          name: 'bank_phone_number',
          placeholderName: 'Bank Phone Number',
        }, {
          name: 'bank_branch_number',
          placeholderName: 'Bank Branch Number',
        }, {
          name: 'tax_id',
          placeholderName: 'Tax Id',
        }, {
          name: 'tax_id_name',
          placeholderName: 'Tax Owner Name',
        }, {
          name: 'occupation',
          placeholderName: 'Occupation',
        }, {
          name: 'employer_name',
          placeholderName: 'Employer Name',
        }, {
          name: 'employer_address',
          placeholderName: 'Employer Address',
        }, {
          name: 'language_code',
          placeholderName: 'Language Code',
        }, {
          name: 'passbase',
          placeholderName: 'Passbase',
        }
      ],

    }
  }

  correctinput(str) {
    toast.error(str, {
      position: "top-right",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  }

  successinput(str) {
    toast.success(str, {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  }

  referenceUserWithKey(identityAccessKey) {
    this.setState({ passbase: true, identityAccessKey: identityAccessKey })
    // this.props.passbasecheck(identityAccessKey);
  }

  kycPut() {
    var kycinfo = {};
    var needf = this.state.needfields;
    var flag = {
      status: true,
      content: ""
    };
    for (var i = 0; i < needf.length; i++) {
      if (needf[i].name === "passbase") {
        if (this.state.passbase === "") {
          flag.flag = false;
          flag.content = "passbase";
        }
        kycinfo['passbase'] = this.state.passbase;
      } else if (needf[i].name === "address_country_code") {
        kycinfo[needf[i].name] = this.state.country;
      } else if (needf[i].name === "email_address") {
        if (EmailValidator.validate(this.refs[needf[i].name].value) !== true) {
          flag.flag = false;
          flag.content = "email";
        }
      } else if (needf[i].name === "bank_number") {
        if (brnv.ABARoutingNumberIsValid(this.refs[needf[i].name].value) !== true) {
          flag.flag = false;
          flag.content = "Bank Routing Number";
        }
      } else if (needf[i].name === "birth_date") {
        kycinfo[needf[i].name] = this.state.date;
      } else if (this.refs[needf[i].name].value === "") {
        flag.flag = false;
        flag.content = needf[i].placeholderName;
      } else {
        kycinfo[needf[i].name] = this.refs[needf[i].name].value;
      }
    }

    if (flag.flag === false) {
      this.correctinput(`Sorry!, You are missing or invalid ${flag.content}! Please check again.`);
      if (config.dev !== true) {
        return;
      }
    }

    kycinfo['identityAccessKey'] = this.state.identityAccessKey;

    this.setState({ loading: 1, disablestatus: true })
    this.props.personal_kyc_save(kycinfo);
  }

  selectCountry(val) {
    this.setState({ country: val });
  }

  changedate(val) {
    this.setState({ date: val });
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps !== this.props) {
      if (nextProps.passbase) {
        this.setState({
          passbase: nextProps.passbase
        })
      }
      this.setState({ loading: 0, disablestatus: false })
    }
  }

  render() {
    return (
      <>
        <div className="left-container">
          <div className="transaction-history-section-container">
            <div className="row title-row">
              <div className="col-md-12">
                <h2>Verify your Identity now</h2>
                <h3>You can verify your identity for SoNiceSoNice UK Ltd by clicking verification button below</h3>
              </div>
            </div>
            <div className="row">
              {/*Transaction Table */}
              <div className="col-md-12 col-lg-12 col-xl-12 col-sm-12 col-12">
                <div className="business-kyc-content">
                  <form className="form-business-kyc">
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Additional Name" className="label">Additional Name</label>
                          <input type="text" id="Additional Name" className="form-control" placeholder="Enter Additional Name" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization VAT Number" className="label">Address Country Code</label>
                          <div className="select-control-wrapper custom-select-box">
                            <select className="form-control">
                              <option>United Kingdom</option>
                              <option>Hola</option>
                              <option>United Kingdom</option>
                              <option>Hola</option>
                              <option>United Kingdom</option>
                              <option>Hola</option>
                              <option>Hola</option>
                              <option>Hola</option>
                              <option>Hola</option>
                              <option>Hola</option>
                              <option>Hola</option>
                              <option>Hola</option>
                              <option>Hola</option>
                              <option>Hola</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="State or Province" className="label">State or Province</label>
                          <input type="text" id="State or Province" className="form-control" placeholder="Enter State or Province" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="City" className="label">City</label>
                          <input type="text" id="City" className="form-control" placeholder="Enter City" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Postal Code" className="label">Postal Code</label>
                          <input type="text" id="Postal Code" className="form-control" placeholder="Enter Postal Code" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Address" className="label">Address</label>
                          <input type="text" id="Address" className="form-control" placeholder="Enter Address" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Mobile Number" className="label">Mobile Number</label>
                          <input type="text" id="Mobile Number" className="form-control" placeholder="Enter Mobile Number" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Email Address" className="label">Email Address</label>
                          <input type="text" id="Email Address" className="form-control" placeholder="Enter Email Address " />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Birth Date" className="label">Birth Date</label>
                          <input type="date" id="Birth Date" className="form-control" placeholder=" -- / -- / -- " />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Birth Place" className="label">Birth Place</label>
                          <input type="text" id="Birth Place" className="form-control" placeholder="Enter Birth Place" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Birth Country Code" className="label">Birth Country Code</label>
                          <input type="text" id="Birth Country Code" className="form-control" placeholder="Enter Birth Country Code" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Bank Account Number" className="label">Bank Account Number</label>
                          <input type="text" id="Bank Account Number" className="form-control" placeholder="Enter Bank Account Number" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Bank Routing Number" className="label">Bank Routing Number</label>
                          <input type="text" id="Bank Routing Number" className="form-control" placeholder="Enter Bank Routing Number" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Website" className="label">Bank Phone Number</label>
                          <input type="text" id="Organization Website" className="form-control" placeholder="Enter Bank Phone Number" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Email " className="label">Bank Branch Number</label>
                          <input type="text" id="Organization Email " className="form-control" placeholder="Enter Bank Branch Number" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Phone" className="label">Tax Id</label>
                          <input type="text" id="Organization Phone" className="form-control" placeholder="Enter Tax Id" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Email " className="label">Tax Owner Name</label>
                          <input type="text" id="Organization Email " className="form-control" placeholder="Enter Tax Owner Name" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Phone" className="label">Occupation</label>
                          <input type="text" id="Organization Phone" className="form-control" placeholder="Enter Occupation" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Email " className="label">Employer Name</label>
                          <input type="text" id="Organization Email " className="form-control" placeholder="Enter Employer Name" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Phone" className="label">Employer Address</label>
                          <input type="text" id="Organization Phone" className="form-control" placeholder="Enter Employer Address" />
                        </div>
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    {/*Field row*/}
                    <div className="row">
                      {/*Field box*/}
                      <div className="col-md-6">
                        <div className="form-box">
                          <label htmlFor="Organization Email " className="label">Language Code</label>
                          <input type="text" id="Organization Email " className="form-control" placeholder="Enter Language Code" />
                        </div>
                      </div>
                      {/*Field box*/}
                      {/*Field box*/}
                      <div className="col-md-6">
                      </div>
                      {/*Field box*/}
                    </div>
                    {/*Field row*/}
                    <button className="btn btn-submit verify-my-id" type="submit"><span><img src="assets/img/pass-base-icon.png" /></span>Verify my Identity</button>
                  </form>
                </div>
              </div>
              {/*Transaction Table */}
            </div>
            {/**/}
          </div>
        </div>

      </>
    )
  }
}

function done(state) {
  return {
    kyc: state.userdata.kyc
  }
}

export default connect(done, { allasets, personal_kyc_save })(KYCpersonal);