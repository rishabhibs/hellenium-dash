import React from 'react';
import Select from 'react-select';
import Spinner from 'react-bootstrap/Spinner';
import { connect } from 'react-redux';
import { toast } from 'react-toastify';
import { exchange } from '../../../../../redux/actions/exchange';

import '../../../../../assets/css/type-select.css';


class Exchange extends React.Component {
    constructor() {
        super();
        this.state = {
            toml: {},
            msc1Price: 1.82,
            currentOption: [],
            targetOption: [],
            scurrentOption: {},
            stargetOption: {},
            currency_rates: {},
            currentlyValue: "",
            targetValue: "",
            targetPrice: "",
            target: 0,
            loading: 0,
            disablebutton: false,
            customStyles: {
                control: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 100
                }),
                menu: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 100
                })
            }
        }
    }

    UNSAFE_componentWillMount() {
        this.setState({
            currentOption: this.props.fiatcurrencies,
            targetOption: this.props.fiatcurrencies,
            scurrentOption: this.props.fiatcurrencies[0],
            stargetOption: this.props.fiatcurrencies[0]
        });
    }

    enterCurrentValue(val) {

        var cval = parseFloat(val);
        if(this.state.target === 1) {
            if(this.state.scurrentOption === this.state.stargetOption || val === "") {
                this.setState({
                    currentlyValue: val,
                    targetValue: val
                });
            } else {
                var calcVal = 0;
                var EuroPrice = this.props.europrice;
                var currentValue = this.state.scurrentOption.value;
                var targetValue = this.state.stargetOption.value;
                var targetPrice = "";

                if(this.state.scurrentOption.value === "EUR") {
                    calcVal = cval * EuroPrice[targetValue];
                    targetPrice = EuroPrice[targetValue];
                } else if(this.state.stargetOption.value === "EUR") {
                    calcVal = cval / EuroPrice[currentValue];
                    targetPrice = 1 / EuroPrice[currentValue];
                } else {
                    calcVal = cval * EuroPrice[targetValue] / EuroPrice[currentValue];
                    targetPrice = EuroPrice[targetValue] / EuroPrice[currentValue];
                }

                this.setState({
                    currentlyValue: val,
                    targetValue: calcVal,
                    targetPrice: targetPrice,
                });
            }
        }
    }

    changecurrent(curO) {
        this.setState({
            scurrentOption: curO
        })
        if(curO === this.state.stargetOption || this.state.currentlyValue === "") {
            this.setState({
                currentlyValue: this.state.currentlyValue,
                targetValue: this.state.currentlyValue
            });
        } else {
            var calcVal = 0;
            var curVal = parseFloat(this.state.currentlyValue);
            var EuroPrice = this.props.europrice;
            var currentValue = curO.value;
            var targetValue = this.state.stargetOption.value;
            var targetPrice = "";

            if(curO.value === "EUR") {
                calcVal = curVal * EuroPrice[targetValue];
                targetPrice = EuroPrice[targetValue];
            } else if(this.state.stargetOption.value === "EUR") {
                calcVal = curVal / EuroPrice[currentValue];
                targetPrice = 1 / EuroPrice[currentValue];
            } else {
                calcVal = curVal * EuroPrice[targetValue] / EuroPrice[currentValue];
                targetPrice = EuroPrice[targetValue] / EuroPrice[currentValue];
            }

            this.setState({
                currentlyValue: curVal,
                targetValue: calcVal,
                targetPrice: targetPrice,
            });
        }
    }

    enterTargetValue(val) {
        
        var cval = parseFloat(val);
        if(this.state.target === 2) {
            if(this.state.scurrentOption === this.state.stargetOption || val === "") {
                this.setState({
                    currentlyValue: val,
                    targetValue: val
                });
            } else {
                var calcVal = 0;
                var EuroPrice = this.props.europrice;
                var currentValue = this.state.scurrentOption.value;
                var targetValue = this.state.stargetOption.value;
                var targetPrice = "";

                if(this.state.scurrentOption.value === "EUR") {
                    calcVal = cval / EuroPrice[targetValue];
                    targetPrice = 1 / EuroPrice[targetValue];
                } else if(this.state.stargetOption.value === "EUR") {
                    calcVal = cval * EuroPrice[currentValue];
                    targetPrice = EuroPrice[currentValue];
                } else {
                    calcVal = cval * EuroPrice[currentValue] / EuroPrice[targetValue];
                    targetPrice = EuroPrice[currentValue] / EuroPrice[targetValue];
                }

                this.setState({
                    currentlyValue: calcVal,
                    targetValue: val,
                    targetPrice: targetPrice,
                });
            }
        }
    }

    changetarget(tarO) {
        this.setState({
            stargetOption: tarO
        })
        if(this.state.scurrentOption === tarO || this.state.currentlyValue === "") {
            this.setState({
                currentlyValue: this.state.currentlyValue,
                targetValue: this.state.currentlyValue
            });
        } else {
            var calcVal = 0;
            var curVal = parseFloat(this.state.currentlyValue);
            var EuroPrice = this.props.europrice;
            var currentValue = this.state.scurrentOption.value;
            var targetValue = tarO.value;
            var targetPrice = "";

            if(this.state.scurrentOption.value === "EUR") {
                calcVal = curVal * EuroPrice[targetValue];
                targetPrice = EuroPrice[targetValue];
            } else if(tarO.value === "EUR") {
                calcVal = curVal / EuroPrice[currentValue];
                targetPrice = 1 / EuroPrice[currentValue];
            } else {
                calcVal = curVal * EuroPrice[targetValue] / EuroPrice[currentValue];
                targetPrice = EuroPrice[targetValue] / EuroPrice[currentValue];
            }
            this.setState({
                currentlyValue: curVal,
                targetValue: calcVal,
                targetPrice: targetPrice,
            });
        }
    }

    exchange() {
        if(this.props.kyc === true) {
            if(this.state.currentlyValue === "" || this.state.targetValue === "") {
                toast.error("Input the acount correctly!", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            }
            if(this.state.scurrentOption === this.state.stargetOption) {
                toast.error("Same option!", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            }
            let balances = this.props.allasets.stellar_balance;
    
            let realbal = balances.filter(item => item.asset_code === this.state.scurrentOption.value)[0];
    
            if(parseFloat(this.state.currentlyValue) > parseFloat(realbal.balance)) {
                toast.error("You don't have enough balance!", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            }
            this.setState({loading: 1, disablebutton: true});
            this.props.exchange({
                sourceAssetCode: this.state.scurrentOption.value,
                targetAssetCode: this.state.stargetOption.value,
                exchangeAmount: this.state.currentlyValue,
                targetAmount: this.state.targetValue,
            });
        } else {
            toast.warning("Please verify your identify first.", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(nextProps !== this.props) {
            this.setState({
                loading: 0,
                disablebutton: false
            })
        }
    }

    render () {
        return (
            <div className="d-flex flex-column-fluid">
                <div className="container py-8">
                    <div className="row">
                        <div className="col-lg-12 col-xxl-12">
                            <div className="card card-custom mb-8 mb-lg-0">
                                <div className="card-header border-0 pt-5">
                                    <h3 className="card-title align-items-start flex-column">
                                        <span className="card-label font-weight-bolder text-dark">Exchange</span>
                                        <span className="text-muted mt-3 font-weight-bold font-size-sm">You can exchange without any issues</span>
                                    </h3>
                                </div>
                                <div className="card-body">
                                    <div className="row">
                                        <div className="card card-custom wave wave-animate-slow wave-success mb-8 mb-lg-0 w-100">
                                            <div className="card-body">
                                                <div className="form-group row text-center mt-5">
                                                    <div className="col-lg-3"></div>
                                                    <div className="col-lg-6">
                                                        <label>Exchange price</label>
                                                        <span className="form-text text-muted">
                                                            <h3>
                                                                {`1 ${this.state.scurrentOption.value}`}  & {`${this.state.scurrentOption === this.state.stargetOption ? 1 : this.state.targetPrice} ${this.state.stargetOption.value}`}
                                                            </h3>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div className="form-group row mb-26">
                                                    <div className="col-lg-6">
                                                        <label>Input amount & Type</label>
                                                        <div className="input-group type-select">
                                                            <input 
                                                                type="text" 
                                                                className="form-control" 
                                                                value={this.state.currentlyValue} 
                                                                placeholder={`Enter ${this.state.scurrentOption.value}`} 
                                                                onFocus={() => this.setState({target:1})} 
                                                                onBlur={() => this.setState({target: 0})} 
                                                                onChange={(e) =>  this.enterCurrentValue(e.target.value)}
                                                            />
                                                            <div className="input-group-append">
                                                                {
                                                                    this.state.currentOption.length > 0 ? 
                                                                    <Select className="select" autosize={true} styles={this.state.customStyles} options={this.state.currentOption} onChange={(e) => this.changecurrent(e)} defaultValue={this.state.scurrentOption} maxMenuHeight={120} /> : ""
                                                                }
                                                            </div>
                                                        </div>
                                                        <span className="form-text text-muted">Please enter {this.state.scurrentOption.value} amount to exchange</span>
                                                    </div>
                                                    <div className="col-lg-6">
                                                        <label>You will receive</label>
                                                        <div className="input-group">
                                                            <input 
                                                                type="text" 
                                                                className="form-control" 
                                                                value={this.state.targetValue} 
                                                                placeholder={`Enter ${this.state.stargetOption.value}`} 
                                                                onFocus={() => this.setState({target:2})} 
                                                                onBlur={() => this.setState({target: 0})} 
                                                                onChange={(e) => this.enterTargetValue(e.target.value)}
                                                            />
                                                            {
                                                                this.state.targetOption.length > 0 ? 
                                                                <Select className="select" autosize={true} styles={this.state.customStyles} options={this.state.targetOption} onChange={(e) => this.changetarget(e)} defaultValue={this.state.stargetOption} maxMenuHeight={120} /> : ""
                                                            }
                                                        </div>
                                                        <span className="form-text text-muted">Please enter {this.state.stargetOption.value}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="card-footer">
                                    <div className="row">
                                        <div className="col-lg-12 text-right">
                                            <button type="reset" disabled={this.state.disablebutton} className="btn btn-primary mr-2" onClick={() => this.exchange()}>
                                                { this.state.loading === 0 ? "Exchange" : <Spinner animation="border" /> }
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function done(state) {
    return {
        kyc: state.userdata.kyc,
        allasets: state.stellar.allasets,
        fiatcurrencies: state.stellar.fiatcurrencies,
        xlmprice: state.stellar.xlmprice,
        europrice: state.stellar.europrice
    }
}

export default connect(done, { exchange })(Exchange);