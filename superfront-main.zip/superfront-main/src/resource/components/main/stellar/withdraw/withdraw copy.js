import React from 'react';
import { connect } from 'react-redux';
import Select from 'react-select';
import Spinner from 'react-bootstrap/Spinner';
import { toast } from 'react-toastify';
import { StellarTomlResolver, Server, } from 'stellar-sdk';
import { StrKey } from 'stellar-base';
import Iban from 'iban';

import FormControlLabelPlacement from './choose';
import EditviewM from './editview';

import { withdraw } from '../../../../../redux/actions/buy';
import config from '../../../../../config';

import '../../../../../assets/css/type-select.css';

class Withdraw extends React.Component {
    constructor() {
        super();
        this.state = {
            amount: 2,
            main: "",
            options: [],
            paytype: "iban",
            targetOption: {},
            loading: 0,
            ibannumber: "",
            address: "",
            disablebutton: false,
            stellar_balance: [],
            currencybalance: {},
            open: false,
            balances: [],
            selectStyle: {
                control: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 300
                }),
                menu: base => ({
                ...base,
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 300
                })
            }
        }
        this.choosetype = this.onchangetype.bind(this);
        this.selectbalance = this.selectbalance.bind(this);
    }

    UNSAFE_componentWillMount() {
        let me = this;
        if(config.dev === true) {
            StellarTomlResolver.resolve(config.toml_url, { allowHttp:true })
            .then(toml => {
                let currencies = toml.CURRENCIES;
                let arr = [];
                for(let i = 0 ; i < currencies.length ; i++) {
                    if(currencies[i].anchor_asset_type === "crypto")continue;
                    arr.push({
                        value: currencies[i].code,
                        label: currencies[i].code
                    })
                }
                me.setState({
                    options: arr,
                    targetOption: arr[0]
                });
            })
        } else {
            StellarTomlResolver.resolve(config.toml_url)
            .then(toml => {
                let currencies = toml.CURRENCIES;
                let arr = [];
                for(let i = 0 ; i < currencies.length ; i++) {
                    if(currencies[i].anchor_asset_type === "crypto")continue;
                    arr.push({
                        value: currencies[i].code,
                        label: currencies[i].code
                    })
                }
                me.setState({
                    options: arr,
                    targetOption: arr[0]
                });
            })
        }
    }

    withdrawc() {
        if(this.props.kyc === true) {
            if(this.state.paytype === "iban") {
                if(Iban.isValid(this.state.ibannumber) === false) {
                    this.errmessage("Please input your corret iban number!");
                    return;
                }
                this.withdrawreal();
            } else if(this.state.paytype === "address") {
                if(StrKey.isValidEd25519PublicKey(this.state.address) === false) {
                    this.errmessage("Please input corret another address!");
                    return;
                }
                const StellarServer = new Server(config.horizon_url);
                StellarServer.loadAccount(this.state.address)
                .then(account => {
                    let arr = [];
                    for(let i = 0 ; i < account.balances.length ; i++) {
                        arr.push({
                            label: account.balances[i].asset_code ? account.balances[i].asset_code : "XLM",
                            value: account.balances[i].asset_code ? account.balances[i].asset_code : "XLM",
                            issuer: account.balances[i].asset_issuer
                        })
                    }
                    this.setState({balances: arr, open:true});
                    // axios.get('')
                })
                .catch(err => {
                    this.errmessage("The account doesn't actived yet!");
                })
            }
        } else {
            toast.warning("Please verify your identify first.", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }

    withdrawreal() {
        if(this.state.paytype === "address") {
            if(!this.state.currencybalance.value) {
                this.errmessage("Please select the target asset!");
                return;
            }
        }
        if(this.state.amount < 2) {
            this.errmessage("Withdraw minimum amount is 2!");
        } else if(this.state.ibannumber === config.iban) {
            this.errmessage("This is our iban!");
        } else {
            let balances = this.state.stellar_balance.filter(item => item.asset_code === this.state.targetOption.value)[0];
            if(parseFloat(balances.balance) < this.state.amount) {
                this.errmessage("You don't have enough balance!");
            } else {
                this.setState({disablebutton: true, loading: 1});
                this.props.withdraw({
                    type: this.state.paytype,
                    iban: this.state.ibannumber,
                    address: this.state.address,
                    amount: this.state.amount,
                    currency: this.state.targetOption.value,
                    targetoption: this.state.currencybalance,
                })
            }
        }
    }

    errmessage(str) {
        toast.error(str, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if( this.props !== nextProps) {
            this.setState({disablebutton: false, open:false, loading: 0});
        }
        if(nextProps.allasets) {
            this.setState({
                stellar_balance : nextProps.allasets['stellar_balance']
            });
        }
    }

    onchangetype(val) {
        this.setState({paytype: val});
    }

    selectbalance(target) {
        this.setState({currencybalance: target});
    }

    cancel() {
        this.setState({open: false});
    }

    render () {
        return (
            <div className="d-flex flex-column-fluid">
                <div className="container py-8">
                    <div className="row">
                        <EditviewM parent={this} open={this.state.open} />
                        <div className="col-lg-12 col-xxl-12">
                            <div className="card card-custom mb-8 mb-lg-0">
                                <div className="card-header border-0 pt-5">
                                    <h3 className="card-title align-items-start flex-column">
                                        <span className="card-label font-weight-bolder text-dark">Withdraw</span>
                                        <span className="text-muted mt-3 font-weight-bold font-size-sm">You can withdraw fiat currencies to your bank or another address</span>
                                    </h3>
                                </div>
                                <div className="card-body pt-0">
                                    <div className="row">
                                        <div className="card card-custom wave wave-animate-slow wave-success mb-8 mb-lg-0 w-100">
                                            <div className="card-body mb-20">
                                                <FormControlLabelPlacement onchangetype={this.choosetype} />
                                                <div className="form-group row mb-0">
                                                    {
                                                        this.state.paytype === "iban" ? 
                                                        <div className="col-lg-5">
                                                            <label>Your IBAN</label>
                                                            <div className="input-group type-select">
                                                                <input type="text" className="form-control" value={this.state.ibannumber} placeholder={`Enter your iban`} onChange={(e) =>  this.setState({ibannumber: e.target.value})}/>
                                                            </div>
                                                            <span className="form-text text-muted">Please enter your iban that you want to withdraw money to</span>
                                                        </div> :
                                                        <div className="col-lg-5">
                                                            <label>Another Address</label>
                                                            <div className="input-group type-select">
                                                                <input type="text" className="form-control" value={this.state.address} placeholder={`Enter another wallet address`} onChange={(e) =>  this.setState({address: e.target.value})}/>
                                                            </div>
                                                            <span className="form-text text-muted">Please enter another address that you want to withdraw money to</span>
                                                        </div>
                                                    }
                                                    <div className="col-lg-3">
                                                        <label>Amount</label>
                                                        <div className="input-group type-select">
                                                            <input type="text" className="form-control" value={this.state.amount} placeholder={`Enter ${this.state.assetCode}`} onChange={(e) =>  this.setState({amount: e.target.value})}/>
                                                        </div>
                                                        <span className="form-text text-muted">Please enter {this.state.assetCode} amount to withdraw</span>
                                                    </div>
                                                    <div className="col-lg-2">
                                                        <label>Type</label>
                                                        <div className="input-group">
                                                            {
                                                                this.state.options.length > 0 ?
                                                                <Select className="select" autosize={true} styles={this.state.selectStyle} options={this.state.options} onChange={(e) => this.setState({targetOption: e})} defaultValue={this.state.targetOption} maxMenuHeight={100} /> : ""
                                                            }
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="card-footer">
                                    <div className="row">
                                        <div className="col-lg-12 text-right">
                                            <button type="reset" disabled={this.state.disablebutton} className="btn btn-primary mr-2" onClick={() => this.withdrawc()}>
                                                { this.state.loading === 0 ? "Withdraw" : <Spinner animation="border" /> }
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function done(state) {
    return {
        kyc: state.userdata.kyc,
        kyb: state.userdata.kyb,
        allasets: state.stellar.allasets
    }
}

export default connect(done, { withdraw })(Withdraw);