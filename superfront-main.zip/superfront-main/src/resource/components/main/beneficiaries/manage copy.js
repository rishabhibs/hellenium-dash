import React from 'react';
import Select from 'react-select';
import Button from '@material-ui/core/Button';
import Spinner from 'react-bootstrap/Spinner'

import { connect } from "react-redux";
import { toast } from 'react-toastify';
import { getusersexept, adduser, invite } from '../../../../redux/actions/beneficiaries';

import Btable from './b_table.js';
import "../../../../assets/scss/simpleStyle.scss";

class Benefic extends React.Component {

    constructor() {
        super()
        this.state = {
            options : [],
            childdata : [],
            targetOption: {},
            toml: {},
            customStyles : {
                control: styles => ({ ...styles,                 
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 200,
                }), 
                menu: styles => ({ ...styles,                 
                    fontFamily: "Times New Roman",
                    flex: 1,
                    width: 200,
                }) 
            },
            loading: 0,
            inviteStatus: 0
        }
    }

    UNSAFE_componentWillMount() {
        this.props.getusersexept();
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(nextProps.beneficiaries) {
            if(nextProps.beneficiaries.child) {
                this.setState({
                    childdata: nextProps.beneficiaries.child
                })
            }
            if(nextProps.beneficiaries.result) {
                var result = nextProps.beneficiaries.result;
                var options = []
                for(var i = 0 ; i < result.length ; i++ ) {
                    options.push({
                        value: result[i].firstname + ' ' + result[i].lastname,
                        label: result[i].firstname + ' ' + result[i].lastname,
                        id: result[i].id,
                    })
                }
                this.setState({
                    options: options,
                    targetOption: options[0],
                    loading: 0
                })
            }
        }
    }

    addbe() {
        if(this.state.options.length === 0) {
            toast.error("There is no beneficiaries to add!", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        } else {
            this.setState({loading: 1});
            this.props.adduser(this.state.targetOption);
        }
    }

    inviteusers() {
        this.setState({inviteStatus: 1})
    }
    
    realinvite() {
        if(this.state.email === "" || this.state.content === "" || this.validateEmail(this.state.email) !== true) {
            toast.error("Input correctly!", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            return;
        }
        this.props.invite({
            email: this.state.email,
            content: this.state.content,
            firstname: this.props.userdata.firstname,
            lastname: this.props.userdata.lastname,
        });
    }

    validateEmail(email) {
        // eslint-disable-next-line
        var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
        if (!pattern.test(email)) {
            return false
        } else {
            return true;
        }
    }
    
    cancel() {
        this.setState({inviteStatus: 0})
    }

    render () {
        return (
            <div className="d-flex flex-column-fluid pt-18">
                <div className="container py-8">
                    <div className="row">
                        <div className="col-lg-12 col-xxl-12">
                            <div className="card card-custom mb-8 mb-lg-0">
                                <div className="card-header border-0 pt-5">
                                    <h3 className="card-title align-items-start flex-column">
                                        <span className="card-label font-weight-bolder text-dark">Add Beneficiaries</span>
                                        <span className="text-muted mt-3 font-weight-bold font-size-sm">you can add beneficiaries to create a payment</span>
                                    </h3>
                                </div>
                                <div className="card-body">
                                    <div className="row">
                                        <div className="card card-custom wave wave-animate-slow wave-primary mb-30 mb-lg-0 w-100">
                                            <div className="card-body">
                                                <div className="form-group row text-center mt-5 mb-30">
                                                    <div className="col-lg-3"></div>
                                                    <div className="col-lg-6" style={{ display: "flex" }}>
                                                        <div className="col-md-6">
                                                            {
                                                                this.state.options.length > 0 ?
                                                                <Select
                                                                    value={this.state.targetOption} 
                                                                    defaultValue={this.state.targetOption}
                                                                    onChange={(e) => this.setState({targetOption: e})}
                                                                    options={this.state.options} 
                                                                    styles={this.state.customStyles}
                                                                    maxMenuHeight={120}
                                                                /> : ""
                                                            }
                                                        </div>
                                                        {
                                                            this.state.options.length > 0 ?
                                                            <div className="col-md-6 text-left">
                                                                <Button onClick={() => this.addbe()} variant="contained" color="secondary" className="h-100">
                                                                    { this.state.loading === 1 ? <Spinner animation="border" /> : "Add Beneficiary" }
                                                                </Button>
                                                            </div>:
                                                            <div className="col-lg-12">
                                                                {
                                                                    this.state.inviteStatus === 0 ?
                                                                    <>
                                                                        <span className="card-label font-weight-bolder text-dark">Do you want to invite and entity to register?</span>
                                                                        <span className="text-muted mt-3 font-weight-bold font-size-sm">
                                                                            <Button onClick={() => this.inviteusers()} variant="contained" color="secondary" className="ml-10">
                                                                                Yes
                                                                            </Button>
                                                                        </span>
                                                                    </> :
                                                                    <>
                                                                        <div className="row">
                                                                            <div className="col-lg-6">
                                                                                <label>Email</label>
                                                                                <div className="input-group type-select">
                                                                                    <input type="text" className="form-control" onChange={e => this.setState({email: e.target.value})} placeholder="Email of the beneficiary" />
                                                                                </div>
                                                                            </div>
                                                                            <div className="col-lg-6">
                                                                                <label>Content</label>
                                                                                <div className="input-group type-select">
                                                                                    <input type="text" className="form-control" onChange={e => this.setState({content: e.target.value})}  placeholder="Content" />
                                                                                </div>
                                                                            </div>
                                                                            <div className="col-lg-12 mt-5 text-right">
                                                                                <Button onClick={() => this.realinvite()} variant="contained" color="secondary" className="ml-10 mt-5">
                                                                                    Invite
                                                                                </Button>
                                                                                <Button onClick={() => this.cancel()} variant="contained" color="secondary" className="ml-10 mt-5">
                                                                                    Cancel
                                                                                </Button>
                                                                            </div>
                                                                        </div>
                                                                    </>
                                                                }
                                                            </div>
                                                        }
                                                    </div>
                                                </div>
                                                <div className="row overflow-auto">
                                                    {this.state.childdata.length > 0 ? <Btable childdata={this.state.childdata} />: ""}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function beneficiary(state) {
    return {
        userdata: state.userdata.userdata,
        beneficiaries: state.stellar.getbeneficiaries,
    }
}

export default connect(beneficiary, { getusersexept, adduser, invite })(Benefic);