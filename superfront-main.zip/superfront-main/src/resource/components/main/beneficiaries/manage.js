import React from 'react';
// import Select from 'react-select';
// import Button from '@material-ui/core/Button';
// import Spinner from 'react-bootstrap/Spinner'

import { connect } from "react-redux";
import { toast } from 'react-toastify';
import { getusersexept, adduser, invite } from '../../../../redux/actions/beneficiaries';

// import Btable from './b_table.js';
import "../../../../assets/scss/simpleStyle.scss";

class Benefic extends React.Component {

  constructor() {
    super()
    this.state = {
      options: [],
      childdata: [],
      targetOption: {},
      toml: {},
      customStyles: {
        control: styles => ({
          ...styles,
          fontFamily: "Times New Roman",
          flex: 1,
          width: 200,
        }),
        menu: styles => ({
          ...styles,
          fontFamily: "Times New Roman",
          flex: 1,
          width: 200,
        })
      },
      loading: 0,
      inviteStatus: 0
    }
  }

  UNSAFE_componentWillMount() {
    this.props.getusersexept();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.beneficiaries) {
      if (nextProps.beneficiaries.child) {
        this.setState({
          childdata: nextProps.beneficiaries.child
        })
      }
      if (nextProps.beneficiaries.result) {
        var result = nextProps.beneficiaries.result;
        var options = []
        for (var i = 0; i < result.length; i++) {
          options.push({
            value: result[i].firstname + ' ' + result[i].lastname,
            label: result[i].firstname + ' ' + result[i].lastname,
            id: result[i].id,
          })
        }
        this.setState({
          options: options,
          targetOption: options[0],
          loading: 0
        })
      }
    }
  }

  addbe() {
    if (this.state.options.length === 0) {
      toast.error("There is no beneficiaries to add!", {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
    } else {
      this.setState({ loading: 1 });
      this.props.adduser(this.state.targetOption);
    }
  }

  inviteusers() {
    this.setState({ inviteStatus: 1 })
  }

  realinvite() {
    if (this.state.email === "" || this.state.content === "" || this.validateEmail(this.state.email) !== true) {
      toast.error("Input correctly!", {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
      return;
    }
    this.props.invite({
      email: this.state.email,
      content: this.state.content,
      firstname: this.props.userdata.firstname,
      lastname: this.props.userdata.lastname,
    });
  }

  validateEmail(email) {
    // eslint-disable-next-line
    var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
    if (!pattern.test(email)) {
      return false
    } else {
      return true;
    }
  }

  cancel() {
    this.setState({ inviteStatus: 0 })
  }

  render() {
    return (
      <>
        <div className="left-container">
          <div className="transaction-history-section-container">
            <div className="row title-row">
              <div className="col-md-12">
                <h2>Add Benefeciary</h2>
                <h3>Enter your details to create payment</h3>
              </div>
            </div>
            {/*Row*/}
            <div className="row">
              <div className="col-md-12 col-lg-12 col-xl-12 col-sm-12 col-12">
                <div className="benefeciary-content-1">
                  {/*Field box*/}
                  <div className="col-md-12">
                    {/*Form Box*/}
                    <div className="form-box">
                      <div className="select-control-wrapper custom-select-box">
                        <select className="form-control">
                          <option>YuanXin Wang</option>
                          <option>Hola</option>
                          <option>YuanXin Wang</option>
                          <option>Hola</option>
                          <option>YuanXin Wang</option>
                          <option>Hola</option>
                          <option>Hola</option>
                          <option>Hola</option>
                          <option>Hola</option>
                          <option>Hola</option>
                          <option>Hola</option>
                          <option>Hola</option>
                          <option>Hola</option>
                          <option>Hola</option>
                        </select>
                      </div>
                    </div>
                    {/*Form Box*/}
                    {/*Form Box*/}
                    <div className="form-box">
                      <label htmlFor="Street" className="label">Street</label>
                      <input type="text" id="Street" className="form-control" placeholder="Street" />
                    </div>
                    {/*Form Box*/}
                    {/*Form Box*/}
                    <div className="form-box">
                      <input type="text" id="City" className="form-control" placeholder="City" />
                    </div>
                    {/*Form Box*/}
                    {/*Form Box*/}
                    <div className="form-box">
                      <input type="text" id="Country" className="form-control" placeholder="Country" />
                    </div>
                    {/*Form Box*/}
                    {/*Form Box*/}
                    <div className="form-box">
                      <input type="text" id="Postal" className="form-control" placeholder="Postal" />
                    </div>
                    {/*Form Box*/}
                  </div>
                  {/*Field box*/}
                  <button className="btn btn-submit" type="submit">Add Benefeciary</button>
                </div>
              </div>
            </div>
            {/*Row*/}
          </div>
        </div>

      </>
    )
  }
}

function beneficiary(state) {
  return {
    userdata: state.userdata.userdata,
    beneficiaries: state.stellar.getbeneficiaries,
  }
}

export default connect(beneficiary, { getusersexept, adduser, invite })(Benefic);