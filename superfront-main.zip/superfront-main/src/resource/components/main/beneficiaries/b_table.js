import React from 'react';
import { MDBDataTable } from 'mdbreact';

class Btable extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data : {
                columns: [
                    {
                        label: 'First Name',
                        field: 'firstname',
                        sort: 'asc',
                        width: 200
                    },
                    {
                        label: 'Last Name',
                        field: 'lastname',
                        sort: 'asc',
                        width: 200
                    },
                    {
                        label: 'Email',
                        field: 'email',
                        sort: 'asc',
                        width: 200
                    },
                    {
                        label: 'Phone',
                        field: 'phone',
                        sort: 'asc',
                        width: 150
                    },
                    {
                        label: 'Stellar Account Id',
                        field: 's_account_id',
                        sort: 'asc',
                        width: 250
                    }
                ],
                rows: props.childdata
            }   
        }
    }

    render() {
        return (
            <MDBDataTable
                striped
                bordered
                small
                hover
                className="w-98"
                data={this.state.data}
            />
        );
    }
}
export default Btable;