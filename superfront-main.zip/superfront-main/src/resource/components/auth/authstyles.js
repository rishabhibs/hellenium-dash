export const Styles = {
    root: {
        flexGrow: 1,
    },
    paper: {
        padding: 1,
        textAlign: 'center',
        color: 'secondary',
    },
};