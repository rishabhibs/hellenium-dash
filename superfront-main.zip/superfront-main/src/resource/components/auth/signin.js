import React from 'react';
import { Link } from 'react-router-dom';
import Reaptcha from 'reaptcha';
// import LogoImage from '../../../assets/images/hellenium.svg';
import { connect } from 'react-redux';
import { toast } from 'react-toastify';
import validator from 'validator'

// import { history } from '../../history'
import { signIn } from '../../../redux/actions/auth'
import config from '../../../config';
import "../../../assets/scss/new_style.scss";
/* import VisibilityIcon from '@material-ui/icons/Visibility';
import VisibilityOffIcon from '@material-ui/icons/VisibilityOff'; */

class Signin extends React.Component {
    constructor() {
        super();
        this.state = {
            email: "",
            password: "",
            main_formClass: "form-control h-auto placeholder-white opacity-70 bg-dark-o-70 border-0 py-4 px-8 mb-5",
            flag: false,
            verified: false,
            visibility: 'password',
        }
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if (nextProps.auth) {
            if (nextProps.auth.status === true) {
                toast.success('Success!', {
                    position: "top-right",
                    autoClose: 1000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    onClose: () => { window.location.href = config.client_url; }
                    // onClose: () => { history.push("/"); }
                });
            } else {
                toast.error(nextProps.auth.message, {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
        }
    }

    validateEmail(email) {
        if (validator.isEmail(email)) {
            return true;
        } else {
            return false
        }
    }

    validatePassword(password) {
        if (validator.isStrongPassword(password)) {
            return true;
        } else {
            return false;
        }
    }

    gosignin() {
        if (config.dev === true) {
            if (this.validateEmail(this.state.email) === false || this.state.password === "") {
                toast.error('Input correctly.', {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            }
        } else {
            if (this.validateEmail(this.state.email) === false || this.state.password === "") {
                toast.error('Input correctly.', {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            } else if (this.state.verified === false) {
                toast.error("Please let us you aren't robot!", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            }
        }
        this.setState({ flag: false })
        this.props.signIn({
            email: this.state.email,
            password: this.state.password
        })
    }
    render() {

        return (
            <>
                <div className="login-container">
                    <form className="form-signin">
                        <img className="login-logo" src="assets/img/logo.svg" alt="" />
                        <h1 className="login-heading">Sign In</h1>
                        <h2 className="login-subheading">Enter your details to login to your account:</h2>
                        <div className="form-box">
                          <label htmlFor="Email" className="label">Email Address</label>
                          <input type="email" id="Email" 
                          className={this.validateEmail(this.state.email) ? this.state.main_formClass + ' is-valid' : this.state.main_formClass + ' is-invalid'} placeholder="sonice@sonice.com" onChange={e => { this.setState({ email: e.target.value }) }} name="email" autoComplete="off"
                          value={this.state.email} />
                          </div>

                        <div className="form-box">
                          <label htmlFor="Password" className="label">Password</label>
                          <input id="Password" placeholder="*********************" 
                          className={this.validatePassword(this.state.password) ? this.state.main_formClass + ' is-valid' : this.state.main_formClass + ' is-invalid'} type={this.state.visibility} onChange={e => { this.setState({ password: e.target.value }) }} name="password" value={this.state.password} />         
                           
                        </div>

                       
                        <div className="form-group d-flex flex-wrap justify-content-between align-items-center px-8" ref={element => {
                            if (element) element.style.setProperty('justify-content', 'center', 'important');
                        }}>
                            <Reaptcha sitekey={config.sitekey} onVerify={() => this.setState({ verified: true })} onExpired={() => { /* console.log('expired'); */ this.setState({ verified: false }) }} />
                        </div>
                        <div className="remember-row">
                            <div className="remember-me-box">
                                <div className="custom-control custom-checkbox">
                                    <input type="checkbox" name="remember" className="custom-control-input" id="customCheck1" />
                                    <label className="custom-control-label" htmlFor="customCheck1">Remember me</label>
                                </div>
                            </div>
                            <div className="forget-box">
                                <Link to="/forgot">Forgot password?</Link>
                            </div>
                        </div>
                        <button className="btn btn-block"
                            type="button"
                            onClick={() => this.gosignin()}  >Sign In</button>
                        <div className="sigup-row">
                            <p>Don’t have account yet? <Link to="/signup">Sign Up</Link></p>
                        </div>
                    </form>
                </div>

            </>
        )
    }
}

const load = (state) => {
    return {
        auth: state.auth.auth
    }
}

export default connect(load, { signIn })(Signin);