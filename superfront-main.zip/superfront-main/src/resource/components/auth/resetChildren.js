import React from 'react';
import { Link } from 'react-router-dom';
import Spinner from "../../Loading-spinner";
import { connect } from 'react-redux';
import { toast } from 'react-toastify';
import validator from 'validator'

import VisibilityIcon from '@material-ui/icons/Visibility';
import VisibilityOffIcon from '@material-ui/icons/VisibilityOff';
import { checktoken, resetpass } from '../../../redux/actions/auth';
import LogoImage from '../../../assets/images/stellar.png';
import { history } from '../../history'

// import '../../../assets/css/thankyoupage.css';
import "../../../assets/scss/new_style.scss";

class Reset extends React.Component {
    
    constructor() {
        super()
        this.state = {
            data: '',
            loading: 1,
            message: "",
            confirms: false,
            password: "",
            cpassword: "",
            visibility: 'password',
            main_formClass: "form-control h-auto  placeholder-white opacity-70 bg-dark-o-70 border-0 py-4 px-8 text-white",
        }
    }

    UNSAFE_componentWillMount() {
        this.setState({loading: 0})
        this.props.checktoken(this.props.tokendt);
    }

    validatePassword(password) {
        if(validator.isStrongPassword(password)) {
            return true;
        } else {
            return false;
        }
    }

    resetpassword() {
        if(this.validatePassword(this.state.password)) {
            if(this.state.password === this.state.cpassword) {
                console.log(this.props.tokendt, this.state.password)
            } else {
                this.errmsg("Password doesn't match!");
            }
        } else {
            this.errmsg("Password must to contain 8 digits, contains upper, lowercase, and a special character!");
        }
    }

    errmsg(msg) {
        toast.error(msg, {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    }

    goback = () => {
        history.push('/signin')
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(this.props !== nextProps) {
            if(nextProps.tokenstatus === false) {
                history.push('/signin');
            } else {
                this.setState({loading: 1});
            }
        }
    }

    render () {
        return (
            <>
                {this.state.loading === 0 ? 
                    <Spinner />:
                    <div className="d-flex flex-column flex-root     lllll000000" style={{ height: "100%" }}>
                        <div className="login login-3 login-signin-on d-flex flex-row-fluid" id="kt_login">
                            <div className="d-flex flex-center bgi-size-cover bgi-no-repeat flex-row-fluid">
                                <div className="new-login login-form text-center p-7 position-relative overflow-hidden">
                                    <div className="flex-center mb-15">
                                        <Link to="#">
                                            <img src={LogoImage} className="max-h-200px" alt="" />
                                        </Link>
                                    </div>
                                    <div className="form" id="kt_login_forgot_form">
                                        <div className="mb-20 form text-center">
                                            <div className="form-group has-danger justify-content-between d-flex">
                                                <input className={ this.validatePassword(this.state.password) ? this.state.main_formClass+' is-valid' : this.state.main_formClass+' is-invalid' } type={this.state.visibility} placeholder="Password" onChange={e => {this.setState({password: e.target.value})}} name="password" value={this.state.password} />
                                                <span className="symbol symbol-lg-35 symbol-25 symbol-light-primary d-flex align-items-center">
                                                    <span className="symbol-label font-size-h5 font-weight-bold">
                                                        {
                                                            this.state.visibility === 'password' ? 
                                                            <VisibilityIcon onClick={() => this.setState({visibility: 'text'})} /> : 
                                                            <VisibilityOffIcon onClick={() => this.setState({visibility: 'password'})} />
                                                        }
                                                    </span>
                                                </span>
                                            </div>
                                            <div className="form-group has-danger justify-content-between d-flex align-items-center">
                                                <input className={(this.state.password === this.state.cpassword) && (this.state.cpassword !== "") && (this.validatePassword(this.state.password) === true) ? this.state.main_formClass+' is-valid' :  this.state.main_formClass+' is-invalid'} type={this.state.visibility} placeholder="Confirm Password" onChange={e => {this.setState({cpassword: e.target.value})}} name="cpassword" value={this.state.cpassword} />
                                                <span className="symbol symbol-lg-35 symbol-25 symbol-light-primary d-flex align-items-center">
                                                    <span className="symbol-label font-size-h5 font-weight-bold">
                                                        {
                                                            this.state.visibility === 'password' ? 
                                                            <VisibilityIcon onClick={() => this.setState({visibility: 'text'})} /> : 
                                                            <VisibilityOffIcon onClick={() => this.setState({visibility: 'password'})} />
                                                        }
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                        <div className="mt-10">
                                            <button type="button" id="kt_login_signin_submit" onClick={() => this.resetpassword()} className="btn btn-pill btn-outline-white text-primary font-weight-bold opacity-70 px-15 py-3">
                                                Reset Password
                                            </button>
                                            <button type="button" onClick={() => this.goback()} className="btn btn-pill text-primary btn-outline-white text-primary font-weight-bold opacity-70 px-15 py-3 m-2">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                }
            </>
        )
    }
}

function done(state) {
    return {
        tokenstatus: state.userdata.tokenstatus,
        resetdone: state.userdata.resetdone
    }
}

export default connect(done, { checktoken, resetpass })(Reset);
