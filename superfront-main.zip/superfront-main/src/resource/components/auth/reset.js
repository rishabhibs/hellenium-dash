import { lazy } from "react"
import {
    useParams
} from "react-router-dom";

const ResetChild  = lazy(() => import('./resetChildren'));

export default function Reset() {
	
    let { token } = useParams();

    return (
        <ResetChild tokendt={token} />
    );
}