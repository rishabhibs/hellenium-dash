import React from 'react';
// import { Link } from 'react-router-dom';
import { signUp } from '../../../redux/actions/auth'
import { connect } from 'react-redux';
import { history } from '../../history'
import { toast } from 'react-toastify';
import Reaptcha from 'reaptcha';
import validator from 'validator'

/* import VisibilityIcon from '@material-ui/icons/Visibility';
import VisibilityOffIcon from '@material-ui/icons/VisibilityOff'; */

// import LogoImage from '../../../assets/images/hellenium.png';
import config from '../../../config';

import "../../../assets/scss/new_style.scss";


class Signup extends React.Component {

 constructor(props) {
  super(props)
  this.state = {
   firstname: '',
   lastname: '',
   email: '',
   password: '',
   cpassword: '',
   main_formClass: "form-control h-auto  placeholder-white opacity-70 bg-dark-o-70 border-0 py-4 px-8",
   verified: false,
   passbaseAPIvefiry: false,
   step: 0,
   legal_entity_type: "company",
   street: "",
   city: "",
   country: "",
   postal_code: "",
   passwordLength: 15,
   visibility: 'password',
   characters: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!@#$%^&*()<>,.?/[]{}-=_+|/0123456789'
  }
 }

 handleSubmit = (e) => {
  e.preventDefault();
  if (config.dev !== true) {
   if (this.state.verified === false) {
    toast.error("Please check the robot check!", {
     position: "top-right",
     autoClose: 5000,
     hideProgressBar: false,
     closeOnClick: true,
     pauseOnHover: true,
     draggable: true,
     progress: undefined,
    });
    return;
   }
  }
  if (!this.validatePassword(this.state.password)) {
   toast.error("Password must to contain 8 digits, contains upper, lowercase, and a special character!", {
    position: "top-right",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
   });
   return;
  }
  if (this.state.password !== this.state.cpassword) {
   toast.error("Password doesn't match.", {
    position: "top-right",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
   });
   return;
  }
  this.props.signUp({
   firstname: this.state.firstname,
   lastname: this.state.lastname,
   email: this.state.email,
   password: this.state.password,
   legal_entity_type: this.state.legal_entity_type,
   street: this.state.street,
   city: this.state.city,
   country: this.state.country,
   postal_code: this.state.postal_code
  })
 }

 nextfunc() {
  if (this.state.step === 0) {
   if (this.state.fullname === "" || this.validateEmail(this.state.email) === false) {
    toast.error("Input correctly!", {
     position: "top-right",
     autoClose: 5000,
     hideProgressBar: false,
     closeOnClick: true,
     pauseOnHover: true,
     draggable: true,
     progress: undefined,
    });
    return;
   }
   this.setState({ step: 1 });
  } else if (this.state.step === 1) {
   if (this.state.street === "" || this.state.city === "" || this.state.country === "" || this.state.postal_code === "") {
    toast.error("Input correctly!", {
     position: "top-right",
     autoClose: 5000,
     hideProgressBar: false,
     closeOnClick: true,
     pauseOnHover: true,
     draggable: true,
     progress: undefined,
    });
    return;
   }
   this.setState({ step: 2 });
  }
 }

 validateEmail(email) {
  if (validator.isEmail(email)) {
   return true;
  } else {
   return false
  }
 }

 validatePassword(password) {
  if (validator.isStrongPassword(password)) {
   return true;
  } else {
   return false;
  }
 }

 referenceUserWithKey = (key) => {
  // console.log(key);
  this.setState({ passbaseAPIvefiry: true });
  // Make request to your backend/db and save the key to the user's profile
 }

 setrandompassword() {
  var password = '';
  while (1) {
   for (let i = 0; i < this.state.passwordLength; i++) {
    password += this.state.characters[this.getRandomInteger(0, this.state.characters.length - 1)];
   }
   if (validator.isStrongPassword(password)) {
    this.setState({
     password: password,
     cpassword: password,
     visibility: "text"
    });
    break;
   } else {
    break;
   }
  }
 }

 getRandomInteger = (min, max) => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
 }

 UNSAFE_componentWillReceiveProps(nextProps) {
  if (nextProps.signupresult) {
   if (nextProps.signupresult.status === true) {
    toast.success("Success! Please confirm your inbox.", {
     position: "top-center",
     autoClose: 3000,
     hideProgressBar: false,
     closeOnClick: true,
     pauseOnHover: true,
     draggable: true,
     progress: undefined,
     onClose: () => {
      history.push('/signin');
     }
    });
   } else {
    toast.warn("Fail! Something went wrong.", {
     position: "top-right",
     autoClose: 5000,
     hideProgressBar: false,
     closeOnClick: true,
     pauseOnHover: true,
     draggable: true,
     progress: undefined,
     onClose: () => {
      history.push('/signup');
     }
    });
   }
  }
 }

 render() {
  return (

   <div className="login-container">
    <form className="form-signin" onSubmit={(e) => this.handleSubmit(e)}>
     <img className="login-logo" src="assets/img/logo.svg" alt="" />
     <h1 className="login-heading">Sign Up</h1>
     <h2 className="login-subheading">Enter your details to create your account:</h2>
     {
      this.state.step === 0 ?
       <>
        <div className="form-box">
         <label htmlFor="Full Name" className="label">Full Name</label>
         <input type="text" id="Fullname" className={this.state.firstname === "" ? this.state.main_formClass + ' is-invalid' : this.state.main_formClass + ' is-valid'} placeholder="Sotiris Melioumis" onChange={e => { this.setState({ firstname: e.target.value }) }} name="firstname" value={this.state.firstname} />
        </div>
        <div className="form-box">
         <label htmlFor="Email" className="label">Email</label>
         <input type="text" id="Email" className={this.validateEmail(this.state.email) ? this.state.main_formClass + ' is-valid' : this.state.main_formClass + ' is-invalid'} placeholder="sonice@sonice.com" onChange={e => { this.setState({ email: e.target.value }) }} name="email" autoComplete="off" value={this.state.email} />
        </div>
        <div className="form-box last">
         <label htmlFor="telphone" className="label">Phone Number</label>
         <input type="text" id="telphone" className={this.state.lastname === "" ? this.state.main_formClass + ' is-invalid' : this.state.main_formClass + ' is-valid'} placeholder="+1 123 456 78 90" onChange={e => { this.setState({ lastname: e.target.value }) }} name="lastname" value={this.state.lastname} />
        </div>
       </> :
       <>
        <div className="form-box">
         <label htmlFor="Password" className="label">Password</label>
         <input id="Password" placeholder="*********************" 
         className={this.validatePassword(this.state.password) ? this.state.main_formClass + ' is-valid' : this.state.main_formClass + ' is-invalid'} type={this.state.visibility} onChange={e => { this.setState({ password: e.target.value }) }} name="password" value={this.state.password} />
        
        </div>
        <div className="form-box">
         <label htmlFor="Confirm password" className="label">Confirm password</label>
         <input id="Confirm password" placeholder="*************************"
          className={(this.state.password === this.state.cpassword) && (this.state.password !== "") ? this.state.main_formClass + ' is-valid' : this.state.main_formClass + ' is-invalid'} type={this.state.visibility} onChange={e => { this.setState({ cpassword: e.target.value }) }} name="cpassword" value={this.state.cpassword} />
         {/* <span className="symbol symbol-lg-35 symbol-25 symbol-light-primary d-flex">
          <span className="symbol-label font-size-h5 font-weight-bold">
           {
            this.state.visibility === 'password' ? <VisibilityIcon onClick={() => this.setState({ visibility: 'text' })} /> : <VisibilityOffIcon onClick={() => this.setState({ visibility: 'password' })} />
           }
          </span>
         </span> */}
        </div>
        <div className="form-group d-flex flex-wrap justify-content-between align-items-center px-8" ref={element => {
         if (element) element.style.setProperty('justify-content', 'center', 'important');
        }}>
         <Reaptcha sitekey={config.sitekey} onVerify={() => this.setState({ verified: true })} onExpired={() => { /* console.log('expired'); */ this.setState({ verified: false }) }} />
        </div>
        <div className="agree-row">
         <div className="remember-me-box">
          <div className="custom-control custom-checkbox">
           <input type="checkbox" defaultValue="remember-me" className="custom-control-input" id="customCheck1" />
           <label className="custom-control-label" htmlFor="customCheck1">I Agree with terms &amp; conditions.</label>
          </div>
         </div>
        </div>
       </>
     }
     <div>
      {
       this.state.step === 1 ?
        <>
         <div className="signup-btn-row">
          <span className="btn back-btn" onClick={() => this.setState({ step: 0 })}> <img src="assets/img/back-arrow.svg" alt="" /></span>
          <button className="btn btn-block next-btn" /* href="success-signup.html" */>Sign Up</button>
         </div>
        </> : <></>
      }
     </div>
     <div>
     {
      this.state.step === 0 ?
       <>
        <div className="signup-btn-row">
         <a className="btn back-btn" href="login.html"> <img src="assets/img/back-arrow.svg" alt="" /></a>
         <span className="btn btn-block next-btn" onClick={() => this.nextfunc()}>Next</span>
        </div>
       </> : <></>
     }
    </div>
    </form>
    
   </div>




  )
 }
}

const load = (state) => {
 return {
  signupresult: state.auth.signupresult
 }
}

export default connect(load, { signUp })(Signup);