import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { toast } from 'react-toastify';
import validator from 'validator'
import Spinner from 'react-bootstrap/Spinner';

import { forgotpassword } from '../../../redux/actions/auth';

import { history } from '../../history'
import LogoImage from '../../../assets/images/stellar.png';
import "../../../assets/scss/new_style.scss";

class Forgot extends React.Component {
    constructor() {
        super()
        this.state ={
            email: "",
            loading: 0
        }
    }

    goback = () => {
        history.push('/signin')
    }

    forgotPass = () => {
        if(this.validateEmail(this.state.email) === false) {
            toast.error("Please input the correct email!", {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            return;
        }
        this.setState({loading: 1})
        this.props.forgotpassword(this.state.email)
    }

    validateEmail(email) {
        if(validator.isEmail(email)){
            return true;
        } else { return false; }
    }

    handleSubmit(e) {
        e.preventDefault();
        this.forgotPass()
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(this.props !== nextProps) {
            this.setState({loading: 0})
        }
    }
    render () {
       
        return (
            <div className="d-flex flex-column flex-root" style={{ height: "100%" }}>
                <div className="login login-3 login-signin-on d-flex flex-row-fluid" id="kt_login">
                    <div className="d-flex flex-center bgi-size-cover bgi-no-repeat flex-row-fluid">
                        <div className="new-login login-form text-center p-7 position-relative overflow-hidden">
                            <div className="d-flex flex-center mb-5">
                                <Link to="#">
                                    <img src={LogoImage} className="max-h-200px" alt="" />
                                </Link>
                            </div>
                            <div className="login-signin">
                                <div className="mb-10">
                                    <h3>Forgotten Password ?</h3>
                                    <p className="opacity-60">Enter your email to reset your password</p>
                                </div>
                                <form className="form" id="kt_login_forgot_form" onSubmit={(e) => this.handleSubmit(e)}>
                                    <div className="form-group mb-10">
                                        <input className="form-control h-auto text-white placeholder-white opacity-70 bg-dark-o-70 rounded-pill border-0 py-4 px-8" type="text" placeholder="Email" name="email" autoComplete="off" onChange={(e) => this.setState({email: e.target.value})} />
                                    </div>
                                    <div className="form-group">
                                        <button type="button" disabled={this.state.loading} onClick={() => this.forgotPass()} className="btn btn-pill text-primary btn-outline-white font-weight-bold opacity-90 px-15 py-3 m-2">
                                            {this.state.loading === 0 ? "Request" : <Spinner animation="border" />}
                                        </button>
                                        <button type="button" disabled={this.state.loading} onClick={() => this.goback()} className="btn btn-pill text-primary btn-outline-white font-weight-bold opacity-70 px-15 py-3 m-2">
                                            {this.state.loading === 0 ? "Cancel" : <Spinner animation="border" />}
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function forgotdone(state) {
    return {
        forgotpass: state.userdata.forgotpass
    }
}

export default connect(forgotdone, { forgotpassword })(Forgot);