import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { toast } from 'react-toastify';
import validator from 'validator'
import Spinner from 'react-bootstrap/Spinner';

import { forgotpassword } from '../../../redux/actions/auth';

import { history } from '../../history'
// import LogoImage from '../../../assets/images/stellar.png';
import "../../../assets/scss/new_style.scss";

class Forgot extends React.Component {
    constructor() {
        super()
        this.state = {
            email: "",
            loading: 0
        }
    }

    goback = () => {
        history.push('/signin')
    }

    forgotPass = () => {
        if (this.validateEmail(this.state.email) === false) {
            toast.error("Please input the correct email!", {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            return;
        }
        this.setState({ loading: 1 })
        this.props.forgotpassword(this.state.email)
    }

    validateEmail(email) {
        if (validator.isEmail(email)) {
            return true;
        } else { return false; }
    }

    handleSubmit(e) {
        e.preventDefault();
        this.forgotPass()
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if (this.props !== nextProps) {
            this.setState({ loading: 0 })
        }
    }
    render() {

        return (
            <div className="login-container">
                <form className="form-signin" onSubmit={(e) => this.handleSubmit(e)}>
                    <img className="login-logo" src="assets/img/logo.svg" alt="" />
                    <h1 className="login-heading">Forgot Password</h1>
                    <h2 className="login-subheading">Enter email address to recover your access:</h2>
                    <div className="form-box forget-box">
                        <label htmlFor="Email" className="label">Email</label>
                        <input type="email" id="Email" className="form-control" placeholder="sonice@sonice.com" name="email" autoComplete="off" onChange={(e) => this.setState({ email: e.target.value })} autofocus />
                    </div>
                    <button className="btn btn-block" type="button" disabled={this.state.loading} onClick={() => this.forgotPass()}>
                        {this.state.loading === 0 ? "Reset" : <Spinner animation="border" />}</button>
                    <div className="sigup-row">
                        <p>Remember your pass? <Link to="/signin">Sign In</Link></p>
                    </div>
                </form>
            </div>
        )
    }
}

function forgotdone(state) {
    return {
        forgotpass: state.userdata.forgotpass
    }
}

export default connect(forgotdone, { forgotpassword })(Forgot);