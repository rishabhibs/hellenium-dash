import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { toast } from 'react-toastify';
import Reaptcha from 'reaptcha';
import validator from 'validator'

// import { history } from '../../history'
import { signIn } from '../../../redux/actions/auth'
import LogoImage from '../../../assets/images/hellenium.svg';
import config from '../../../config';
import "../../../assets/scss/new_style.scss";

class Signin extends React.Component {
    constructor() {
        super();
        this.state = {
            email: "",
            password: "",
            main_formClass: "form-control h-auto placeholder-white opacity-70 bg-dark-o-70 border-0 py-4 px-8 mb-5",
            flag: false,
            verified: false
        }
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if(nextProps.auth) {
            if(nextProps.auth.status === true) {
                toast.success('Success!', {
                    position: "top-right",
                    autoClose: 1000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    onClose: () => { window.location.href = config.client_url; }
                    // onClose: () => { history.push("/"); }
                });
            } else {
                toast.error(nextProps.auth.message, {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
        }
    }

    validateEmail(email) {
        if (validator.isEmail(email)) {
            return true;
        } else {
            return false
        }
    }

    validatePassword(password) {
        if(validator.isStrongPassword(password)) {
            return true;
        } else {
            return false;
        }
    }
    
    gosignin(){
        if(config.dev === true) {
            if(this.validateEmail(this.state.email) === false || this.state.password === "") {
                toast.error('Input correctly.', {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            } 
        } else {
            if(this.validateEmail(this.state.email) === false || this.state.password === "") {
                toast.error('Input correctly.', {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            } else if(this.state.verified === false ) {
                toast.error("Please let us you aren't robot!", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            }
        }
        this.setState({flag: false})
        this.props.signIn({
            email: this.state.email,
            password: this.state.password
        })
    }
    render () {
       
        return (
            <div className="d-flex flex-column flex-root" style={{ height: "100%" }}>
                <div className="login login-3 login-signin-on d-flex flex-row-fluid" id="kt_login">
                    <div className="d-flex flex-center bgi-size-cover bgi-no-repeat flex-row-fluid">
                        <div className="new-login login-form text-center p-7 position-relative overflow-hidden">
                            <div className="flex-center mb-5">
                                <Link to="#">
                                    <img src={LogoImage} className="max-h-200px" alt="" />
                                </Link>
                            </div>
                            <div className="login-signin">
                                <div className="mb-10">
                                    <h3>Sign In</h3>
                                    <p className="opacity-60 font-weight-bold">Enter your details to login to your account:</p>
                                </div>
                                <form className="form" id="kt_login_signin_form">
                                    <div className="form-group has-danger">
                                        <input className={ this.validateEmail(this.state.email) ? this.state.main_formClass+' is-valid' : this.state.main_formClass+' is-invalid'} type="text" placeholder="Email" onChange={e => {this.setState({email: e.target.value})}} name="email" autoComplete="off" />
                                    </div>
                                    <div className="form-group has-danger">
                                        <input className={ this.validatePassword(this.state.password) ? this.state.main_formClass+' is-valid' : this.state.main_formClass+' is-invalid' } type="password" placeholder="Password" onChange={e => {this.setState({password: e.target.value})}} name="password" value={this.state.password} />
                                    </div>
                                    <div className="form-group d-flex flex-wrap justify-content-between align-items-center px-8" ref={element => { 
                                        if (element) element.style.setProperty('justify-content', 'center', 'important'); 
                                    }}>
                                        <Reaptcha sitekey={config.sitekey} onVerify={() => this.setState({verified: true})} onExpired={() => { /* console.log('expired'); */ this.setState({verified: false})}} />
                                    </div>
                                    <div className="form-group d-flex flex-wrap justify-content-between align-items-center px-8">
                                        <div className="checkbox-inline">
                                            <label className="checkbox checkbox-outline checkbox-white m-0">
                                            <input type="checkbox" name="remember" />
                                            <span></span>Remember me</label>
                                        </div>
                                        <Link to="/forgot" id="kt_login_forgot" className="new-black-color font-weight-bold">Forget Password ?</Link>
                                    </div>
                                    <div className="form-group text-center mt-10">
                                        <button type="button" onClick={() => this.gosignin()} id="kt_login_signin_submit" className="new-login-btn-color btn btn-pill btn-outline-white border-white font-weight-bold opacity-90 px-15 py-3">Sign In</button>
                                    </div>
                                </form>
                                <div className="mt-10">
                                    <span className="opacity-70 mr-4">Don't have an account yet?</span>
                                    <Link to="/signup" id="kt_login_signup" className="new-black-color font-weight-bold">Sign Up</Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

const load = (state) => {
    return {
        auth: state.auth.auth
    }
}

export default connect(load, {signIn})(Signin);