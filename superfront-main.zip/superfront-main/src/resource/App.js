import React, { Suspense, lazy } from "react"
import { Router, Switch, Route, Redirect } from "react-router-dom"
import { history } from "./history"
import { connect } from "react-redux"
import Spinner from "./Loading-spinner"
import { ContextLayout } from "../layouts/Layout"
import { is_session } from '../redux/actions/session';
import { ToastContainer } from 'react-toastify';
// import '../assets/css/webscrollbar.css';


// Components
const Dashboard  = lazy(() => import('./components/main/dashboard'));

// const Aconversation  = lazy(() => import('./components/main/currencycloud/aconversation/aconversation'));
// const Beneficiaries  = lazy(() => import('./components/main/currencycloud/beneficiaries/beneficiaries'));
// const AddBeneficiaries  = lazy(() => import('./components/main/currencycloud/beneficiaries/addbeneficiaries'));
// const Convert  = lazy(() => import('./components/main/currencycloud/convert/convert'));
// const Onboarding  = lazy(() => import('./components/main/currencycloud/onboarding/onboarding'));
// const Pay  = lazy(() => import('./components/main/currencycloud/pay/pay'));
// const Search  = lazy(() => import('./components/main/currencycloud/search/search'));
// const Transfers  = lazy(() => import('./components/main/currencycloud/transfers/transfers'));
// const Transactions  = lazy(() => import('./components/main/currencycloud/transactions/transactions'));
// const Balances  = lazy(() => import('./components/main/currencycloud/balances/balances'));

// Admin
const Users  = lazy(() => import('./components/main/admin/users'));
const ADeposit  = lazy(() => import('./components/main/admin/deposit'));
const ADWithdraw  = lazy(() => import('./components/main/admin/withdraw'));
const Adminlogin  = lazy(() => import('./components/main/admin/auth'));
const ABuy  = lazy(() => import('./components/main/admin/buy'));
const ASell  = lazy(() => import('./components/main/admin/sell'));

const Buy  = lazy(() => import('./components/main/stellar/buy/buy'));
const Sell  = lazy(() => import('./components/main/stellar/sell/sell'));
const Exchange  = lazy(() => import('./components/main/stellar/exchange/exchange'));
const Deposit  = lazy(() => import('./components/main/stellar/deposit/deposit'));
const Transfer  = lazy(() => import('./components/main/stellar/transfer/transfer'));
const Trustline  = lazy(() => import('./components/main/stellar/trustline'));
const Withdraw  = lazy(() => import('./components/main/stellar/withdraw/withdraw'));
const Balancem  = lazy(() => import('./components/main/stellar/wallet/manage'));
const KYCpersonal  = lazy(() => import('./components/main/stellar/kyc/personal'));
const KYCorganization  = lazy(() => import('./components/main/stellar/kyc/organization'));

const Company  = lazy(() => import('./components/main/user/company'));
const Benefic  = lazy(() => import('./components/main/beneficiaries/manage'));

const Signin  = lazy(() => import('./components/auth/signin'));
const Signup  = lazy(() => import('./components/auth/signup'));
const Forgot  = lazy(() => import('./components/auth/forgot'));
const Reset  = lazy(() => import('./components/auth/reset'));
const Error  = lazy(() => import('./content/404'));
const EmailChildren  = lazy(() => import('./content/emailChildren'));

// Set Layout and Component Using App Route
const RouteConfig = ({ component: Component, fullLayout, adminLayout, ...rest }) => (
  <Route
    {...rest}
    render={props => {
      return (
        <ContextLayout.Consumer>
          {context => {
            let LayoutTag =
              fullLayout === true
                ? context.fullLayout
                : adminLayout === true
                ? context.AdminLayout
                : context.VerticalLayout
            return (
              <LayoutTag {...props} permission={props.user}>
                <Suspense fallback={<Spinner />}>
                  <Component {...props} />
                </Suspense>
              </LayoutTag>
            )
          }}
        </ContextLayout.Consumer>
      )
    }}
  />
)
const mapStateToProps = state => {
  // console.log(state.auth);
  return {
    user: 1
  }
}

const RequireAuth = (data) => {
  is_session();
  for(var i in data.children){
    if(data.children[i].props.path === data.location.pathname){
      return data.children.slice(0, data.children.length-1);
    }
  }
  return data.children.slice(data.children.length-1, data.children.length);
};


const AppRoute = connect(mapStateToProps)(RouteConfig)

class AppRouter extends React.Component {
  render() {
    return (
      <>
        <Router history={history}>
          <Switch>
            <AppRoute path="/signout" exact component={() => <Redirect to="/signin" />} />
            <AppRoute path="/signin" component={Signin} fullLayout />
            <AppRoute path="/signup" component={Signup} fullLayout />
            <AppRoute path="/forgot" component={Forgot} fullLayout />
            <AppRoute path="/resetpassword/:token" component={Reset} fullLayout />
            <AppRoute path="/emailconfirm/:data" children={<EmailChildren />} fullLayout />
            
            <RequireAuth>
              
              <AppRoute path="/admin" exact component={() => <Redirect to="/admin/users" />}/>

              <AppRoute path="/admin/signout" exact component={() => <Redirect to="/admin/login" />}/>

              <AppRoute path="/admin/users" component={Users} adminLayout />
              <AppRoute path="/admin/deposit" component={ADeposit} adminLayout />
              <AppRoute path="/admin/withdraw" component={ADWithdraw} adminLayout />
              <AppRoute path="/admin/buy" component={ABuy} adminLayout />
              <AppRoute path="/admin/sell" component={ASell} adminLayout />
              <AppRoute path="/admin/login" component={Adminlogin} fullLayout />

              <AppRoute path="/" exact component={() => <Redirect to="/dashboard" />}/>
              <AppRoute exact path="/dashboard" component={Dashboard} />

              <AppRoute path="/company" component={Company} />

              <AppRoute path="/transfer" component={Transfer} />
              <AppRoute path="/trustline" component={Trustline} />
              
              <AppRoute path="/buy" component={Buy} />
              <AppRoute path="/sell" component={Sell} />

              <AppRoute path="/deposit" component={Deposit} />
              <AppRoute path="/withdraw" component={Withdraw} />
              <AppRoute path="/exchange" component={Exchange} />

              <AppRoute path="/beneficiaries/manage" component={Benefic} />
              <AppRoute path="/wallets" component={Balancem} />

              <AppRoute path="/personal" component={KYCpersonal} />
              <AppRoute path="/organization" component={KYCorganization} />

              <AppRoute component={Error} fullLayout />
            </RequireAuth>
          </Switch>
        </Router>
        <ToastContainer
          position="top-right"
          autoClose={5000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
        />
      </>
    )
  }
}

export default AppRouter
