import React, { Suspense } from "react"
import ReactDOM from "react-dom"
import { Provider } from "react-redux"
import App from './resource/App';
import { Layout } from "./layouts/Layout"
import { store } from "./resource/store"
import Spinner from "./resource/Loading-spinner"

ReactDOM.render(
  <Provider store={store}>
      <Suspense fallback={<Spinner />}>
        <Layout>
          <App />
        </Layout>
      </Suspense>
    </Provider>,
  document.getElementById('root')
);