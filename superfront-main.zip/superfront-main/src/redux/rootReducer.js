import { combineReducers } from "redux"
import auth from "./reducers/auth";
import userdata from "./reducers/userdata";
import stellar from "./reducers/stellar";
import socket from "./reducers/socket";
import admin from "./reducers/admin";

const rootReducer = combineReducers({
  auth,
  userdata,
  stellar,
  socket,
  admin,
})

export default rootReducer
