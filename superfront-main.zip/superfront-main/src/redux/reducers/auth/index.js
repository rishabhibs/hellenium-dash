const authinitialState = {
  signupresult: {},
  auth: null
}

const auth = (state = authinitialState , action) => {
  switch (action.type) {
    case "SIGNUP":
      return { ...state, signupresult: action.data }
    case "SIGNIN":
      return { ...state, auth: action.data }
    case "SIGNOUT":
      return { ...state, auth: null }
    case "SESSION_CHECK":
      return { ...state, auth: action.data }
    default:
      return state
  }
}
  
export default auth