import axios from 'axios'
import { toast } from 'react-toastify'
import config from '../../../config'

export const addtrustline = (assetdata) => {
    return async dispatch => {
        assetdata.partner_id = config.userinfo;
        var result = await axios.post(`${config.server_url}/stellar/addtrustline`, {data: assetdata});
        if(result.data.status === true) {
            toast.success("Success!", {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });

            var wallets = await axios.post(`${config.server_url}/wallets/mywallets`, {data: config.userinfo});
            let currentwallet = wallets.data.result.filter(item => item.use === true).length > 0 ? wallets.data.result.filter(item => item.use === true)[0] : {};
            var XLM = await axios.post(config.server_url + '/stellar/account', {signer: currentwallet.public_key});
            var obj = {};
            if(XLM['data']['balances']) {
                obj['stellar_balance'] = XLM['data']['balances'];
            } else {
                obj['stellar_balance'] = 0;
            }
            var currencies = await axios.post(config.server_url + '/wallets/getcurencies', { data: currentwallet.id });
            let cur = []
            if(currentwallet) {
                for(let i = 0 ; i < currencies.data.result.length ; i++) {
                    cur.push({
                        asset_code: currencies.data.result[i].type,
                        balance: currencies.data.result[i].amount,
                    })
                }
                if(obj['stellar_balance'] === 0) {
                    obj['stellar_balance'] = cur
                } else {
                    for(let j = 0 ; j < cur.length ; j++) {
                        obj['stellar_balance'].push(cur[j])
                    }
                }
            }
            
            dispatch({
                type: "WALLETS",
                data: wallets.data.result,
                currentwallet: currentwallet,
                allasets: obj
            })
        } else {
            toast.warning(result.data.result, {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }
}

export const getwallets = () => {
    return async dispatch => {

        var wallets = await axios.post(`${config.server_url}/wallets/mywallets`, {data: config.userinfo});
        let currentwallet = wallets.data.result.filter(item => item.use === true).length > 0 ? wallets.data.result.filter(item => item.use === true)[0] : {} ;
        
        dispatch({
            type: "WALLETS",
            data: wallets.data.result,
            currentwallet: currentwallet
        })

    }
}

export const activewallet = (publickey) => {
    return async dispatch => {
        var returnvalue = await axios.post(`${config.server_url}/wallets/activewallet`, {
            data: {
                partner_id: config.userinfo,
                public_key: publickey
            }
        });
        if(returnvalue.data.status === true) {
            toast.success("Wallet is actived", {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            var wallets = await axios.post(`${config.server_url}/wallets/mywallets`, {data: config.userinfo});
            var XLM = await axios.post(config.server_url + '/stellar/account', {signer: returnvalue.data.result.public_key});
            var obj = {};
            if(XLM['data']['balances']) {
                obj['stellar_balance'] = XLM['data']['balances'];
            } else {
                obj['stellar_balance'] = 0;
            }
            var currencies = await axios.post(config.server_url + '/wallets/getcurencies', { data: returnvalue.data.result.id });
            let cur = []
            for(let i = 0 ; i < currencies.data.result.length ; i++) {
                cur.push({
                    asset_code: currencies.data.result[i].type,
                    balance: currencies.data.result[i].amount,
                })
            }
            if(obj['stellar_balance'] === 0) {
                obj['stellar_balance'] = cur
            } else {
                for(let j = 0 ; j < cur.length ; j++) {
                    obj['stellar_balance'].push(cur[j])
                }
            }
            
            dispatch({
                type: "WALLETS",
                data: wallets.data.result,
                currentwallet: returnvalue.data.result,
                allasets: obj
            })

        } else {
            toast.warning("Something went wrong", {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }
}

export const createwallet = (walletinfo) => {
    return async dispatch => {
        walletinfo.partner_id = config.userinfo;
        var returndata = await axios.post(`${config.server_url}/wallets/create`, {data: walletinfo});
        if(returndata.data.status === true) {
            toast.success("You have created the wallet successfuly.", {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        } else {
            toast.error(returndata.data.result, {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
        // window.location.reload();
        var wallets = await axios.post(`${config.server_url}/wallets/mywallets`, {data: config.userinfo});
        let currentwallet = wallets.data.result.filter(item => item.use === true).length > 0 ? wallets.data.result.filter(item => item.use === true)[0] : {};
        var XLM = await axios.post(config.server_url + '/stellar/account', {signer: currentwallet.public_key});
        var obj = {};
        if(XLM['data']['balances']) {
            obj['stellar_balance'] = XLM['data']['balances'];
        } else {
            obj['stellar_balance'] = 0;
        }
        var currencies = await axios.post(config.server_url + '/wallets/getcurencies', { data: currentwallet.id });
        let cur = []
        if(currentwallet) {
            for(let i = 0 ; i < currencies.data.result.length ; i++) {
                cur.push({
                    asset_code: currencies.data.result[i].type,
                    balance: currencies.data.result[i].amount,
                })
            }
            if(obj['stellar_balance'] === 0) {
                obj['stellar_balance'] = cur
            } else {
                for(let j = 0 ; j < cur.length ; j++) {
                    obj['stellar_balance'].push(cur[j])
                }
            }
        }
        
        dispatch({
            type: "WALLETS",
            data: wallets.data.result,
            currentwallet: currentwallet,
            allasets: obj,
            wresult: true
        })
    }
}