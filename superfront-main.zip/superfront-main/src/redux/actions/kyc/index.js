import axios from "axios";
import config from '../../../config';
import { toast } from 'react-toastify';

export const personal_kyc_save = (data) => {
    return async dispatch => {
        data.partner_id = config.userinfo;
        var return_result = await axios.post(`${config.server_url}/kyc/personal_kyc_save`, { data: data});
        if(return_result.data.status === true) {
            toast.success("You have submitted successfuly! Please wait for approving!", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            dispatch({
                type : "KYC",
                data : true
            })
        } else {
            toast.warning(return_result.data.result, {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            dispatch({
                type : "KYC",
                data : false
            })
        }
        
    }
}

export const personal_kyb_save = (data) => {
    return async dispatch => {
        data.partner_id = config.userinfo;
        var return_result = await axios.post(`${config.server_url}/kyc/personal_kyb_save`, { data: data});
        if(return_result.data.status === true) {
            toast.success("You have submitted successfuly! Please wait for approving!", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            dispatch({
                type : "KYB",
                data : true
            })
        } else {
            toast.warning(return_result.data.result, {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            dispatch({
                type : "KYB",
                data : false
            })
        }
        
    }
}

export const check_kyc = () => {
    return async dispatch => {
        var return_result = await axios.post(`${config.server_url}/kyc/kycCheck`, { data: config.userinfo});
        if(return_result.data.status === true) {
            dispatch({
                type : "KYC",
                data : true
            })
        } else {
            dispatch({
                type : "KYC",
                data : false
            })
        }
        
    }
}

export const passbasecheck = (identityAccessKey) => {
    return async dispatch => {
        const body = {
          identityAccessKey: identityAccessKey,
        };
        const requestOptions = {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(body),
        };
        fetch(`${config.server_url}/kyc/passbase-webhooks`, requestOptions)
          .then(() => {
            dispatch({
                type : "PASSBASE",
                data : true
            })
          })
          .catch((error) => {
            dispatch({
                type : "PASSBASE",
                data : false
            })
          });
    }
}