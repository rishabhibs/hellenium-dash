import axios from 'axios'
import config from '../../../config';
import Cookies from 'universal-cookie';
import { toast } from 'react-toastify';
import socketIOClient from "socket.io-client";
const cookies = new Cookies();

export const signUp = (data) => {
    return dispatch => {
        axios.post(config.server_url + '/users/create', data)
        .then(res => {
            dispatch({
                type: "SIGNUP",
                data: res.data
            })
        })
    }
}

export const signIn = (data) => {
    return dispatch => {
        axios.post(config.server_url + '/users/login', data)
        .then(res => {
            if(config.dev === true) {
                cookies.set('token', res.data.usertoken, { path: '/', domain: 'localhost' });
                cookies.remove('socket', { path: '/', domain: "localhost" });
            } else {
                cookies.set('token', res.data.usertoken, { path: '/', domain: 'hellenium.com' });
                cookies.remove('socket', { path: '/', domain: "hellenium.com" });
            }
            dispatch({
                type: "SIGNIN",
                data: res.data
            })
        })
    }
}

export const signOut = () => {
    var data = JSON.parse(atob(cookies.get('token')));
    var obj = {
        email : data.email
    }
    if(config.dev === true) {
        cookies.remove('token', { path: '/', domain: "localhost" });
        cookies.remove('socket', { path: '/', domain: "localhost" });
    } else {
        cookies.remove('token', { path: '/', domain: "hellenium.com" });
        cookies.remove('socket', { path: '/', domain: "hellenium.com" });
    }
    return dispatch => {
        axios.post(`${config.server_url}/users/logout`, obj)
        .then(res => {
            dispatch({
                type: "SIGNOUT",
                data: null
            })
        })
    }
}

// Socket connection
export const socketconnect = (sendertype) => {
    return async (dispatch) => {
        if(cookies.get('socket') === undefined) {
            var socket = null;
            socket = socketIOClient(config.server_url);
            socket.emit('getid', {userid: config.userinfo, type: sendertype});
            socket.on('sendid', (id) => {
                if(config.dev === true) {
                    cookies.set('socket', id, { path: '/', domain: 'localhost' });
                } else {
                    cookies.set('socket', id, { path: '/', domain: 'hellenium.com' });
                }
            })
            dispatch({
                type: "SOCKET",
                data: socket
            })
        } else {
            let result = await axios.post(`${config.server_url}/socket/check`, { data : { socketID : cookies.get('socket') }});
            if(result.data.status === true) {
                dispatch({
                    type: "SOCKET_STATUS",
                    data: true
                })
            } else {
                let socket = null;
                socket = socketIOClient(config.server_url);
                socket.emit('getid', { userid: config.userinfo, type: sendertype});
                socket.on('sendid', (id) => {
                    if(config.dev === true) {
                        cookies.set('socket', id, { path: '/', domain: 'localhost' });
                    } else {
                        cookies.set('socket', id, { path: '/', domain: 'hellenium.com' });
                    }
                })
                dispatch({
                    type: "SOCKET",
                    data: socket
                })
            }
        }
    }
}

export const user_info = () => {
    return dispatch => {
        axios.post(config.server_url + '/users/user_info', {data : config.userinfo})
        .then(res => {
            dispatch({
                type: "USERINFO",
                data: res.data.userinfo
            })
        })
    }
}

export const forgotpassword = (email) => {
    return dispatch => {
        axios.post(config.server_url + '/users/forgotpass', {data : email})
        .then(res => {
            if(res.data.status === false) {
                toast.warning(res.data.msg, {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            } else {
                toast.success(res.data.msg, {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
            dispatch({
                type: "FORGOTPASS",
                data: res.data.status
            })
        })
    }
}

export const checktoken = (token) => {
    return dispatch => {
        axios.post(config.server_url + '/users/checktoken', {data : token})
        .then(res => {
            if(res.data.status === false) {
                toast.warning(res.data.msg, {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
            dispatch({
                type: "TOKENSTATUS",
                data: res.data.status
            })
        })
    }
}

export const resetpass = (email) => {
    return dispatch => {
        axios.post(config.server_url + '/users/resetpass', {data : email})
        .then(res => {
            dispatch({
                type: "RESETPASS",
                data: res.data.userinfo
            })
        })
    }
}