import axios from 'axios';
import config from '../../../config';
import { toast } from 'react-toastify';

export const sell = (request_data) =>  {
    return async dispatch => {
        request_data.partner_id = config.userinfo;
        var selldata = await axios.post(config.server_url + '/stellar/sell', request_data);
        if(selldata.data.status === true) {
            toast.success("Success!", {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        } else {
            toast.warning(selldata.data.result, {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
        var cur_wallet = await axios.post(config.server_url + '/wallets/currentwallet', { data: config.userinfo });
        if( cur_wallet.data.status === true ) {
            if(cur_wallet.data.result.length > 0) {
                var XLM = await axios.post(config.server_url + '/stellar/account', {signer: cur_wallet.data.result[0].public_key});
                var obj = {};
                if(XLM['data']['balances']) {
                    obj['stellar_balance'] = XLM['data']['balances'];
                } else {
                    obj['stellar_balance'] = 0;
                }
                var currencies = await axios.post(config.server_url + '/wallets/getcurencies', { data: cur_wallet.data.result[0].id });
                let cur = []
                for(let i = 0 ; i < currencies.data.result.length ; i++) {
                    cur.push({
                        asset_code: currencies.data.result[i].type,
                        balance: currencies.data.result[i].amount,
                    })
                }
                if(obj['stellar_balance'] === 0) {
                    obj['stellar_balance'] = cur
                } else {
                    for(let j = 0 ; j < cur.length ; j++) {
                        obj['stellar_balance'].push(cur[j])
                    }
                }
                // var balance = await axios.post(config.server_url + '/currencycloud/findbalances');
                // obj['currency_balances'] = balance['data']['balances'];
                dispatch({
                    type: "AllASSETS",
                    data: obj
                })
            } else {
                dispatch({
                    type: "AllASSETS",
                    data: []
                })
            }
        }
    }
}