import axios from 'axios'
import config from '../../../config';

export const gettoken = () => {
    return async dispatch => {
        var obj = {
            login_id: 'stigerpanda@gmail.com',
            api_key: '3594d1f698970f8a2f9748985f95ddae8c5a79d004c78afd3385b5c0d3ae3314'
        }
        var auth_token = await axios.post(config.request_url + '/authenticate/currencycloud', obj);
        dispatch({
            type: "GETBALANCES",
            data: balances
        })
    }
}