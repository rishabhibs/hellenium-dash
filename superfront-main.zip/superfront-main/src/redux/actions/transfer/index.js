import axios from 'axios'
import { toast } from 'react-toastify';
import config from '../../../config';

export const transfer = (data) => {
    return async dispatch => {
        const headers = {
            'X-Auth-Token': config.auth_token,
        };
        var data = await axios.get(config.request_url + '/beneficiaries/find', {headers});
        dispatch({
            type: "CONVERT",
            data: data.data
        })
    }
}

export const transfer_stellar = (data) => {
    return async dispatch => {
        var obj = {
            password: data.password,
            receiver: data.destination,
            assetCode: data.assetCode,
            assetIssuer: data.assetIssuer,
            amount: data.amount,
            partner_id: config.userinfo,
            realid: data.realid,
            public_key: data.public_key,
            type: data.type
        }
        var return_data = {};
        if(obj.type === "fiat") {
            return_data = await axios.post(config.server_url + '/wallets/createpay', {data: obj});
        } else {
            return_data = await axios.post(config.server_url + '/stellar/transfer', obj);
        }
        if(return_data.data.status === true) {
            toast.success('Success', {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        } else {
            toast.warning(return_data.data.result, {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
        var cur_wallet = await axios.post(config.server_url + '/wallets/currentwallet', { data: config.userinfo });
        if( cur_wallet.data.status === true ) {
            if(cur_wallet.data.result.length > 0) {
                var XLM = await axios.post(config.server_url + '/stellar/account', {signer: cur_wallet.data.result[0].public_key});
                obj = {};
                if(XLM['data']['balances']) {
                    obj['stellar_balance'] = XLM['data']['balances'];
                } else {
                    obj['stellar_balance'] = 0;
                }
                var currencies = await axios.post(config.server_url + '/wallets/getcurencies', { data: cur_wallet.data.result[0].id });
                let cur = []
                for(let i = 0 ; i < currencies.data.result.length ; i++) {
                    cur.push({
                        asset_code: currencies.data.result[i].type,
                        balance: currencies.data.result[i].amount,
                    })
                }
                if(obj['stellar_balance'] === 0) {
                    obj['stellar_balance'] = cur
                } else {
                    for(let j = 0 ; j < cur.length ; j++) {
                        obj['stellar_balance'].push(cur[j])
                    }
                }
                // var balance = await axios.post(config.server_url + '/currencycloud/findbalances');
                // obj['currency_balances'] = balance['data']['balances'];
                dispatch({
                    type: "AllASSETS",
                    data: obj
                })
            } else {
                dispatch({
                    type: "AllASSETS",
                    data: []
                })
            }
        } else {
            dispatch({
                type: "CURRENT",
                data: []
            })
        }
    }
}

// export const addbeneficiaries = (data) => {
//     return async dispatch => {
//         dispatch({
//             type: "ADDBENEFICIARIES",
//             data: data
//         })
//     }
// }
