// import axios from 'axios'
// import config from '../../../config';

export const GotoSearch = (data) => {
    return dispatch => {
        dispatch({
            type: "SEARCH",
            data: data
        })
    }
}