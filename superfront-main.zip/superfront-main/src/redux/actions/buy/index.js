import axios from 'axios'
import { toast } from 'react-toastify';
import config from '../../../config';
// import { history } from '../../../resource/history';

export const buy = (request_data) =>  {
    return async dispatch => {
        request_data.partner_id = config.userinfo;
        var buydata = await axios.post(config.server_url + '/stellar/buy', request_data);
        if(buydata.data.status === true) {
            toast.success(buydata.data.result, {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        } else {
            toast.warning(buydata.data.result, {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
        var cur_wallet = await axios.post(config.server_url + '/wallets/currentwallet', { data: config.userinfo });
        if( cur_wallet.data.status === true ) {
            if(cur_wallet.data.result.length > 0) {
                var XLM = await axios.post(config.server_url + '/stellar/account', {signer: cur_wallet.data.result[0].public_key});
                var obj = {};
                if(XLM['data']['balances']) {
                    obj['stellar_balance'] = XLM['data']['balances'];
                } else {
                    obj['stellar_balance'] = 0;
                }
                var currencies = await axios.post(config.server_url + '/wallets/getcurencies', { data: cur_wallet.data.result[0].id });
                let cur = []
                for(let i = 0 ; i < currencies.data.result.length ; i++) {
                    cur.push({
                        asset_code: currencies.data.result[i].type,
                        balance: currencies.data.result[i].amount,
                    })
                }
                if(obj['stellar_balance'] === 0) {
                    obj['stellar_balance'] = cur
                } else {
                    for(let j = 0 ; j < cur.length ; j++) {
                        obj['stellar_balance'].push(cur[j])
                    }
                }
                // var balance = await axios.post(config.server_url + '/currencycloud/findbalances');
                // obj['currency_balances'] = balance['data']['balances'];
                dispatch({
                    type: "AllASSETS",
                    data: obj
                })
            } else {
                dispatch({
                    type: "AllASSETS",
                    data: []
                })
            }
        }
    }
}

export const deposit = (required_data) => {
    return async dispatch => {
        required_data.partner_id = config.userinfo;
        var result_data = await axios.post(config.server_url + '/stellar/deposit', {data: required_data});
        if(result_data.data.status === true) {
            toast.success(result_data.data.result, {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        } else {
            toast.warning(result_data.data.result, {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            return;
        }
        var cur_wallet = await axios.post(config.server_url + '/wallets/currentwallet', { data: config.userinfo });
        if( cur_wallet.data.status === true ) {
            if(cur_wallet.data.result.length > 0) {
                var XLM = await axios.post(config.server_url + '/stellar/account', {signer: cur_wallet.data.result[0].public_key});
                var obj = {};
                if(XLM['data']['balances']) {
                    obj['stellar_balance'] = XLM['data']['balances'];
                } else {
                    obj['stellar_balance'] = 0;
                }
                var currencies = await axios.post(config.server_url + '/wallets/getcurencies', { data: cur_wallet.data.result[0].id });
                let cur = []
                for(let i = 0 ; i < currencies.data.result.length ; i++) {
                    cur.push({
                        asset_code: currencies.data.result[i].type,
                        balance: currencies.data.result[i].amount,
                    })
                }
                if(obj['stellar_balance'] === 0) {
                    obj['stellar_balance'] = cur
                } else {
                    for(let j = 0 ; j < cur.length ; j++) {
                        obj['stellar_balance'].push(cur[j])
                    }
                }
                // var balance = await axios.post(config.server_url + '/currencycloud/findbalances');
                // obj['currency_balances'] = balance['data']['balances'];
                dispatch({
                    type: "AllASSETS",
                    data: obj
                })
            } else {
                dispatch({
                    type: "AllASSETS",
                    data: []
                })
            }
        }
    }
}
export const withdraw = (required_data) => {
    return async dispatch => {
        required_data.partner_id = config.userinfo;
        var result_data = await axios.post(config.server_url + '/stellar/withdraw', {data: required_data});
        if(result_data.data.status === true) {
            toast.success(result_data.data.result, {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        } else {
            toast.warning(result_data.data.result, {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            dispatch({
                type: "WITHDRAW",
                data: null
            })
        }
        var cur_wallet = await axios.post(config.server_url + '/wallets/currentwallet', { data: config.userinfo });
        if( cur_wallet.data.status === true ) {
            if(cur_wallet.data.result.length > 0) {
                var XLM = await axios.post(config.server_url + '/stellar/account', {signer: cur_wallet.data.result[0].public_key});
                var obj = {};
                if(XLM['data']['balances']) {
                    obj['stellar_balance'] = XLM['data']['balances'];
                } else {
                    obj['stellar_balance'] = 0;
                }
                var currencies = await axios.post(config.server_url + '/wallets/getcurencies', { data: cur_wallet.data.result[0].id });
                let cur = []
                for(let i = 0 ; i < currencies.data.result.length ; i++) {
                    cur.push({
                        asset_code: currencies.data.result[i].type,
                        balance: currencies.data.result[i].amount,
                    })
                }
                if(obj['stellar_balance'] === 0) {
                    obj['stellar_balance'] = cur
                } else {
                    for(let j = 0 ; j < cur.length ; j++) {
                        obj['stellar_balance'].push(cur[j])
                    }
                }
                // var balance = await axios.post(config.server_url + '/currencycloud/findbalances');
                // obj['currency_balances'] = balance['data']['balances'];
                dispatch({
                    type: "AllASSETS",
                    data: obj
                })
            } else {
                dispatch({
                    type: "AllASSETS",
                    data: []
                })
            }
        }
    }
}
