import axios from 'axios'
import config from '../../../config';
import { history } from '../../../resource/history';
import { toast } from 'react-toastify';
import Cookies from 'universal-cookie';

export const is_session = () => {
    const cookies = new Cookies();
    if(window.location.href.indexOf('admin') === -1) {
        if(!cookies.get('token')) {
            if(history.location.pathname !== "/signin" && history.location.pathname !== "/") {
                toast.error('You have to signin.', {
                    position: "top-right",
                    autoClose: 3000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                history.push('/signin');
            } else if(history.location.pathname === "/") {
                history.push('/signin');
            }
        } else {
            var data = JSON.parse(atob(cookies.get('token')));
            axios.post(config.server_url + '/session/check', {id: data})
            .then(res => {
                if(res.data.status === false) {
                    toast.info('Session expired.', {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                    if(config.dev === true) {
                        cookies.remove('token', { path: '/', domain: "localhost" });
                    } else {
                        cookies.remove('token', { path: '/', domain: "hellenium.com" });
                    }
                    history.push('/signout');
                }
            })
        }
    } else {
        if(window.location.href.indexOf('/admin/login') === -1) {
            let adtoken = cookies.get('adtoken');
            if(adtoken === null || adtoken === undefined ) {
                history.push('/admin/login');
            } else {
                let adtodata = atob(adtoken);
                axios.post(config.server_url + '/admin/check', {data: adtodata})
                .then(res => {
                    if(res.data.status === false) {
                        toast.info('Session expired.', {
                            position: "top-right",
                            autoClose: 5000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                        });
                        if(config.dev === true) {
                            cookies.remove('adtoken', { path: '/', domain: "localhost" });
                        } else {
                            cookies.remove('adtoken', { path: '/', domain: "hellenium.com" });
                        }
                        history.push('/admin/signout');
                    }
                })
                .catch(err => {
                    history.push('/admin/login');
                })
            }
        }
    }
}