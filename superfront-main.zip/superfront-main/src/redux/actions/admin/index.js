import axios from 'axios'
import config from '../../../config';
import { toast } from 'react-toastify';
import Cookies from 'universal-cookie';
import { history } from '../../../resource/history';

export const adminsignin = (data) => {
    const cookies = new Cookies();
    return dispatch => {
        axios.post(config.server_url + '/admin/adminsignin', { data: data })
        .then(res => {
            if(res.data.status === true) {
                toast.success("Success!", {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                if(config.dev === true) {
                    cookies.set('adtoken', btoa(res.data.result), { path : '/', domain: 'localhost' });
                } else {
                    cookies.set('adtoken', btoa(res.data.result), { path : '/', domain: 'hellenium.com' });
                }
                history.push('/admin/users');
            } else {
                toast.error(res.data.result, {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return;
            }
            dispatch({
                type: "ADMININFO",
                data: res.data
            })
        })
    }
}

export const depositsget = () => {
    return dispatch => {
        axios.post(config.server_url + '/admin/depositsget', {})
        .then(res => {
            dispatch({
                type: "DEPOSTREQUESTS",
                data: res.data.result
            })
        })
    }
}

export const depositschange = (data) => {
    return dispatch => {
        axios.post(config.server_url + '/admin/d_change', {data: data})
        .then(res => {
            if(res.data.status === true) {
                toast.success("Success!", {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            } else {
                toast.error("Fail Something went wrong!", {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
            axios.post(config.server_url + '/admin/depositsget', {})
            .then(res => {
                dispatch({
                    type: "DEPOSTREQUESTS",
                    data: res.data.result
                })
            })
        })
    }
}

export const withdrawget = () => {
    return dispatch => {
        axios.post(config.server_url + '/admin/withdrawget', {})
        .then(res => {
            dispatch({
                type: "WITHDRAWREQUESTS",
                data: res.data.result
            })
        })
    }
}

export const withdrawchange = (data) => {
    return dispatch => {
        axios.post(config.server_url + '/admin/w_change', {data: data})
        .then(res => {
            if(res.data.status === true) {
                toast.success("Success!", {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            } else {
                toast.error("Fail Something went wrong!", {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
            axios.post(config.server_url + '/admin/withdrawget', {})
            .then(res => {
                dispatch({
                    type: "WITHDRAWREQUESTS",
                    data: res.data.result
                })
            })
        })
    }
}

export const getusers = () => {
    return dispatch => {
        axios.post(config.server_url + '/admin/getusers', {})
        .then(res => {
            dispatch({
                type: "USERS",
                data: res.data
            })
        })
    }
}

export const DeleteUser = (partner_id) => {
    return dispatch => {
        axios.post(config.server_url + '/admin/deleteuser', {data: partner_id})
        .then(res => {
            if(res.data.status === true) {
                toast.success("Success!", {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                dispatch({
                    type: "USERS",
                    data: res.data
                })
            } else {
                toast.error(res.data.result, {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                }); return;
            }
        })
    }
}

export const EditUser = (editeduser) => {
    return dispatch => {
        axios.post(config.server_url + '/admin/edituser', {data: editeduser})
        .then(res => {
            if(res.data.status === true) {
                toast.success("Success!", {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                dispatch({
                    type: "USERS",
                    data: res.data
                })
            } else {
                toast.error(res.data.result, {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                }); return;
            }
        })
    }
}

export const buyget = () => {
    return dispatch => {
        axios.post(config.server_url + '/admin/buyget')
        .then(res => {
            dispatch({
                type: "BUYREQUESTS",
                data: res.data.result
            })
        })
    }
}

export const buychange = (data) => {
    return dispatch => {
        axios.post(config.server_url + '/admin/b_change', {data: data})
        .then(res => {
            if(res.data.status === true) {
                toast.success("Success!", {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            } else {
                toast.error("Fail Something went wrong!", {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
            axios.post(config.server_url + '/admin/buyget', {})
            .then(res => {
                dispatch({
                    type: "BUYREQUESTS",
                    data: res.data.result
                })
            })
        })
    }
}

export const deleteHistoryBuy = () => {
    return dispatch => {
        axios.post(config.server_url + '/admin/deleteHistoryBuy')
        .then(res => {
            dispatch({
                type: "BUYREQUESTS",
                data: res.data.result
            })
        })
    }
}

export const sellget = () => {
    return dispatch => {
        axios.post(config.server_url + '/admin/sellget')
        .then(res => {
            dispatch({
                type: "SELLREQUESTS",
                data: res.data.result
            })
        })
    }
}

// export const sellchange = (data) => {
//     return dispatch => {
//         axios.post(config.server_url + '/admin/s_change', {data: data})
//         .then(res => {
//             if(res.data.status === true) {
//                 toast.success("Success!", {
//                     position: "top-right",
//                     autoClose: 2000,
//                     hideProgressBar: false,
//                     closeOnClick: true,
//                     pauseOnHover: true,
//                     draggable: true,
//                     progress: undefined,
//                 });
//             } else {
//                 toast.error("Fail Something went wrong!", {
//                     position: "top-right",
//                     autoClose: 2000,
//                     hideProgressBar: false,
//                     closeOnClick: true,
//                     pauseOnHover: true,
//                     draggable: true,
//                     progress: undefined,
//                 });
//             }
//             axios.post(config.server_url + '/admin/sellget', {})
//             .then(res => {
//                 dispatch({
//                     type: "SELLREQUESTS",
//                     data: res.data
//                 })
//             })
//         })
//     }
// }

// export const deleteHistorySell = () => {
//     return dispatch => {
//         axios.post(config.server_url + '/admin/deleteHistorySell')
//         .then(res => {
//             dispatch({
//                 type: "BUYREQUESTS",
//                 data: res.data.result
//             })
//         })
//     }
// }