import axios from 'axios'
import config from '../../../config';
import Cookies from 'universal-cookie';

export const getbalances = () => {
    return async dispatch => {
        var balances = await axios.post(config.server_url + '/currencycloud/findbalances');
        dispatch({
            type: "GETBALANCES",
            data: balances
        })
    }
}

export const current_wallet = () => {
    return async dispatch => {
        var cur_wallet = await axios.post(config.server_url + '/wallets/currentwallet', { data: config.userinfo });
        if( cur_wallet.data.status === true ) {
            var walletdt = cur_wallet.data.result;
            if(walletdt.length > 0) {
                
                walletdt = walletdt[0];
                
                var XLM = await axios.post(config.server_url + '/stellar/account', {signer: walletdt.public_key});
                var obj = {};
                if(XLM['data']['balances']) {
                    obj['stellar_balance'] = XLM['data']['balances'];
                } else {
                    obj['stellar_balance'] = 0;
                }
                var currencies = await axios.post(config.server_url + '/wallets/getcurencies', { data: walletdt.id });
                let cur = []
                for(let i = 0 ; i < currencies.data.result.length ; i++) {
                    cur.push({
                        asset_code: currencies.data.result[i].type,
                        balance: currencies.data.result[i].amount,
                    })
                }
                if(obj['stellar_balance'] === 0) {
                    obj['stellar_balance'] = cur
                } else {
                    for(let j = 0 ; j < cur.length ; j++) {
                        obj['stellar_balance'].push(cur[j])
                    }
                }
                // var balance = await axios.post(config.server_url + '/currencycloud/findbalances');
                // obj['currency_balances'] = balance['data']['balances'];
                dispatch({
                    type: "AllASSETS",
                    data: obj
                })
            } else {
                dispatch({
                    type: "AllASSETS",
                    data: []
                })
            }
        } else {
            dispatch({
                type: "CURRENT",
                data: []
            })
        }
    }
}

export const addbalances = (data) => {
    return async dispatch => {
        dispatch({
            type: "ADDBALANCES",
            data: data
        })
    }
}

export const allasets = () => {
    return async dispatch => {
        try {
            const cookies = new Cookies();
            let data = JSON.parse(atob(cookies.get('token')));
            var XLM = await axios.post(config.server_url + '/stellar/account', {signer: data['s_account_id']});
            var obj = {};
            if(XLM['data']['balances']) {
                obj['stellar_balance'] = XLM['data']['balances'];
            } else {
                obj['stellar_balance'] = 0;
            }
            // var balance = await axios.post(config.server_url + '/currencycloud/findbalances');
            // obj['currency_balances'] = balance['data']['balances'];
            dispatch({
                type: "AllASSETS",
                data: obj
            })
        } catch (error) {
            dispatch({
                type: "AllASSETS",
                data: error
            })
        }
    }
}

export const addasset = () => {
    return async dispatch => {
        const cookies = new Cookies();
        let data = JSON.parse(atob(cookies.get('token')));
        var resultdata = await axios.post(config.server_url + '/stellar/addasset', { assetCode : "msc1", secret: data['s_account_id_secret']});
        if(resultdata.data.status === true) {
            var XLM = await axios.post(config.server_url + '/stellar/account', {signer: data['s_account_id']});
            var obj = {};
            if(XLM['data']['balances']) {
                obj['stellar_balance'] = XLM['data']['balances'];
            } else {
                obj['stellar_balance'] = 0;
            }
            dispatch({
                type: "AllASSETS",
                data: obj
            })
        } else {
            dispatch({
                type: "ERROR",
                data: resultdata.data.error
            })
        }
    }
}

export const getliveprice = () => {
    return async dispatch => {
        let data = await axios.post(config.server_url + '/stellar/getliveprice');
        dispatch({
            type: "LIVEPRICE",
            data: data
        })
    }
}

export const gettransactions = (re_data) => {
    return async dispatch => {

        let transactiondata = await axios.post(config.server_url + '/wallets/transactions', { data : re_data });

        if(transactiondata.data.status === true) {
            dispatch({
                type: "TRANDATA",
                data: transactiondata.data.result
            })
        } else {
            dispatch({
                type: "TRANDATA",
                data: []
            })
        }
    }
}