
import axios from 'axios';
import config from '../../../config';

export const getallcurrencies = () => {
    return async dispatch => {
        // let tomlResult = {};
        // if(config.dev === true) {
        //     tomlResult = await StellarTomlResolver.resolve(config.toml_url, { allowHttp:true });
        // } else {
        //     tomlResult = await StellarTomlResolver.resolve(config.toml_url);
        // }
        // var fiatarr = [], cryptoarr = [], allarr = [];
        // for(var i = 0 ; i < tomlResult.CURRENCIES.length ; i++) {
        //     var obj = {}
        //     if(tomlResult.CURRENCIES[i].anchor_asset_type === "crypto") {
        //         obj['value'] = tomlResult.CURRENCIES[i].code;
        //         obj['label'] = tomlResult.CURRENCIES[i].code;
        //         obj['issuer'] = tomlResult.CURRENCIES[i].issuer;
        //         cryptoarr.push(obj);
        //         allarr.push(obj);
        //         continue;
        //     }
        //     obj['value'] = tomlResult.CURRENCIES[i].code;
        //     obj['label'] = tomlResult.CURRENCIES[i].code;
        //     fiatarr.push(obj);
        //     allarr.push(obj);
        // }
        // cryptoarr.push({
        //     value : "XLM",
        //     label : "XLM"
        // })
        // allarr.push({
        //     value : "XLM",
        //     label : "XLM"
        // })
        // console.log(allarr)
        var data1 = [
            {value: 'EUR', label: 'EUR'},
            {value: 'USD', label: 'USD'},
            {value: 'GBP', label: 'GBP'},
            {value: 'CHF', label: 'CHF'}
        ]
        var data2 = [
            {value: 'msc1', label: "msc1", issuer: "GCHUU75ANFDIOTRMFTYSA44CMDEYEZ4I2JCGKJELYOF6PWTJSH42MHWM"},
            {value: "XLM", label: "XLM"}
        ]
        var data3 = [
            {value: 'msc1', label: "msc1", issuer: "GCHUU75ANFDIOTRMFTYSA44CMDEYEZ4I2JCGKJELYOF6PWTJSH42MHWM"},
            {value: 'EUR', label: 'EUR'},
            {value: 'USD', label: 'USD'},
            {value: 'GBP', label: 'GBP'},
            {value: 'CHF', label: 'CHF'},
            {value: "XLM", label: "XLM"}
        ]
        dispatch({
            type: "CURRENCIES",
            data: {
                fiat: data1, 
                crypto: data2, 
                all: data3
            }
        })
    }
}

export const getprice = () => {
    return async dispatch => {
        // let result = await axios.post(`${config.server_url}/currencies/getliveprice`);
        // console.log(result.data);
        var data = {
            prices: {
                CHF: 0.29490494315258625,
                EUR: 0.2700947658139078,
                GBP: 0.2329327970096341,
                USD: 0.32899508484962
            }
        }
        dispatch({
            type: "PRICE",
            data: data
        })
    }
}