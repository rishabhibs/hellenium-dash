import axios from 'axios'
import config from '../../../config';

export const payf = (data) => {
    return async dispatch => {
        var result = await axios.post(config.server_url + '/currencycloud/pay',data);
        dispatch({
            type: "PAY",
            data: result.data
        })
    }
}

// export const addbeneficiaries = (data) => {
//     return async dispatch => {
//         dispatch({
//             type: "ADDBENEFICIARIES",
//             data: data
//         })
//     }
// }
