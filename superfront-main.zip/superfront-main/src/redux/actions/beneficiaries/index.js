import axios from 'axios'
import config from '../../../config';
import { toast } from 'react-toastify';
// export const getbeneficiaries = () => {
//     return async dispatch => {
//         var beneficiaries = await axios.post(config.server_url + '/currencycloud/findbeneficiaries');
//         dispatch({
//             type: "GETBENEFICIARIES",
//             data: beneficiaries.data
//         })
//     }
// }

// export const addbeneficiaries = (payload) => {
//     return async dispatch => {
//         var data = await axios.post(config.server_url +'/currencycloud/createbeneficiaries', payload);
//         dispatch({
//             type: "ADDBENEFICIARIES",
//             data: data.data
//         })
//     }
// }

export const getusers = () => {
    return async dispatch => {
        var data = await axios.post(config.server_url + '/beneficiaries/getusers', {id: config.userinfo});
        dispatch({
            type: "BENEFICIARIES",
            data: data.data.result
        })
    }
}

export const getusersexept = () => {
    return async dispatch => {
        var data = await axios.post(config.server_url + '/beneficiaries/getusersexept', {id: config.userinfo});
        dispatch({
            type: "GETBENEFICIARIES",
            data: data.data
        })
    }
}

export const adduser = (reqdata) => {
    return async dispatch => {
        var data = await axios.post(config.server_url + '/beneficiaries/adduser', {id: config.userinfo, targetId: reqdata.id});
        toast.success("Success!", {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
        dispatch({
            type: "GETBENEFICIARIES",
            data: data.data
        })
    }
}

export const invite = (requireddata) => {
    return async dispatch => {
        requireddata.sender = requireddata.firstname + ' ' + requireddata.lastname;
        var returndata = await axios.post(config.server_url + '/users/send_mail', requireddata);
        if(returndata.data.status === true) {
            toast.success("You have sent successfuly!", {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        } else {
            toast.error("Something went wrong!", {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
        var users = await axios.post(config.server_url + '/beneficiaries/getusersexept', {id: config.userinfo});
        dispatch({
            type: "GETBENEFICIARIES",
            data: users.data
        })
    }
}