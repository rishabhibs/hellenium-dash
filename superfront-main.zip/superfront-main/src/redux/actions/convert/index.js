import axios from 'axios'
import config from '../../../config';

export const convert = (data) => {
    return async dispatch => {
        var result = await axios.post(config.server_url + '/currencycloud/convert', data);
        dispatch({
            type: "CONVERT",
            data: result.data
        })
    }
}

// export const addbeneficiaries = (data) => {
//     return async dispatch => {
//         dispatch({
//             type: "ADDBENEFICIARIES",
//             data: data
//         })
//     }
// }
