import axios from 'axios'
import config from '../../../config';
import { toast } from 'react-toastify';

export const emailConfirm = (data) => {
    return dispatch => {
        axios.post(config.server_url + '/users/confirm', {data: data})
        .then(res => {
            if(res.data.status === true) {
                toast.success("Success!", {
                    position: "top-right",
                    autoClose: 3000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            } else {
                toast.warning(res.data.message, {
                    position: "top-right",
                    autoClose: 3000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
            dispatch({
                type: "CONFIRM",
                data: res.data
            })
        })
    }
}
