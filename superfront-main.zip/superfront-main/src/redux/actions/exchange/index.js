import axios from 'axios'
import { toast } from 'react-toastify';
import config from '../../../config';

export const exchange = (required_data) => {
    return async dispatch => {
        required_data.partner_id = config.userinfo;
        var result = await axios.post(config.server_url + '/wallets/exchange', {data: required_data});
        if(result.data.status === false) {
            toast.warning("Sorry something went wrong, please try again or ask to support team", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            return;
        } else {
            toast.success("Success, you have exchanged successfuly!", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
        var cur_wallet = await axios.post(config.server_url + '/wallets/currentwallet', { data: config.userinfo });
        if( cur_wallet.data.status === true ) {
            if(cur_wallet.data.result.length > 0) {
                var XLM = await axios.post(config.server_url + '/stellar/account', {signer: cur_wallet.data.result[0].public_key});
                var obj = {};
                if(XLM['data']['balances']) {
                    obj['stellar_balance'] = XLM['data']['balances'];
                } else {
                    obj['stellar_balance'] = 0;
                }
                var currencies = await axios.post(config.server_url + '/wallets/getcurencies', { data: cur_wallet.data.result[0].id });
                let cur = []
                for(let i = 0 ; i < currencies.data.result.length ; i++) {
                    cur.push({
                        asset_code: currencies.data.result[i].type,
                        balance: currencies.data.result[i].amount,
                    })
                }
                if(obj['stellar_balance'] === 0) {
                    obj['stellar_balance'] = cur
                } else {
                    for(let j = 0 ; j < cur.length ; j++) {
                        obj['stellar_balance'].push(cur[j])
                    }
                }
                // var balance = await axios.post(config.server_url + '/currencycloud/findbalances');
                // obj['currency_balances'] = balance['data']['balances'];
                dispatch({
                    type: "AllASSETS",
                    data: obj
                })
            } else {
                dispatch({
                    type: "AllASSETS",
                    data: []
                })
            }
        } else {
            dispatch({
                type: "CURRENT",
                data: []
            })
        }
    }
}